"""
SOLACE — pgvector Semantic Search Client
Embedding-based semantic search over reports and observations.
"""
from __future__ import annotations

from sqlalchemy import text

from config import get_logger
from core.database import get_db_session
from nlp.pipeline import generate_embedding

logger = get_logger("pgvector")


class PgVectorClient:
    """Semantic search operations over pgvector-enabled PostgreSQL tables."""

    async def search_reports(
        self, query: str, limit: int = 10, min_similarity: float = 0.5
    ) -> list[dict]:
        """Semantic search over report embeddings.

        Args:
            query: Natural language search query.
            limit: Maximum results to return.
            min_similarity: Minimum cosine similarity threshold.

        Returns:
            List of report dicts with similarity scores.
        """
        embedding = generate_embedding(query)
        if not embedding:
            return []

        async with get_db_session() as session:
            result = await session.execute(
                text("""
                    SELECT
                        id, report_id, subject, subject_type,
                        classification, confidence, executive_summary,
                        tags, created_at,
                        1 - (embedding <=> CAST(:embedding AS vector)) AS similarity
                    FROM reports
                    WHERE embedding IS NOT NULL
                      AND 1 - (embedding <=> CAST(:embedding AS vector)) >= :min_sim
                    ORDER BY embedding <=> CAST(:embedding AS vector)
                    LIMIT :limit
                """),
                {
                    "embedding": str(embedding),
                    "min_sim": min_similarity,
                    "limit": limit,
                },
            )
            rows = result.mappings().all()
            return [dict(row) for row in rows]

    async def embed_report(self, report_id: str, content: str) -> bool:
        """Generate and store embedding for a report.

        Args:
            report_id: Database report UUID.
            content: Report markdown content to embed.

        Returns:
            True if embedding was stored successfully.
        """
        embedding = generate_embedding(content)
        if not embedding:
            return False

        async with get_db_session() as session:
            await session.execute(
                text("UPDATE reports SET embedding = CAST(:emb AS vector) WHERE id = :id"),
                {"emb": str(embedding), "id": report_id},
            )
        logger.info("report_embedded", report_id=report_id)
        return True

    async def find_related_reports(
        self, report_id: str, limit: int = 5
    ) -> list[dict]:
        """Find reports semantically similar to a given report.

        Args:
            report_id: Database ID of the source report.
            limit: Maximum related reports to return.

        Returns:
            List of related report dicts.
        """
        async with get_db_session() as session:
            result = await session.execute(
                text("""
                    WITH source AS (
                        SELECT embedding FROM reports WHERE id = :id
                    )
                    SELECT
                        r.id, r.report_id, r.subject, r.classification,
                        1 - (r.embedding <=> source.embedding) AS similarity
                    FROM reports r, source
                    WHERE r.id != :id
                      AND r.embedding IS NOT NULL
                    ORDER BY r.embedding <=> source.embedding
                    LIMIT :limit
                """),
                {"id": report_id, "limit": limit},
            )
            return [dict(row) for row in result.mappings().all()]


pgvector_client = PgVectorClient()
