"""
SOLACE — Google Drive Storage Integration
Uploads reports and panel assessments as native Google Docs (fully searchable).
Creates and maintains the SOLACE folder structure automatically.
"""
from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload

from config import get_logger, settings

logger = get_logger("google_drive")

SCOPES = [
    "https://www.googleapis.com/auth/drive",
    "https://www.googleapis.com/auth/drive.file",
]

FOLDER_NAMES = {
    "root": "SOLACE Intelligence Agency",
    "reports": "Raw Reports",
    "assessments": "Panel Assessments",
    "cases": "Active Cases",
    "entities": "Entity Registry",
    "archive": "Archived",
}


class GoogleDriveClient:
    """Full Google Drive integration for SOLACE report storage.

    All reports are uploaded as native Google Docs for full-text search
    and NotebookLM indexing compatibility.
    """

    def __init__(self) -> None:
        self._service = None
        self._folder_ids: dict[str, str] = {}

    def _get_service(self):
        """Lazy-initialize the Drive API service."""
        if self._service is None:
            cred_path = settings.google_drive_credentials_json
            if not Path(cred_path).exists():
                raise FileNotFoundError(f"Google credentials not found: {cred_path}")
            creds = service_account.Credentials.from_service_account_file(
                str(cred_path), scopes=SCOPES
            )
            self._service = build("drive", "v3", credentials=creds)
        return self._service

    async def ensure_folder_structure(self) -> dict[str, str]:
        """Create the SOLACE folder structure if it doesn't exist.

        Returns:
            Dict mapping folder keys to Drive folder IDs.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._ensure_folder_structure_sync)

    def _ensure_folder_structure_sync(self) -> dict[str, str]:
        """Synchronous folder structure creation."""
        service = self._get_service()
        folder_ids: dict[str, str] = {}

        # Root folder
        root_id = settings.google_drive_root_folder_id
        if not root_id:
            root_id = self._create_folder(service, FOLDER_NAMES["root"], None)
            logger.info("created_root_folder", folder_id=root_id)
        folder_ids["root"] = root_id

        # Sub-folders
        for key, name in FOLDER_NAMES.items():
            if key == "root":
                continue
            existing_id = getattr(settings, f"google_drive_{key}_folder_id", "")
            if not existing_id:
                existing_id = self._create_folder(service, name, root_id)
                logger.info("created_subfolder", name=name, folder_id=existing_id)
            folder_ids[key] = existing_id

        self._folder_ids = folder_ids
        return folder_ids

    def _create_folder(self, service, name: str, parent_id: str | None) -> str:
        """Create a Drive folder and return its ID."""
        metadata: dict[str, Any] = {
            "name": name,
            "mimeType": "application/vnd.google-apps.folder",
        }
        if parent_id:
            metadata["parents"] = [parent_id]

        folder = service.files().create(body=metadata, fields="id").execute()
        return folder["id"]

    async def upload_report(
        self, report_id: str, markdown_content: str, properties: dict[str, str]
    ) -> str:
        """Upload an intelligence report as a native Google Doc.

        Args:
            report_id: The SOLACE report ID.
            markdown_content: Full markdown content of the report.
            properties: Metadata properties for Drive indexing.

        Returns:
            Google Drive file ID.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        folder_id = self._get_folder_id("reports")
        return await loop.run_in_executor(
            None, self._upload_doc, report_id, markdown_content, folder_id, properties
        )

    async def upload_assessment(
        self, session_id: str, assessment_content: str, properties: dict[str, str]
    ) -> str:
        """Upload a panel assessment as a native Google Doc.

        Args:
            session_id: The panel session ID.
            assessment_content: Full assessment markdown.
            properties: Metadata properties.

        Returns:
            Google Drive file ID.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        folder_id = self._get_folder_id("assessments")
        return await loop.run_in_executor(
            None, self._upload_doc, f"ASSESSMENT-{session_id}", assessment_content, folder_id, properties
        )

    def _upload_doc(
        self,
        doc_name: str,
        content: str,
        folder_id: str,
        properties: dict[str, str],
    ) -> str:
        """Synchronously upload a document to Drive."""
        service = self._get_service()

        metadata: dict[str, Any] = {
            "name": doc_name,
            "mimeType": "application/vnd.google-apps.document",
            "parents": [folder_id],
            "properties": properties,
            "description": f"SOLACE Intelligence Document — {doc_name}",
        }

        media = MediaIoBaseUpload(
            io.BytesIO(content.encode("utf-8")),
            mimetype="text/plain",
            resumable=False,
        )

        file = service.files().create(
            body=metadata,
            media_body=media,
            fields="id, name, webViewLink",
        ).execute()

        logger.info(
            "document_uploaded",
            doc_name=doc_name,
            file_id=file["id"],
            link=file.get("webViewLink"),
        )
        return file["id"]

    async def search_reports(self, query: str, max_results: int = 20) -> list[dict[str, str]]:
        """Search reports using Google Drive full-text search.

        Args:
            query: Search query string.
            max_results: Maximum results to return.

        Returns:
            List of file metadata dicts.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _search():
            service = self._get_service()
            folder_id = self._get_folder_id("reports")
            q = (
                f"'{folder_id}' in parents and "
                f"fullText contains '{query}' and trashed = false"
            )
            results = service.files().list(
                q=q,
                pageSize=max_results,
                fields="files(id, name, properties, createdTime, modifiedTime, webViewLink)",
            ).execute()
            return results.get("files", [])

        return await loop.run_in_executor(None, _search)

    async def get_file_content(self, file_id: str) -> str:
        """Download the content of a Drive file as plain text.

        Args:
            file_id: Google Drive file ID.

        Returns:
            File content as string.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _get():
            service = self._get_service()
            content = service.files().export(
                fileId=file_id, mimeType="text/plain"
            ).execute()
            if isinstance(content, bytes):
                return content.decode("utf-8")
            return str(content)

        return await loop.run_in_executor(None, _get)

    async def move_to_archive(self, file_id: str) -> None:
        """Move a file to the archive folder.

        Args:
            file_id: ID of the file to archive.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        archive_id = self._get_folder_id("archive")

        def _move():
            service = self._get_service()
            file = service.files().get(fileId=file_id, fields="parents").execute()
            previous_parents = ",".join(file.get("parents", []))
            service.files().update(
                fileId=file_id,
                addParents=archive_id,
                removeParents=previous_parents,
                fields="id, parents",
            ).execute()

        await loop.run_in_executor(None, _move)
        logger.info("file_archived", file_id=file_id)

    def _get_folder_id(self, key: str) -> str:
        """Get a folder ID from cache or settings."""
        if key in self._folder_ids:
            return self._folder_ids[key]
        # Fall back to settings
        attr = f"google_drive_{key}_folder_id"
        folder_id = getattr(settings, attr, "")
        if not folder_id:
            logger.warning("folder_id_not_configured", key=key)
            return ""
        return folder_id


drive_client = GoogleDriveClient()
