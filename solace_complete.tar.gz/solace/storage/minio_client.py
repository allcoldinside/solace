"""
SOLACE — MinIO Artifact Storage Client
S3-compatible object storage for documents, captures, and media.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

from config import get_logger, settings

logger = get_logger("minio_client")


class MinIOClient:
    """MinIO client for artifact and document storage."""

    def __init__(self) -> None:
        self._client = None

    def _get_client(self):
        if self._client is None:
            from minio import Minio
            self._client = Minio(
                settings.minio_endpoint,
                access_key=settings.minio_access_key,
                secret_key=settings.minio_secret_key,
                secure=False,  # Internal Docker network — TLS terminated at Caddy
            )
            # Ensure bucket exists
            try:
                if not self._client.bucket_exists(settings.minio_bucket):
                    self._client.make_bucket(settings.minio_bucket)
                    logger.info("minio_bucket_created", bucket=settings.minio_bucket)
            except Exception as exc:
                logger.warning("minio_bucket_check_failed", error=str(exc))
        return self._client

    async def upload_report_markdown(self, report_id: str, content: str) -> str:
        """Upload a report markdown file to MinIO.

        Args:
            report_id: SOLACE report ID (used as object key).
            content: Markdown content string.

        Returns:
            Object URL path.
        """
        import asyncio
        loop = asyncio.get_event_loop()
        object_name = f"reports/{report_id}.md"

        def _upload():
            client = self._get_client()
            data = content.encode("utf-8")
            client.put_object(
                settings.minio_bucket,
                object_name,
                io.BytesIO(data),
                length=len(data),
                content_type="text/markdown",
                metadata={"report_id": report_id},
            )
            return object_name

        try:
            result = await loop.run_in_executor(None, _upload)
            logger.info("report_uploaded_minio", report_id=report_id, object=result)
            return result
        except Exception as exc:
            logger.error("minio_upload_error", error=str(exc), report_id=report_id)
            return ""

    async def upload_file(self, object_name: str, file_path: str | Path,
                          content_type: str = "application/octet-stream") -> str:
        """Upload a file to MinIO.

        Args:
            object_name: Target object key.
            file_path: Local file path.
            content_type: MIME type.

        Returns:
            Object name on success.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _upload():
            client = self._get_client()
            client.fput_object(
                settings.minio_bucket,
                object_name,
                str(file_path),
                content_type=content_type,
            )
            return object_name

        try:
            return await loop.run_in_executor(None, _upload)
        except Exception as exc:
            logger.error("minio_file_upload_error", error=str(exc))
            return ""

    async def download_file(self, object_name: str) -> bytes | None:
        """Download an object from MinIO.

        Args:
            object_name: Object key to download.

        Returns:
            File bytes or None on failure.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _download():
            client = self._get_client()
            response = client.get_object(settings.minio_bucket, object_name)
            data = response.read()
            response.close()
            response.release_conn()
            return data

        try:
            return await loop.run_in_executor(None, _download)
        except Exception as exc:
            logger.error("minio_download_error", error=str(exc), object=object_name)
            return None

    async def list_objects(self, prefix: str = "") -> list[str]:
        """List objects in the SOLACE bucket.

        Args:
            prefix: Optional prefix filter.

        Returns:
            List of object names.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _list():
            client = self._get_client()
            objects = client.list_objects(settings.minio_bucket, prefix=prefix, recursive=True)
            return [obj.object_name for obj in objects]

        try:
            return await loop.run_in_executor(None, _list)
        except Exception as exc:
            logger.error("minio_list_error", error=str(exc))
            return []

    async def get_presigned_url(self, object_name: str, expires_hours: int = 24) -> str:
        """Generate a presigned URL for temporary access to an object.

        Args:
            object_name: Object key.
            expires_hours: URL expiry in hours.

        Returns:
            Presigned URL string.
        """
        import asyncio
        from datetime import timedelta
        loop = asyncio.get_event_loop()

        def _presign():
            client = self._get_client()
            return client.presigned_get_object(
                settings.minio_bucket,
                object_name,
                expires=timedelta(hours=expires_hours),
            )

        try:
            return await loop.run_in_executor(None, _presign)
        except Exception as exc:
            logger.error("minio_presign_error", error=str(exc))
            return ""


minio_client = MinIOClient()
