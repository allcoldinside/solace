"""
SOLACE — Neo4j Entity Graph Client
Stores and queries entity relationships in a property graph.
"""
from __future__ import annotations

from typing import Any

from config import get_logger, settings

logger = get_logger("neo4j_client")


class Neo4jClient:
    """Neo4j client for entity relationship graph operations."""

    def __init__(self) -> None:
        self._driver = None

    def _get_driver(self):
        if self._driver is None:
            from neo4j import GraphDatabase
            self._driver = GraphDatabase.driver(
                settings.neo4j_url,
                auth=(settings.neo4j_user, settings.neo4j_password),
            )
        return self._driver

    async def close(self) -> None:
        if self._driver:
            self._driver.close()
            self._driver = None

    async def upsert_entity(self, entity_id: str, entity_type: str,
                             name: str, properties: dict[str, Any] | None = None) -> None:
        """Create or update an entity node.

        Args:
            entity_id: Unique entity ID.
            entity_type: Entity type label.
            name: Display name.
            properties: Additional properties dict.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _run():
            driver = self._get_driver()
            with driver.session() as session:
                props = properties or {}
                props.update({"id": entity_id, "name": name})
                session.run(
                    f"""
                    MERGE (e:{entity_type} {{id: $id}})
                    SET e += $props
                    SET e.updated_at = datetime()
                    """,
                    id=entity_id, props=props,
                )

        try:
            await loop.run_in_executor(None, _run)
        except Exception as exc:
            logger.error("neo4j_upsert_entity_error", error=str(exc), entity_id=entity_id)

    async def upsert_relationship(self, source_id: str, target_id: str,
                                   rel_type: str, properties: dict | None = None) -> None:
        """Create or update a directed relationship between entities.

        Args:
            source_id: Source entity ID.
            target_id: Target entity ID.
            rel_type: Relationship type (e.g. LINKED_TO, EMPLOYS, CONTROLS).
            properties: Relationship properties.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _run():
            driver = self._get_driver()
            with driver.session() as session:
                props = properties or {}
                session.run(
                    f"""
                    MATCH (a {{id: $source_id}})
                    MATCH (b {{id: $target_id}})
                    MERGE (a)-[r:{rel_type}]->(b)
                    SET r += $props
                    SET r.updated_at = datetime()
                    """,
                    source_id=source_id, target_id=target_id, props=props,
                )

        try:
            await loop.run_in_executor(None, _run)
        except Exception as exc:
            logger.error("neo4j_upsert_relationship_error", error=str(exc))

    async def get_entity_network(self, entity_id: str, depth: int = 2) -> dict[str, Any]:
        """Get the relationship network around an entity.

        Args:
            entity_id: Central entity ID.
            depth: Traversal depth (hops).

        Returns:
            Dict with nodes and relationships.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _run():
            driver = self._get_driver()
            with driver.session() as session:
                result = session.run(
                    f"""
                    MATCH path = (e {{id: $entity_id}})-[*1..{depth}]-(connected)
                    RETURN nodes(path) as nodes, relationships(path) as rels
                    LIMIT 100
                    """,
                    entity_id=entity_id,
                )
                nodes = []
                edges = []
                seen_nodes = set()
                seen_edges = set()

                for record in result:
                    for node in record["nodes"]:
                        nid = str(node.id)
                        if nid not in seen_nodes:
                            seen_nodes.add(nid)
                            nodes.append(dict(node.items()) | {"_id": nid,
                                         "_labels": list(node.labels)})
                    for rel in record["rels"]:
                        rid = str(rel.id)
                        if rid not in seen_edges:
                            seen_edges.add(rid)
                            edges.append({
                                "_id": rid,
                                "_type": rel.type,
                                "_start": str(rel.start_node.id),
                                "_end": str(rel.end_node.id),
                                **dict(rel.items()),
                            })

                return {"nodes": nodes, "relationships": edges}

        try:
            return await loop.run_in_executor(None, _run)
        except Exception as exc:
            logger.error("neo4j_get_network_error", error=str(exc))
            return {"nodes": [], "relationships": []}

    async def build_entity_graph_from_report(self, report_id: str,
                                              entity_map: dict[str, list[str]]) -> None:
        """Populate the graph from a report's entity map.

        Args:
            report_id: Source report ID (for provenance).
            entity_map: Dict of {entity_type: [entity_names]}.
        """
        import uuid

        type_map = {
            "people": "Person",
            "organizations": "Organization",
            "locations": "Location",
            "infrastructure": "Infrastructure",
            "misc": "Entity",
        }

        entity_ids: dict[str, str] = {}

        # Create entity nodes
        for category, entities in entity_map.items():
            neo4j_type = type_map.get(category, "Entity")
            for name in entities:
                eid = str(uuid.uuid5(uuid.NAMESPACE_DNS, name.lower().strip()))
                entity_ids[name] = eid
                await self.upsert_entity(
                    entity_id=eid,
                    entity_type=neo4j_type,
                    name=name,
                    properties={"source_report": report_id},
                )

        # Create co-occurrence relationships (entities in the same report are related)
        entity_list = list(entity_ids.items())
        for i, (name_a, id_a) in enumerate(entity_list):
            for name_b, id_b in entity_list[i+1:i+4]:  # Link to next 3 only
                await self.upsert_relationship(
                    source_id=id_a,
                    target_id=id_b,
                    rel_type="CO_OCCURS_WITH",
                    properties={"report_id": report_id, "strength": 0.5},
                )

        logger.info("entity_graph_built", report_id=report_id,
                    entity_count=len(entity_ids))


neo4j_client = Neo4jClient()
