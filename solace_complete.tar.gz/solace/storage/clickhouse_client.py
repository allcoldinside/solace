"""
SOLACE — ClickHouse Analytics Client
Time-series event storage for high-volume collection metrics and IOC events.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from config import get_logger, settings

logger = get_logger("clickhouse_client")

CREATE_TABLES_SQL = [
    """
    CREATE TABLE IF NOT EXISTS solace.collection_events (
        event_time    DateTime DEFAULT now(),
        collector_id  String,
        target        String,
        target_type   String,
        items_count   UInt32,
        duration_ms   UInt32,
        errors_count  UInt16,
        status        String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(event_time)
    ORDER BY (event_time, collector_id);
    """,
    """
    CREATE TABLE IF NOT EXISTS solace.panel_events (
        event_time    DateTime DEFAULT now(),
        session_id    String,
        report_id     String,
        round_number  UInt8,
        analyst       String,
        content_len   UInt32,
        is_loop       UInt8,
        event_type    String
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(event_time)
    ORDER BY (event_time, session_id, round_number);
    """,
    """
    CREATE TABLE IF NOT EXISTS solace.ioc_events (
        event_time    DateTime DEFAULT now(),
        ioc_type      String,
        ioc_value     String,
        source        String,
        malicious_score Float32,
        report_id     String,
        tags          Array(String)
    ) ENGINE = MergeTree()
    PARTITION BY toYYYYMM(event_time)
    ORDER BY (event_time, ioc_type, ioc_value);
    """,
]


class ClickHouseClient:
    """ClickHouse client for time-series analytics writes."""

    def __init__(self) -> None:
        self._client = None

    def _get_client(self):
        if self._client is None:
            import clickhouse_connect
            self._client = clickhouse_connect.get_client(
                host=settings.clickhouse_host,
                port=settings.clickhouse_port,
                database=settings.clickhouse_db,
                username=settings.clickhouse_user,
                password=settings.clickhouse_password,
            )
        return self._client

    async def init_tables(self) -> None:
        """Create ClickHouse tables if they don't exist."""
        import asyncio
        loop = asyncio.get_event_loop()

        def _create():
            client = self._get_client()
            client.command(f"CREATE DATABASE IF NOT EXISTS {settings.clickhouse_db}")
            for sql in CREATE_TABLES_SQL:
                client.command(sql)

        try:
            await loop.run_in_executor(None, _create)
            logger.info("clickhouse_tables_initialized")
        except Exception as exc:
            logger.error("clickhouse_init_error", error=str(exc))

    async def record_collection_event(
        self,
        collector_id: str,
        target: str,
        target_type: str,
        items_count: int,
        duration_ms: int,
        errors_count: int = 0,
        status: str = "complete",
    ) -> None:
        """Record a collection event for analytics.

        Args:
            collector_id: Spider bot ID.
            target: Collection target.
            target_type: Target type string.
            items_count: Number of items collected.
            duration_ms: Duration in milliseconds.
            errors_count: Number of errors encountered.
            status: Completion status.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _insert():
            client = self._get_client()
            client.insert(
                "collection_events",
                [[datetime.utcnow(), collector_id, target, target_type,
                  items_count, duration_ms, errors_count, status]],
                column_names=["event_time", "collector_id", "target", "target_type",
                              "items_count", "duration_ms", "errors_count", "status"],
            )

        try:
            await loop.run_in_executor(None, _insert)
        except Exception as exc:
            logger.debug("clickhouse_insert_error", error=str(exc))

    async def record_panel_event(
        self,
        session_id: str,
        report_id: str,
        round_number: int,
        analyst: str,
        content_len: int,
        is_loop: bool = False,
        event_type: str = "turn",
    ) -> None:
        """Record a panel session event.

        Args:
            session_id: Panel session ID.
            report_id: Linked report ID.
            round_number: Current round.
            analyst: Analyst identifier.
            content_len: Length of content.
            is_loop: Whether this was a loop-flagged turn.
            event_type: Event classification.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _insert():
            client = self._get_client()
            client.insert(
                "panel_events",
                [[datetime.utcnow(), session_id, report_id, round_number,
                  analyst, content_len, int(is_loop), event_type]],
                column_names=["event_time", "session_id", "report_id",
                              "round_number", "analyst", "content_len",
                              "is_loop", "event_type"],
            )

        try:
            await loop.run_in_executor(None, _insert)
        except Exception as exc:
            logger.debug("clickhouse_panel_insert_error", error=str(exc))

    async def get_collection_stats(
        self, hours: int = 24
    ) -> dict[str, Any]:
        """Get collection statistics for the last N hours.

        Args:
            hours: Lookback window in hours.

        Returns:
            Stats dict.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        def _query():
            client = self._get_client()
            result = client.query(f"""
                SELECT
                    collector_id,
                    count() as runs,
                    sum(items_count) as total_items,
                    avg(duration_ms) as avg_duration_ms,
                    sum(errors_count) as total_errors
                FROM collection_events
                WHERE event_time >= now() - INTERVAL {hours} HOUR
                GROUP BY collector_id
                ORDER BY total_items DESC
            """)
            return {
                "period_hours": hours,
                "collectors": [
                    dict(zip(result.column_names, row))
                    for row in result.result_rows
                ],
            }

        try:
            return await loop.run_in_executor(None, _query)
        except Exception as exc:
            logger.error("clickhouse_stats_error", error=str(exc))
            return {"period_hours": hours, "collectors": []}


clickhouse_client = ClickHouseClient()
