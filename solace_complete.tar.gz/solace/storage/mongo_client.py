"""
SOLACE — MongoDB Raw Document Store Client
Stores full raw collected items and bulk intel documents.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from config import get_logger, settings

logger = get_logger("mongo_client")


class MongoClient:
    """Async MongoDB client for raw document storage."""

    def __init__(self) -> None:
        self._client = None
        self._db = None

    def _get_db(self):
        if self._client is None:
            from motor.motor_asyncio import AsyncIOMotorClient
            self._client = AsyncIOMotorClient(settings.mongodb_url)
            self._db = self._client.solace
        return self._db

    async def store_raw_items(self, report_id: str,
                               items: list[dict[str, Any]]) -> int:
        """Store raw collected items for a report.

        Args:
            report_id: Associated report ID.
            items: List of raw item dicts to store.

        Returns:
            Count of items stored.
        """
        try:
            db = self._get_db()
            docs = [
                {**item, "report_id": report_id, "stored_at": datetime.utcnow()}
                for item in items
            ]
            if docs:
                result = await db.raw_intel.insert_many(docs)
                logger.info("raw_items_stored", report_id=report_id,
                            count=len(result.inserted_ids))
                return len(result.inserted_ids)
        except Exception as exc:
            logger.error("mongo_store_error", error=str(exc), report_id=report_id)
        return 0

    async def get_raw_items(self, report_id: str) -> list[dict[str, Any]]:
        """Retrieve raw items for a report.

        Args:
            report_id: Report ID to retrieve items for.

        Returns:
            List of raw item documents.
        """
        try:
            db = self._get_db()
            cursor = db.raw_intel.find({"report_id": report_id}, {"_id": 0})
            return await cursor.to_list(length=1000)
        except Exception as exc:
            logger.error("mongo_get_error", error=str(exc))
            return []

    async def store_artifact(self, artifact_type: str,
                              data: dict[str, Any]) -> str | None:
        """Store an arbitrary artifact document.

        Args:
            artifact_type: Type label for the artifact.
            data: Document data to store.

        Returns:
            Inserted document ID string, or None on failure.
        """
        try:
            db = self._get_db()
            doc = {**data, "artifact_type": artifact_type,
                   "stored_at": datetime.utcnow()}
            result = await db.artifacts.insert_one(doc)
            return str(result.inserted_id)
        except Exception as exc:
            logger.error("mongo_artifact_store_error", error=str(exc))
            return None

    async def search_raw_items(self, query: str,
                                limit: int = 50) -> list[dict[str, Any]]:
        """Full-text search over stored raw items using MongoDB text index.

        Args:
            query: Search query string.
            limit: Maximum results.

        Returns:
            Matching raw items.
        """
        try:
            db = self._get_db()
            # Ensure text index exists
            await db.raw_intel.create_index([("content", "text")])
            cursor = db.raw_intel.find(
                {"$text": {"$search": query}},
                {"score": {"$meta": "textScore"}, "_id": 0},
            ).sort([("score", {"$meta": "textScore"})]).limit(limit)
            return await cursor.to_list(length=limit)
        except Exception as exc:
            logger.error("mongo_search_error", error=str(exc))
            return []

    async def get_collection_stats(self) -> dict[str, Any]:
        """Get MongoDB collection statistics.

        Returns:
            Dict with document counts per collection.
        """
        try:
            db = self._get_db()
            return {
                "raw_intel": await db.raw_intel.count_documents({}),
                "artifacts": await db.artifacts.count_documents({}),
            }
        except Exception as exc:
            logger.error("mongo_stats_error", error=str(exc))
            return {}


mongo_client = MongoClient()
