"""
SOLACE — SPIDER-8: Threat Intelligence Feed Collector
Sources: OTX AlienVault, VirusTotal, AbuseIPDB, GreyNoise.
"""
from __future__ import annotations

import re
import time
from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, TargetType
from config import settings


class SpiderThreat(BaseCollector):
    """SPIDER-8: Threat intelligence feed aggregator.

    Queries major threat intelligence platforms for IOCs, threat actors,
    malware samples, and network abuse data related to the target.
    """

    bot_id = "SPIDER-8"
    domain = "threat_feeds"
    rate_limit = 0.5
    source_reliability = 0.88

    async def validate_target(self, target: str) -> bool:
        """Valid for all targets."""
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect threat intelligence for the target.

        Args:
            target: Subject to search threat feeds for.
            target_type: Target classification.

        Returns:
            CollectionResult with threat intelligence.
        """
        start = time.monotonic()
        items, errors = [], []

        async with self:
            if settings.alienvault_otx_api_key:
                otx_items, otx_errs = await self._collect_otx(target)
                items.extend(otx_items)
                errors.extend(otx_errs)

            if settings.virustotal_api_key:
                vt_items, vt_errs = await self._collect_virustotal(target)
                items.extend(vt_items)
                errors.extend(vt_errs)

            if re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
                abuse_items, abuse_errs = await self._collect_abuseipdb(target)
                items.extend(abuse_items)
                errors.extend(abuse_errs)

                if settings.greynoise_api_key:
                    gn_items, gn_errs = await self._collect_greynoise(target)
                    items.extend(gn_items)
                    errors.extend(gn_errs)

        return self._build_result(target, target_type.value, items,
                                  time.monotonic() - start, errors)

    async def _collect_otx(self, target: str) -> tuple[list, list]:
        """Query OTX AlienVault for pulses mentioning the target."""
        items, errors = [], []
        try:
            headers = {"X-OTX-API-KEY": settings.alienvault_otx_api_key}
            data = await self._fetch(
                f"https://otx.alienvault.com/api/v1/search/pulses?q={target}&limit=5",
                headers=headers,
            )
            if not data or not isinstance(data, dict):
                return items, errors
            for pulse in data.get("results", [])[:5]:
                content = (
                    f"OTX Pulse: {pulse.get('name')}\n"
                    f"  Description: {pulse.get('description', '')[:500]}\n"
                    f"  TLP: {pulse.get('tlp')}\n"
                    f"  Tags: {pulse.get('tags')}\n"
                    f"  Indicators: {len(pulse.get('indicators', []))}"
                )
                items.append(self._build_item(
                    content=content,
                    source_url=f"https://otx.alienvault.com/pulse/{pulse.get('id')}",
                    source_type="otx_alienvault", target=target, target_type="threat",
                    reliability_score=0.85,
                    metadata={"pulse_id": pulse.get("id"), "tlp": pulse.get("tlp")},
                ))
        except Exception as exc:
            errors.append(f"OTX error: {exc}")
        return items, errors

    async def _collect_virustotal(self, target: str) -> tuple[list, list]:
        """Query VirusTotal for threat data."""
        items, errors = [], []
        try:
            headers = {"x-apikey": settings.virustotal_api_key}
            data = await self._fetch(
                f"https://www.virustotal.com/api/v3/search?query={target}&limit=5",
                headers=headers,
            )
            if not data or not isinstance(data, dict):
                return items, errors
            for item in data.get("data", [])[:5]:
                attrs = item.get("attributes", {})
                content = (
                    f"VirusTotal: {item.get('type')} - {item.get('id')}\n"
                    f"  Stats: {attrs.get('last_analysis_stats', {})}\n"
                    f"  Reputation: {attrs.get('reputation')}"
                )
                items.append(self._build_item(
                    content=content,
                    source_url=f"https://www.virustotal.com/gui/{item.get('type')}/{item.get('id')}",
                    source_type="virustotal", target=target, target_type="threat",
                    reliability_score=0.90,
                    metadata={"vt_id": item.get("id"), "vt_type": item.get("type")},
                ))
        except Exception as exc:
            errors.append(f"VirusTotal error: {exc}")
        return items, errors

    async def _collect_abuseipdb(self, target: str) -> tuple[list, list]:
        """Query AbuseIPDB for IP reputation data."""
        items, errors = [], []
        try:
            headers = {"Key": "public", "Accept": "application/json"}
            data = await self._fetch(
                f"https://api.abuseipdb.com/api/v2/check?ipAddress={target}&maxAgeInDays=90",
                headers=headers,
            )
            if not data or not isinstance(data, dict):
                return items, errors
            d = data.get("data", {})
            content = (
                f"AbuseIPDB: {target}\n"
                f"  Abuse Score: {d.get('abuseConfidenceScore')}\n"
                f"  Country: {d.get('countryCode')}\n"
                f"  ISP: {d.get('isp')}\n"
                f"  Total Reports: {d.get('totalReports')}\n"
                f"  Last Reported: {d.get('lastReportedAt')}"
            )
            items.append(self._build_item(
                content=content,
                source_url=f"https://www.abuseipdb.com/check/{target}",
                source_type="abuseipdb", target=target, target_type="threat",
                reliability_score=0.88, metadata=d,
            ))
        except Exception as exc:
            errors.append(f"AbuseIPDB error: {exc}")
        return items, errors

    async def _collect_greynoise(self, target: str) -> tuple[list, list]:
        """Query GreyNoise for IP noise classification."""
        items, errors = [], []
        try:
            headers = {"key": settings.greynoise_api_key}
            data = await self._fetch(
                f"https://api.greynoise.io/v3/community/{target}", headers=headers
            )
            if not data or not isinstance(data, dict):
                return items, errors
            content = (
                f"GreyNoise: {target}\n"
                f"  Noise: {data.get('noise')}\n"
                f"  Riot: {data.get('riot')}\n"
                f"  Classification: {data.get('classification')}\n"
                f"  Name: {data.get('name')}\n"
                f"  Message: {data.get('message')}"
            )
            items.append(self._build_item(
                content=content,
                source_url=f"https://viz.greynoise.io/ip/{target}",
                source_type="greynoise", target=target, target_type="threat",
                reliability_score=0.88, metadata=data,
            ))
        except Exception as exc:
            errors.append(f"GreyNoise error: {exc}")
        return items, errors
