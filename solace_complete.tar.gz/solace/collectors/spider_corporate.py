"""
SOLACE — SPIDER-5: Corporate & Financial Intelligence Collector
Sources: OpenCorporates, SEC EDGAR, OpenSanctions.
"""
from __future__ import annotations

import time
from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, TargetType
from config import settings


class SpiderCorporate(BaseCollector):
    """SPIDER-5: Corporate and financial intelligence collector."""

    bot_id = "SPIDER-5"
    domain = "corporate_financial"
    rate_limit = 1.0
    source_reliability = 0.92

    async def validate_target(self, target: str) -> bool:
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        start = time.monotonic()
        items, errors = [], []

        async with self:
            oc_items, oc_errs = await self._collect_opencorporates(target)
            items.extend(oc_items)
            errors.extend(oc_errs)

            edgar_items, edgar_errs = await self._collect_edgar(target)
            items.extend(edgar_items)
            errors.extend(edgar_errs)

            sanctions_items, sanctions_errs = await self._collect_opensanctions(target)
            items.extend(sanctions_items)
            errors.extend(sanctions_errs)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_opencorporates(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            params = {"q": target, "format": "json"}
            if settings.opencorporates_api_key:
                params["api_token"] = settings.opencorporates_api_key
            data = await self._fetch("https://api.opencorporates.com/v0.4/companies/search", params=params)
            if not data or not isinstance(data, dict):
                return items, errors
            for company in data.get("results", {}).get("companies", [])[:5]:
                c = company.get("company", {})
                content = (f"Company: {c.get('name')}\n  Jurisdiction: {c.get('jurisdiction_code')}\n"
                           f"  Company Number: {c.get('company_number')}\n  Status: {c.get('current_status')}\n"
                           f"  Incorporated: {c.get('incorporation_date')}\n  Registered Address: {c.get('registered_address_in_full')}")
                items.append(self._build_item(
                    content=content, source_url=c.get("opencorporates_url"),
                    source_type="opencorporates", target=target, target_type="corporate",
                    reliability_score=0.92, metadata=c,
                ))
        except Exception as exc:
            errors.append(f"OpenCorporates error: {exc}")
        return items, errors

    async def _collect_edgar(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            params = {"q": f'"{target}"', "dateRange": "custom", "startdt": "2020-01-01", "forms": "10-K,8-K,20-F"}
            data = await self._fetch("https://efts.sec.gov/LATEST/search-index?q={q}&forms={forms}".format(**params) if False else
                                     f"https://efts.sec.gov/LATEST/search-index?q=%22{target.replace(' ', '%20')}%22&forms=10-K,8-K,20-F")
            if not data or not isinstance(data, dict):
                return items, errors
            for hit in data.get("hits", {}).get("hits", [])[:5]:
                src = hit.get("_source", {})
                content = (f"SEC Filing: {src.get('form_type')}\n  Company: {src.get('display_names')}\n"
                           f"  Filed: {src.get('file_date')}\n  Description: {src.get('entity_name')}\n"
                           f"  Period: {src.get('period_of_report')}")
                items.append(self._build_item(
                    content=content,
                    source_url=f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&company={target}&type=10-K",
                    source_type="sec_edgar", target=target, target_type="financial",
                    reliability_score=0.97, metadata=src,
                ))
        except Exception as exc:
            errors.append(f"EDGAR error: {exc}")
        return items, errors

    async def _collect_opensanctions(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            data = await self._fetch(f"https://api.opensanctions.org/search/default?q={target}&limit=5")
            if not data or not isinstance(data, dict):
                return items, errors
            for result in data.get("results", []):
                if result.get("score", 0) < 0.5:
                    continue
                content = (f"OpenSanctions Match:\n  Name: {result.get('caption')}\n"
                           f"  Schema: {result.get('schema')}\n  Score: {result.get('score')}\n"
                           f"  Datasets: {result.get('datasets')}\n  Properties: {str(result.get('properties', {}))[:500]}")
                items.append(self._build_item(
                    content=content, source_url=f"https://www.opensanctions.org/entities/{result.get('id')}/",
                    source_type="opensanctions", target=target, target_type="sanctions_pep",
                    reliability_score=0.95, metadata={"entity_id": result.get("id"), "score": result.get("score")},
                ))
        except Exception as exc:
            errors.append(f"OpenSanctions error: {exc}")
        return items, errors


# ─────────────────────────────────────────────────────────────────────────────


class SpiderDocuments(BaseCollector):
    """SPIDER-7: Document and leak intelligence collector.
    Sources: CISA advisories, public document repositories, metadata extraction.
    """

    bot_id = "SPIDER-7"
    domain = "documents_leaks"
    rate_limit = 1.5
    source_reliability = 0.8

    async def validate_target(self, target: str) -> bool:
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        start = time.monotonic()
        items, errors = [], []

        async with self:
            cisa_items, cisa_errs = await self._collect_cisa(target)
            items.extend(cisa_items)
            errors.extend(cisa_errs)

            doc_items, doc_errs = await self._collect_document_search(target)
            items.extend(doc_items)
            errors.extend(doc_errs)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_cisa(self, target: str) -> tuple[list, list]:
        import feedparser
        items, errors = [], []
        try:
            raw = await self._fetch("https://www.cisa.gov/cybersecurity-advisories/all.xml")
            if raw:
                feed = feedparser.parse(raw)
                for entry in feed.entries[:30]:
                    title = entry.get("title", "")
                    summary = entry.get("summary", "")
                    if target.lower() in (title + summary).lower():
                        content = f"CISA Advisory: {title}\n{summary[:1000]}"
                        items.append(self._build_item(
                            content=content, source_url=entry.get("link"),
                            source_type="cisa_advisory", target=target, target_type="threat",
                            reliability_score=0.98,
                            metadata={"published": entry.get("published"), "title": title},
                        ))
        except Exception as exc:
            errors.append(f"CISA error: {exc}")
        return items, errors

    async def _collect_document_search(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            encoded = target.replace(" ", "+")
            data = await self._fetch(
                f"https://api.semanticscholar.org/graph/v1/paper/search?query={encoded}&limit=5&fields=title,abstract,year,authors,venue"
            )
            if data and isinstance(data, dict):
                for paper in data.get("data", [])[:5]:
                    content = (f"Academic Paper: {paper.get('title')}\n"
                               f"  Year: {paper.get('year')}\n  Venue: {paper.get('venue')}\n"
                               f"  Authors: {[a.get('name') for a in paper.get('authors', [])]}\n"
                               f"  Abstract: {paper.get('abstract', '')[:800]}")
                    items.append(self._build_item(
                        content=content, source_url=f"https://www.semanticscholar.org/paper/{paper.get('paperId')}",
                        source_type="academic_paper", target=target, target_type="document",
                        reliability_score=0.85, metadata=paper,
                    ))
        except Exception as exc:
            errors.append(f"Document search error: {exc}")
        return items, errors


# ─────────────────────────────────────────────────────────────────────────────


class SpiderThreat(BaseCollector):
    """SPIDER-8: Threat intelligence feed collector.
    Sources: OTX AlienVault, Abuse.ch, VirusTotal, GreyNoise.
    """

    bot_id = "SPIDER-8"
    domain = "threat_feeds"
    rate_limit = 0.5
    source_reliability = 0.88

    async def validate_target(self, target: str) -> bool:
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        start = time.monotonic()
        items, errors = [], []

        async with self:
            if settings.alienvault_otx_api_key:
                otx_items, otx_errs = await self._collect_otx(target)
                items.extend(otx_items)
                errors.extend(otx_errs)

            if settings.virustotal_api_key:
                vt_items, vt_errs = await self._collect_virustotal(target)
                items.extend(vt_items)
                errors.extend(vt_errs)

            abuse_items, abuse_errs = await self._collect_abuseipdb(target)
            items.extend(abuse_items)
            errors.extend(abuse_errs)

            if settings.greynoise_api_key:
                gn_items, gn_errs = await self._collect_greynoise(target)
                items.extend(gn_items)
                errors.extend(gn_errs)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_otx(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            headers = {"X-OTX-API-KEY": settings.alienvault_otx_api_key}
            data = await self._fetch(f"https://otx.alienvault.com/api/v1/search/pulses?q={target}&limit=5", headers=headers)
            if data and isinstance(data, dict):
                for pulse in data.get("results", [])[:5]:
                    content = (f"OTX Pulse: {pulse.get('name')}\n  Description: {pulse.get('description', '')[:500]}\n"
                               f"  TLP: {pulse.get('tlp')}\n  Tags: {pulse.get('tags')}\n"
                               f"  Indicators: {len(pulse.get('indicators', []))}")
                    items.append(self._build_item(
                        content=content, source_url=f"https://otx.alienvault.com/pulse/{pulse.get('id')}",
                        source_type="otx_alienvault", target=target, target_type="threat",
                        reliability_score=0.85, metadata={"pulse_id": pulse.get("id"), "tlp": pulse.get("tlp")},
                    ))
        except Exception as exc:
            errors.append(f"OTX error: {exc}")
        return items, errors

    async def _collect_virustotal(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            headers = {"x-apikey": settings.virustotal_api_key}
            data = await self._fetch(f"https://www.virustotal.com/api/v3/search?query={target}&limit=5", headers=headers)
            if data and isinstance(data, dict):
                for item in data.get("data", [])[:5]:
                    attrs = item.get("attributes", {})
                    content = (f"VirusTotal: {item.get('type')} - {item.get('id')}\n"
                               f"  Stats: {attrs.get('last_analysis_stats', {})}\n"
                               f"  Reputation: {attrs.get('reputation')}")
                    items.append(self._build_item(
                        content=content, source_url=f"https://www.virustotal.com/gui/{item.get('type')}/{item.get('id')}",
                        source_type="virustotal", target=target, target_type="threat",
                        reliability_score=0.9, metadata={"vt_id": item.get("id"), "vt_type": item.get("type")},
                    ))
        except Exception as exc:
            errors.append(f"VirusTotal error: {exc}")
        return items, errors

    async def _collect_abuseipdb(self, target: str) -> tuple[list, list]:
        import re
        items, errors = [], []
        try:
            # Only query if target looks like an IP
            if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
                return items, errors
            headers = {"Key": "public", "Accept": "application/json"}
            data = await self._fetch(
                f"https://api.abuseipdb.com/api/v2/check?ipAddress={target}&maxAgeInDays=90",
                headers=headers,
            )
            if data and isinstance(data, dict):
                d = data.get("data", {})
                content = (f"AbuseIPDB: {target}\n  Abuse Score: {d.get('abuseConfidenceScore')}\n"
                           f"  Country: {d.get('countryCode')}\n  ISP: {d.get('isp')}\n"
                           f"  Total Reports: {d.get('totalReports')}\n  Last Reported: {d.get('lastReportedAt')}")
                items.append(self._build_item(
                    content=content, source_url=f"https://www.abuseipdb.com/check/{target}",
                    source_type="abuseipdb", target=target, target_type="threat",
                    reliability_score=0.88, metadata=d,
                ))
        except Exception as exc:
            errors.append(f"AbuseIPDB error: {exc}")
        return items, errors

    async def _collect_greynoise(self, target: str) -> tuple[list, list]:
        import re
        items, errors = [], []
        try:
            if not re.match(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$', target):
                return items, errors
            headers = {"key": settings.greynoise_api_key}
            data = await self._fetch(f"https://api.greynoise.io/v3/community/{target}", headers=headers)
            if data and isinstance(data, dict):
                content = (f"GreyNoise: {target}\n  Noise: {data.get('noise')}\n"
                           f"  Riot: {data.get('riot')}\n  Classification: {data.get('classification')}\n"
                           f"  Name: {data.get('name')}\n  Message: {data.get('message')}")
                items.append(self._build_item(
                    content=content, source_url=f"https://viz.greynoise.io/ip/{target}",
                    source_type="greynoise", target=target, target_type="threat",
                    reliability_score=0.88, metadata=data,
                ))
        except Exception as exc:
            errors.append(f"GreyNoise error: {exc}")
        return items, errors
