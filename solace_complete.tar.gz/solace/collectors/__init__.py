"""SOLACE collectors — spider bot team.

All spiders are imported lazily to avoid requiring collector-specific
dependencies (trafilatura, praw, dnspython, etc.) in test/minimal environments.
"""
from collectors.base_collector import BaseCollector
from collectors.aggregator import AggregatorBot, aggregator


def get_spider(spider_id: str):
    """Lazy factory — returns an instantiated spider bot by ID.

    Does NOT import the spider module until this function is called,
    so missing optional dependencies (trafilatura, praw, etc.) don't
    break the package import in test environments.

    Args:
        spider_id: Spider bot ID e.g. 'SPIDER-1' through 'SPIDER-8'.

    Returns:
        Instantiated spider collector.

    Raises:
        ValueError: If spider_id is not recognized.
        ImportError: If the spider's optional dependency is not installed.
    """
    if spider_id == "SPIDER-1":
        from collectors.spider_web_news import SpiderWebNews
        return SpiderWebNews()
    elif spider_id == "SPIDER-2":
        from collectors.spider_social import SpiderSocial
        return SpiderSocial()
    elif spider_id == "SPIDER-3":
        from collectors.spider_network import SpiderNetwork
        return SpiderNetwork()
    elif spider_id == "SPIDER-4":
        from collectors.spider_darkweb import SpiderDarkWeb
        return SpiderDarkWeb()
    elif spider_id == "SPIDER-5":
        from collectors.spider_corporate import SpiderCorporate
        return SpiderCorporate()
    elif spider_id == "SPIDER-6":
        from collectors.spider_geo import SpiderGeo
        return SpiderGeo()
    elif spider_id == "SPIDER-7":
        from collectors.spider_documents import SpiderDocuments
        return SpiderDocuments()
    elif spider_id == "SPIDER-8":
        from collectors.spider_threat import SpiderThreat
        return SpiderThreat()
    else:
        raise ValueError(f"Unknown spider ID: {spider_id}. Valid: SPIDER-1 through SPIDER-8")


def get_all_spiders():
    """Instantiate all 8 spider bots and return as a list.

    Each spider is imported lazily — if a spider's dependency is missing
    (e.g. trafilatura for SPIDER-1), an ImportError is raised for that spider
    only. Other spiders are unaffected.

    Returns:
        List of instantiated spider collectors (up to 8).
    """
    spiders = []
    for spider_id in [f"SPIDER-{i}" for i in range(1, 9)]:
        try:
            spiders.append(get_spider(spider_id))
        except ImportError as exc:
            import structlog
            log = structlog.get_logger(component="collectors")
            log.warning("spider_dependency_missing", spider_id=spider_id, error=str(exc))
    return spiders


__all__ = [
    "BaseCollector",
    "AggregatorBot",
    "aggregator",
    "get_spider",
    "get_all_spiders",
]
