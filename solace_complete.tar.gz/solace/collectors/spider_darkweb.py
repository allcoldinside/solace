"""
SOLACE — SPIDER-4: Dark Web Monitor
Collects intelligence from .onion sites via Tor SOCKS5 proxy.
Runs in an isolated Docker network (tor_net) — never on solace_net.

SECURITY NOTE: This spider only ever connects through Tor.
The tor service has no access to solace_net by design.
"""
from __future__ import annotations

import time
from typing import Any

from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType
from config import settings, get_logger

logger = get_logger("SPIDER-4")


class SpiderDarkWeb(BaseCollector):
    """SPIDER-4: Tor dark web intelligence collector.

    Only activates when TOR_SOCKS_PROXY is configured and reachable.
    All requests are routed through Tor — never direct.
    Source reliability is deliberately low (0.40) — unverified sources.
    """

    bot_id = "SPIDER-4"
    domain = "dark_web"
    rate_limit = 3.0          # Tor is slow — be respectful
    source_reliability = 0.40

    ONION_SEARCH_ENGINES = [
        "http://juhanurmihxlp77nkq76byazcldy2hlmovfu2epvl5ankdibsot4csyd.onion",  # Ahmia
        "http://darksearch.io",  # Clearnet Tor search proxy
    ]

    async def validate_target(self, target: str) -> bool:
        """Dark web collection valid for any target — but only if Tor configured."""
        return bool(settings.tor_socks_proxy and target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect dark web intelligence through Tor proxy.

        Args:
            target: Subject to search for on dark web.
            target_type: Classification of the target.

        Returns:
            CollectionResult with dark web content.
        """
        start = time.monotonic()
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        if not settings.tor_socks_proxy:
            logger.warning("tor_proxy_not_configured", bot=self.bot_id)
            return self._build_result(target, target_type.value, [], time.monotonic() - start,
                                      ["Tor SOCKS proxy not configured"])

        # Check Tor connectivity first
        tor_ok = await self._check_tor_connectivity()
        if not tor_ok:
            return self._build_result(target, target_type.value, [], time.monotonic() - start,
                                      ["Tor proxy unreachable — skipping dark web collection"])

        logger.info("dark_web_collection_started", target=target)

        async with self:
            # Search via Ahmia (dark web search engine with Tor clearnet proxy)
            ahmia_items, ahmia_errors = await self._search_ahmia(target)
            items.extend(ahmia_items)
            errors.extend(ahmia_errors)

            # Search DarkSearch (clearnet Tor search index)
            ds_items, ds_errors = await self._search_darksearch(target)
            items.extend(ds_items)
            errors.extend(ds_errors)

        return self._build_result(target, target_type.value, items,
                                  time.monotonic() - start, errors)

    async def _check_tor_connectivity(self) -> bool:
        """Verify Tor is reachable by hitting check.torproject.org."""
        try:
            import aiohttp, aiohttp_socks
            proxy = settings.tor_socks_proxy
            connector = aiohttp_socks.ProxyConnector.from_url(proxy)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(
                    "https://check.torproject.org/api/ip",
                    timeout=aiohttp.ClientTimeout(total=15),
                ) as resp:
                    data = await resp.json()
                    is_tor = data.get("IsTor", False)
                    logger.info("tor_connectivity_check", is_tor=is_tor)
                    return True
        except Exception as exc:
            logger.warning("tor_connectivity_failed", error=str(exc))
            return False

    async def _search_ahmia(self, target: str) -> tuple[list, list]:
        """Search Ahmia dark web index (clearnet-accessible)."""
        from bs4 import BeautifulSoup
        items, errors = [], []
        try:
            encoded = target.replace(" ", "+")
            url = f"https://ahmia.fi/search/?q={encoded}"
            raw = await self._fetch(url)
            if not raw or not isinstance(raw, str):
                return items, errors

            soup = BeautifulSoup(raw, "html.parser")
            results = soup.find_all("li", class_="result")

            for result in results[:10]:
                title_el = result.find("h4")
                desc_el = result.find("p")
                onion_el = result.find("cite")

                title = title_el.get_text(strip=True) if title_el else ""
                desc = desc_el.get_text(strip=True) if desc_el else ""
                onion_url = onion_el.get_text(strip=True) if onion_el else ""

                if not desc or len(desc) < 30:
                    continue

                content = f"[DARK WEB - Ahmia Index]\nTitle: {title}\nURL: {onion_url}\nDescription: {desc}"
                h = self._content_hash(content)

                items.append(self._build_item(
                    content=content,
                    source_url=onion_url or url,
                    source_type="onion_content",
                    target=target,
                    target_type="dark_web",
                    reliability_score=0.35,
                    metadata={
                        "title": title,
                        "onion_url": onion_url,
                        "search_engine": "ahmia",
                        "warning": "Unverified dark web source",
                    },
                ))

        except Exception as exc:
            errors.append(f"Ahmia search error: {exc}")
            logger.error("ahmia_search_error", error=str(exc))

        return items, errors

    async def _search_darksearch(self, target: str) -> tuple[list, list]:
        """Search DarkSearch.io API (dark web search index)."""
        items, errors = [], []
        try:
            encoded = target.replace(" ", "%20")
            url = f"https://darksearch.io/api/search?query={encoded}&page=1"
            data = await self._fetch(url)

            if not data or not isinstance(data, dict):
                return items, errors

            for result in data.get("data", [])[:8]:
                title = result.get("title", "")
                description = result.get("description", "")
                link = result.get("link", "")

                if not description or len(description) < 30:
                    continue

                content = (f"[DARK WEB - DarkSearch Index]\n"
                           f"Title: {title}\nURL: {link}\n"
                           f"Description: {description[:500]}")

                items.append(self._build_item(
                    content=content,
                    source_url=link,
                    source_type="onion_content",
                    target=target,
                    target_type="dark_web",
                    reliability_score=0.35,
                    metadata={
                        "title": title,
                        "onion_url": link,
                        "search_engine": "darksearch",
                        "warning": "Unverified dark web source",
                    },
                ))

        except Exception as exc:
            errors.append(f"DarkSearch error: {exc}")

        return items, errors
