"""
SOLACE — SPIDER-7: Document & Leak Intelligence Collector
Sources: CISA cybersecurity advisories (RSS), Semantic Scholar academic papers, PDF metadata.
"""
from __future__ import annotations

import time
from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, TargetType


class SpiderDocuments(BaseCollector):
    """SPIDER-7: Document and leak intelligence collector.

    Sources: CISA advisories RSS, Semantic Scholar, public document repositories.
    """

    bot_id = "SPIDER-7"
    domain = "documents_leaks"
    rate_limit = 1.5
    source_reliability = 0.80

    async def validate_target(self, target: str) -> bool:
        """Valid for all targets — documents exist for most subjects."""
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect document and advisory intelligence.

        Args:
            target: Subject to search for.
            target_type: Target classification.

        Returns:
            CollectionResult with document intelligence.
        """
        start = time.monotonic()
        items, errors = [], []

        async with self:
            cisa_items, cisa_errs = await self._collect_cisa(target)
            items.extend(cisa_items)
            errors.extend(cisa_errs)

            doc_items, doc_errs = await self._collect_semantic_scholar(target)
            items.extend(doc_items)
            errors.extend(doc_errs)

        return self._build_result(target, target_type.value, items,
                                  time.monotonic() - start, errors)

    async def _collect_cisa(self, target: str) -> tuple[list, list]:
        """Fetch CISA cybersecurity advisories RSS feed and filter for target."""
        import feedparser
        items, errors = [], []
        try:
            raw = await self._fetch("https://www.cisa.gov/cybersecurity-advisories/all.xml")
            if not raw:
                return items, errors
            feed = feedparser.parse(raw)
            for entry in feed.entries[:50]:
                title = entry.get("title", "")
                summary = entry.get("summary", "")
                if target.lower() not in (title + summary).lower():
                    continue
                content = f"CISA Advisory: {title}\n{summary[:1000]}"
                items.append(self._build_item(
                    content=content, source_url=entry.get("link"),
                    source_type="cisa_advisory", target=target, target_type="threat",
                    reliability_score=0.98,
                    metadata={"published": entry.get("published"), "title": title},
                ))
        except Exception as exc:
            errors.append(f"CISA error: {exc}")
        return items, errors

    async def _collect_semantic_scholar(self, target: str) -> tuple[list, list]:
        """Search Semantic Scholar academic paper index."""
        items, errors = [], []
        try:
            encoded = target.replace(" ", "+")
            data = await self._fetch(
                f"https://api.semanticscholar.org/graph/v1/paper/search"
                f"?query={encoded}&limit=5&fields=title,abstract,year,authors,venue"
            )
            if not data or not isinstance(data, dict):
                return items, errors
            for paper in data.get("data", [])[:5]:
                abstract = paper.get("abstract", "") or ""
                content = (
                    f"Academic Paper: {paper.get('title')}\n"
                    f"  Year: {paper.get('year')}\n"
                    f"  Venue: {paper.get('venue')}\n"
                    f"  Authors: {[a.get('name') for a in paper.get('authors', [])]}\n"
                    f"  Abstract: {abstract[:800]}"
                )
                items.append(self._build_item(
                    content=content,
                    source_url=f"https://www.semanticscholar.org/paper/{paper.get('paperId')}",
                    source_type="academic_paper", target=target, target_type="document",
                    reliability_score=0.85, metadata=paper,
                ))
        except Exception as exc:
            errors.append(f"Semantic Scholar error: {exc}")
        return items, errors
