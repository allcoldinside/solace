"""
SOLACE — Aggregator Bot
Normalizes, deduplicates, and confidence-scores results from all spider bots.
"""
from __future__ import annotations

import hashlib
from datetime import datetime

from config import get_logger
from core.schemas import CollectionResult, RawIntelItemSchema


logger = get_logger("AGGREGATOR")

SOURCE_RELIABILITY: dict[str, float] = {
    "sec_edgar": 0.97,
    "cisa_advisory": 0.98,
    "opensanctions": 0.95,
    "opencorporates": 0.92,
    "whois": 0.95,
    "dns_records": 0.95,
    "shodan": 0.90,
    "censys": 0.88,
    "otx_alienvault": 0.85,
    "virustotal": 0.90,
    "greynoise": 0.88,
    "abuseipdb": 0.88,
    "news_rss": 0.75,
    "hackernews": 0.70,
    "reddit_post": 0.65,
    "twitter_nitter": 0.60,
    "web_search_snippet": 0.60,
    "academic_paper": 0.85,
    "onion_content": 0.40,
}


class AggregatorBot:
    """Aggregates and normalizes results from all spider collectors.

    Deduplicates by content hash, normalizes reliability scores,
    and produces a clean merged dataset for NLP enrichment.
    """

    def process(self, results: list[CollectionResult]) -> list[RawIntelItemSchema]:
        """Merge, deduplicate, and normalize all collection results.

        Args:
            results: List of CollectionResult from all spider bots.

        Returns:
            Deduplicated, normalized list of RawIntelItemSchema.
        """
        seen_hashes: set[str] = set()
        merged: list[RawIntelItemSchema] = []
        total_raw = 0
        total_errors = 0

        for result in results:
            total_raw += len(result.items)
            total_errors += len(result.errors)

            for item in result.items:
                content_hash = hashlib.sha256(item.content.encode("utf-8")).hexdigest()

                if content_hash in seen_hashes:
                    logger.debug("duplicate_skipped", collector=result.collector_id, hash=content_hash[:8])
                    continue

                seen_hashes.add(content_hash)

                # Normalize reliability score from lookup table
                normalized_reliability = SOURCE_RELIABILITY.get(
                    item.source_type, item.reliability_score
                )
                item.reliability_score = normalized_reliability

                # Filter out very short / low-value items
                if len(item.content.strip()) < 80:
                    continue

                merged.append(item)

        logger.info(
            "aggregation_complete",
            raw_items=total_raw,
            unique_items=len(merged),
            duplicates_removed=total_raw - len(merged),
            collectors=len(results),
            total_errors=total_errors,
        )

        # Sort by reliability score descending — highest quality first
        merged.sort(key=lambda x: x.reliability_score, reverse=True)
        return merged


aggregator = AggregatorBot()
