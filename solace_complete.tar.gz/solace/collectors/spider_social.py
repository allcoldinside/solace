"""
SOLACE — SPIDER-2: Social & Forums Collector
Collects social media posts, Reddit threads, and forum content about a target.
"""
from __future__ import annotations

import time
from typing import Any

import praw

from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType
from config import settings


class SpiderSocial(BaseCollector):
    """SPIDER-2: Social media & forums intelligence collector.

    Sources: Reddit (via PRAW), Nitter (Twitter mirror), HackerNews.
    """

    bot_id = "SPIDER-2"
    domain = "social_forums"
    rate_limit = 1.0
    source_reliability = 0.65

    async def validate_target(self, target: str) -> bool:
        """All targets have potential social media presence."""
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect social media and forum intelligence.

        Args:
            target: Subject to search for.
            target_type: Target classification.

        Returns:
            CollectionResult with social/forum content.
        """
        start = time.monotonic()
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []
        seen: set[str] = set()

        self.logger.info("collection_started", target=target)

        async with self:
            reddit_items, reddit_errors = await self._collect_reddit(target, seen)
            items.extend(reddit_items)
            errors.extend(reddit_errors)

            hn_items, hn_errors = await self._collect_hackernews(target, seen)
            items.extend(hn_items)
            errors.extend(hn_errors)

            nitter_items, nitter_errors = await self._collect_nitter(target, seen)
            items.extend(nitter_items)
            errors.extend(nitter_errors)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_reddit(
        self, target: str, seen: set[str]
    ) -> tuple[list[RawIntelItemSchema], list[str]]:
        """Search Reddit for posts and comments mentioning the target.

        Args:
            target: Search term.
            seen: Seen hashes (mutated).

        Returns:
            Tuple of (items, errors).
        """
        import asyncio
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        try:
            reddit = praw.Reddit(
                client_id="solace_osint",
                client_secret="not_needed",
                user_agent="SOLACE-OSINT:v1.0 (academic)",
                check_for_async=False,
            )

            subreddits_to_search = ["all"]

            loop = asyncio.get_event_loop()

            def _search_reddit():
                results = []
                for sub_name in subreddits_to_search:
                    try:
                        sub = reddit.subreddit(sub_name)
                        for submission in sub.search(target, limit=20, sort="new"):
                            content_parts = [
                                f"Title: {submission.title}",
                                f"Score: {submission.score}",
                                f"Subreddit: r/{submission.subreddit.display_name}",
                            ]
                            if submission.selftext and len(submission.selftext) > 50:
                                content_parts.append(f"Content: {submission.selftext[:2000]}")

                            content = "\n".join(content_parts)
                            results.append({
                                "content": content,
                                "url": f"https://reddit.com{submission.permalink}",
                                "metadata": {
                                    "subreddit": submission.subreddit.display_name,
                                    "score": submission.score,
                                    "num_comments": submission.num_comments,
                                    "created_utc": submission.created_utc,
                                    "author": str(submission.author) if submission.author else "[deleted]",
                                },
                            })
                    except Exception as exc:
                        errors.append(f"Reddit search error ({sub_name}): {exc}")
                return results

            raw_results = await loop.run_in_executor(None, _search_reddit)

            for result in raw_results:
                h = self._content_hash(result["content"])
                if h in seen:
                    continue
                seen.add(h)
                items.append(self._build_item(
                    content=result["content"],
                    source_url=result["url"],
                    source_type="reddit_post",
                    target=target,
                    target_type="social",
                    reliability_score=0.65,
                    metadata=result["metadata"],
                ))

        except Exception as exc:
            errors.append(f"Reddit collector error: {exc}")
            self.logger.error("reddit_error", error=str(exc))

        return items, errors

    async def _collect_hackernews(
        self, target: str, seen: set[str]
    ) -> tuple[list[RawIntelItemSchema], list[str]]:
        """Search HackerNews Algolia API for target mentions.

        Args:
            target: Search term.
            seen: Seen hashes (mutated).

        Returns:
            Tuple of (items, errors).
        """
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        try:
            url = "https://hn.algolia.com/api/v1/search"
            params = {"query": target, "hitsPerPage": 20, "tags": "story"}
            data = await self._fetch(url, params=params)

            if not data or not isinstance(data, dict):
                return items, errors

            for hit in data.get("hits", []):
                title = hit.get("title", "")
                story_text = hit.get("story_text", "") or ""
                content = f"Title: {title}\n{story_text[:1500]}"

                if len(content) < 50:
                    continue

                h = self._content_hash(content)
                if h in seen:
                    continue
                seen.add(h)

                items.append(self._build_item(
                    content=content,
                    source_url=hit.get("url") or f"https://news.ycombinator.com/item?id={hit.get('objectID')}",
                    source_type="hackernews",
                    target=target,
                    target_type="tech_community",
                    reliability_score=0.7,
                    metadata={
                        "author": hit.get("author"),
                        "points": hit.get("points"),
                        "num_comments": hit.get("num_comments"),
                        "created_at": hit.get("created_at"),
                    },
                ))

        except Exception as exc:
            errors.append(f"HackerNews error: {exc}")

        return items, errors

    async def _collect_nitter(
        self, target: str, seen: set[str]
    ) -> tuple[list[RawIntelItemSchema], list[str]]:
        """Attempt to collect Twitter/X data via Nitter public instances.

        Args:
            target: Search term.
            seen: Seen hashes (mutated).

        Returns:
            Tuple of (items, errors).
        """
        from bs4 import BeautifulSoup
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        nitter_instances = [
            "https://nitter.net",
            "https://nitter.it",
            "https://nitter.1d4.us",
        ]

        for instance in nitter_instances:
            try:
                encoded = target.replace(" ", "+")
                url = f"{instance}/search?q={encoded}&f=tweets"
                raw = await self._fetch(url)

                if not raw or not isinstance(raw, str):
                    continue

                soup = BeautifulSoup(raw, "html.parser")
                tweet_divs = soup.find_all("div", class_="tweet-content")

                for div in tweet_divs[:15]:
                    text = div.get_text(strip=True)
                    if len(text) < 30:
                        continue

                    h = self._content_hash(text)
                    if h in seen:
                        continue
                    seen.add(h)

                    items.append(self._build_item(
                        content=text,
                        source_url=instance,
                        source_type="twitter_nitter",
                        target=target,
                        target_type="social",
                        reliability_score=0.6,
                        metadata={"nitter_instance": instance},
                    ))

                if items:
                    break  # Got results from this instance

            except Exception as exc:
                errors.append(f"Nitter error ({instance}): {exc}")

        return items, errors
