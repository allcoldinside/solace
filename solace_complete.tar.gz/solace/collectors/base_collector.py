"""
SOLACE — Base Collector
Abstract base class defining the interface all spider bots must implement.
"""
from __future__ import annotations

import asyncio
import hashlib
import time
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

import aiohttp

from config import get_logger
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType


class BaseCollector(ABC):
    """Abstract base for all SOLACE spider bots.

    Each collector is responsible for a specific intelligence domain.
    All HTTP is async; all collectors respect rate limits.
    """

    bot_id: str = "SPIDER-UNKNOWN"
    domain: str = "unknown"
    rate_limit: float = 1.0  # seconds between requests
    source_reliability: float = 0.7  # default reliability score

    def __init__(self) -> None:
        self.logger = get_logger(self.bot_id, domain=self.domain)
        self._last_request_time: float = 0.0
        self._session: aiohttp.ClientSession | None = None

    async def __aenter__(self) -> "BaseCollector":
        self._session = aiohttp.ClientSession(
            headers={"User-Agent": "SOLACE-OSINT/1.0 (academic research)"},
            timeout=aiohttp.ClientTimeout(total=30),
            connector=aiohttp.TCPConnector(ssl=False),
        )
        return self

    async def __aexit__(self, *args) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    @abstractmethod
    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Execute collection for a target.

        Args:
            target: The subject to collect intelligence on.
            target_type: The type classification of the target.

        Returns:
            CollectionResult with all collected items.
        """
        ...

    @abstractmethod
    async def validate_target(self, target: str) -> bool:
        """Check whether this collector is applicable for a given target.

        Args:
            target: The subject to validate.

        Returns:
            True if this collector should run for this target.
        """
        ...

    async def _fetch(
        self,
        url: str,
        params: dict | None = None,
        headers: dict | None = None,
        method: str = "GET",
        json_body: dict | None = None,
    ) -> dict | str | None:
        """Async HTTP fetch with rate limiting, retries, and error handling.

        Args:
            url: The URL to fetch.
            params: Optional query parameters.
            headers: Optional additional headers.
            method: HTTP method (GET/POST).
            json_body: Optional JSON request body for POST.

        Returns:
            Parsed JSON dict, raw text, or None on failure.
        """
        await self._enforce_rate_limit()

        if self._session is None:
            self._session = aiohttp.ClientSession(
                headers={"User-Agent": "SOLACE-OSINT/1.0"},
                timeout=aiohttp.ClientTimeout(total=30),
            )

        for attempt in range(3):
            try:
                if method == "GET":
                    resp = await self._session.get(url, params=params, headers=headers)
                else:
                    resp = await self._session.post(url, params=params, headers=headers, json=json_body)

                if resp.status == 429:
                    retry_after = int(resp.headers.get("Retry-After", 60))
                    self.logger.warning("rate_limited", url=url, retry_after=retry_after)
                    await asyncio.sleep(retry_after)
                    continue

                if resp.status >= 400:
                    self.logger.warning("http_error", url=url, status=resp.status)
                    return None

                content_type = resp.headers.get("Content-Type", "")
                if "json" in content_type:
                    return await resp.json()
                return await resp.text()

            except aiohttp.ClientError as exc:
                self.logger.warning("fetch_error", url=url, attempt=attempt, error=str(exc))
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)
            except asyncio.TimeoutError:
                self.logger.warning("fetch_timeout", url=url, attempt=attempt)
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)

        self.logger.error("fetch_failed_all_attempts", url=url)
        return None

    async def _enforce_rate_limit(self) -> None:
        """Sleep to enforce the configured rate limit between requests."""
        now = time.monotonic()
        elapsed = now - self._last_request_time
        if elapsed < self.rate_limit:
            await asyncio.sleep(self.rate_limit - elapsed)
        self._last_request_time = time.monotonic()

    def _build_item(
        self,
        content: str,
        source_url: str | None,
        source_type: str,
        target: str,
        target_type: str,
        language: str = "en",
        reliability_score: float | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> RawIntelItemSchema:
        """Build a validated RawIntelItemSchema from collected content.

        Args:
            content: The raw text content.
            source_url: Origin URL.
            source_type: Category label for this source.
            target: Collection target subject.
            target_type: Target type string.
            language: Detected language code.
            reliability_score: Override default reliability.
            metadata: Additional metadata dict.

        Returns:
            A validated RawIntelItemSchema instance.
        """
        return RawIntelItemSchema(
            collector_id=self.bot_id,
            source_url=source_url,
            source_type=source_type,
            content=content,
            language=language,
            target=target,
            target_type=target_type,
            reliability_score=reliability_score or self.source_reliability,
            metadata=metadata or {},
            collected_at=datetime.utcnow(),
        )

    @staticmethod
    def _content_hash(content: str) -> str:
        """Generate a SHA-256 hash of content for deduplication."""
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    def _build_result(
        self,
        target: str,
        target_type: str,
        items: list[RawIntelItemSchema],
        duration: float,
        errors: list[str] | None = None,
    ) -> CollectionResult:
        """Assemble a CollectionResult from gathered items.

        Args:
            target: Collection target.
            target_type: Target type string.
            items: List of collected items.
            duration: Collection duration in seconds.
            errors: Any non-fatal errors encountered.

        Returns:
            Validated CollectionResult.
        """
        self.logger.info(
            "collection_complete",
            target=target,
            items_count=len(items),
            duration_seconds=round(duration, 2),
            errors_count=len(errors or []),
        )
        return CollectionResult(
            collector_id=self.bot_id,
            target=target,
            target_type=target_type,
            items=items,
            duration_seconds=duration,
            errors=errors or [],
        )
