"""
SOLACE — SPIDER-6: Geospatial & Satellite Intelligence Collector
Sources: OpenStreetMap Overpass API, MaxMind GeoLite2, IP geolocation.
Maps physical locations of entities and correlates with network intelligence.
"""
from __future__ import annotations

import re
import time
from typing import Any

from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType
from config import settings, get_logger

logger = get_logger("SPIDER-6")

OVERPASS_API = "https://overpass-api.de/api/interpreter"
NOMINATIM_API = "https://nominatim.openstreetmap.org/search"
IP_GEO_API = "https://ipapi.co/{ip}/json/"


class SpiderGeo(BaseCollector):
    """SPIDER-6: Geospatial intelligence collector.

    Correlates entities with physical locations using:
    - OpenStreetMap Overpass API (business/org locations)
    - Nominatim geocoding (address resolution)
    - IP geolocation (network infrastructure mapping)
    - MaxMind GeoLite2 (offline IP database, if installed)
    """

    bot_id = "SPIDER-6"
    domain = "geo_satellite"
    rate_limit = 1.5          # Nominatim requires 1s between requests
    source_reliability = 0.80

    async def validate_target(self, target: str) -> bool:
        """Valid for any target — geo data exists for most entities."""
        return bool(target)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect geospatial intelligence for a target.

        Args:
            target: Subject to geolocate.
            target_type: Classification of the target.

        Returns:
            CollectionResult with location intelligence.
        """
        start = time.monotonic()
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []
        seen: set[str] = set()

        self.logger.info("collection_started", target=target, target_type=target_type)

        async with self:
            # Geocode the target name → coordinates + address
            geo_items, geo_errors = await self._geocode_target(target, seen)
            items.extend(geo_items)
            errors.extend(geo_errors)

            # If target looks like an IP, geolocate it
            if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", target):
                ip_items, ip_errors = await self._geolocate_ip(target)
                items.extend(ip_items)
                errors.extend(ip_errors)

            # Query OpenStreetMap for physical locations
            osm_items, osm_errors = await self._query_overpass(target, seen)
            items.extend(osm_items)
            errors.extend(osm_errors)

            # Reverse geocode any found coordinates
            coord_items, coord_errors = await self._collect_satellite_metadata(target)
            items.extend(coord_items)
            errors.extend(coord_errors)

        return self._build_result(target, target_type.value, items,
                                  time.monotonic() - start, errors)

    async def _geocode_target(self, target: str, seen: set[str]) -> tuple[list, list]:
        """Use Nominatim to geocode the target name to coordinates.

        Args:
            target: Search term.
            seen: Seen content hashes.

        Returns:
            Tuple of (items, errors).
        """
        items, errors = [], []
        try:
            params = {
                "q": target,
                "format": "json",
                "limit": 5,
                "addressdetails": 1,
            }
            headers = {"User-Agent": "SOLACE-OSINT/1.0 (academic research)"}
            data = await self._fetch(NOMINATIM_API, params=params, headers=headers)

            if not data or not isinstance(data, list):
                return items, errors

            for result in data[:5]:
                lat = result.get("lat", "")
                lon = result.get("lon", "")
                display_name = result.get("display_name", "")
                place_type = result.get("type", "")
                address = result.get("address", {})

                content = (
                    f"Geolocation: {target}\n"
                    f"  Coordinates: {lat}, {lon}\n"
                    f"  Full Address: {display_name}\n"
                    f"  Type: {place_type}\n"
                    f"  Country: {address.get('country', 'Unknown')}\n"
                    f"  State/Region: {address.get('state', address.get('region', 'Unknown'))}\n"
                    f"  City: {address.get('city', address.get('town', 'Unknown'))}\n"
                    f"  OSM ID: {result.get('osm_id', '')}"
                )

                h = self._content_hash(content)
                if h in seen:
                    continue
                seen.add(h)

                items.append(self._build_item(
                    content=content,
                    source_url=f"https://www.openstreetmap.org/?lat={lat}&lon={lon}&zoom=15",
                    source_type="geo_nominatim",
                    target=target,
                    target_type="geographic",
                    reliability_score=0.82,
                    metadata={
                        "lat": lat,
                        "lon": lon,
                        "display_name": display_name,
                        "place_type": place_type,
                        "country": address.get("country"),
                        "osm_id": result.get("osm_id"),
                    },
                ))

        except Exception as exc:
            errors.append(f"Nominatim geocoding error: {exc}")
            logger.error("nominatim_error", error=str(exc))

        return items, errors

    async def _geolocate_ip(self, ip: str) -> tuple[list, list]:
        """Geolocate an IP address using ipapi.co.

        Args:
            ip: IP address string.

        Returns:
            Tuple of (items, errors).
        """
        items, errors = [], []
        try:
            data = await self._fetch(IP_GEO_API.format(ip=ip))
            if not data or not isinstance(data, dict) or "error" in data:
                return items, errors

            content = (
                f"IP Geolocation: {ip}\n"
                f"  Country: {data.get('country_name')} ({data.get('country_code')})\n"
                f"  Region: {data.get('region')}\n"
                f"  City: {data.get('city')}\n"
                f"  Coordinates: {data.get('latitude')}, {data.get('longitude')}\n"
                f"  ISP/Org: {data.get('org')}\n"
                f"  ASN: {data.get('asn')}\n"
                f"  Timezone: {data.get('timezone')}\n"
                f"  Currency: {data.get('currency')}"
            )

            items.append(self._build_item(
                content=content,
                source_url=f"https://ipapi.co/{ip}/",
                source_type="geo_ip",
                target=ip,
                target_type="network_geo",
                reliability_score=0.85,
                metadata={
                    "ip": ip,
                    "country": data.get("country_name"),
                    "country_code": data.get("country_code"),
                    "city": data.get("city"),
                    "lat": data.get("latitude"),
                    "lon": data.get("longitude"),
                    "org": data.get("org"),
                    "asn": data.get("asn"),
                },
            ))

        except Exception as exc:
            errors.append(f"IP geolocation error: {exc}")

        return items, errors

    async def _query_overpass(self, target: str, seen: set[str]) -> tuple[list, list]:
        """Query OpenStreetMap Overpass API for named entities.

        Searches for businesses, buildings, and amenities matching the target.

        Args:
            target: Entity name to search.
            seen: Seen hashes.

        Returns:
            Tuple of (items, errors).
        """
        items, errors = [], []
        try:
            # Overpass QL query — find named entities
            query = f"""
[out:json][timeout:15];
(
  node["name"~"{target}",i];
  way["name"~"{target}",i];
  relation["name"~"{target}",i];
);
out center 10;
"""
            data = await self._fetch(
                OVERPASS_API,
                method="POST",
                json_body={"data": query},
            )

            if not data or not isinstance(data, dict):
                return items, errors

            elements = data.get("elements", [])[:8]

            for element in elements:
                tags = element.get("tags", {})
                name = tags.get("name", "Unknown")
                amenity = tags.get("amenity", tags.get("office", tags.get("shop", "")))

                # Get coordinates
                if element.get("type") == "node":
                    lat = element.get("lat")
                    lon = element.get("lon")
                else:
                    center = element.get("center", {})
                    lat = center.get("lat")
                    lon = center.get("lon")

                if not lat or not lon:
                    continue

                content = (
                    f"OSM Entity: {name}\n"
                    f"  Type: {amenity or element.get('type', 'unknown')}\n"
                    f"  Coordinates: {lat}, {lon}\n"
                    f"  Address: {tags.get('addr:full', tags.get('addr:street', 'N/A'))}\n"
                    f"  City: {tags.get('addr:city', 'N/A')}\n"
                    f"  Country: {tags.get('addr:country', 'N/A')}\n"
                    f"  Website: {tags.get('website', tags.get('contact:website', 'N/A'))}\n"
                    f"  Phone: {tags.get('phone', tags.get('contact:phone', 'N/A'))}\n"
                    f"  OSM ID: {element.get('id')}"
                )

                h = self._content_hash(content)
                if h in seen:
                    continue
                seen.add(h)

                items.append(self._build_item(
                    content=content,
                    source_url=f"https://www.openstreetmap.org/{element.get('type')}/{element.get('id')}",
                    source_type="geo_osm",
                    target=target,
                    target_type="geographic",
                    reliability_score=0.78,
                    metadata={
                        "osm_id": element.get("id"),
                        "osm_type": element.get("type"),
                        "lat": lat,
                        "lon": lon,
                        "name": name,
                        "amenity": amenity,
                        "tags": tags,
                    },
                ))

        except Exception as exc:
            errors.append(f"Overpass API error: {exc}")
            logger.error("overpass_error", error=str(exc))

        return items, errors

    async def _collect_satellite_metadata(self, target: str) -> tuple[list, list]:
        """Collect Copernicus/Sentinel satellite coverage metadata for found locations.

        Uses the Copernicus Open Access Hub search API to find recent satellite
        imagery coverage for geocoded locations.

        Args:
            target: Target subject.

        Returns:
            Tuple of (items, errors).
        """
        items, errors = [], []
        try:
            # Query Copernicus for recent Sentinel-2 coverage info
            params = {
                "q": f"(platformname:Sentinel-2 AND filename:*{target[:10].replace(' ', '*')}*)",
                "start": 0,
                "rows": 3,
                "format": "json",
            }
            data = await self._fetch(
                "https://apihub.copernicus.eu/apihub/search",
                params=params,
            )

            if data and isinstance(data, dict):
                feed = data.get("feed", {})
                entries = feed.get("entry", [])
                if isinstance(entries, dict):
                    entries = [entries]

                for entry in entries[:3]:
                    title = entry.get("title", "")
                    content = (
                        f"Satellite Coverage: {title}\n"
                        f"  Platform: Sentinel-2\n"
                        f"  Ingestion Date: {entry.get('ingestiondate', 'N/A')}\n"
                        f"  Cloud Cover: {entry.get('cloudcoverpercentage', 'N/A')}%\n"
                        f"  Size: {entry.get('size', 'N/A')}"
                    )
                    items.append(self._build_item(
                        content=content,
                        source_url="https://scihub.copernicus.eu",
                        source_type="geo_satellite",
                        target=target,
                        target_type="satellite",
                        reliability_score=0.9,
                        metadata={"title": title, "platform": "Sentinel-2"},
                    ))

        except Exception as exc:
            # Copernicus requires auth — failure is expected without credentials
            logger.debug("copernicus_unavailable", error=str(exc))

        return items, errors
