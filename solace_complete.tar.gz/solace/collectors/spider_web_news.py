"""
SOLACE — SPIDER-1: Web & News Collector
Scrapes news sites, RSS feeds, and general web content about a target.
Uses trafilatura for clean article extraction.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

import feedparser
import trafilatura

from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType

NEWS_SEARCH_APIS = [
    "https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en",
    "https://feeds.reuters.com/reuters/businessNews",
    "https://rss.cnn.com/rss/edition.rss",
]

SEARCH_ENGINES = [
    "https://html.duckduckgo.com/html/?q={query}",
]


class SpiderWebNews(BaseCollector):
    """SPIDER-1: Web & news open-source intelligence collector.

    Collects news articles, RSS feed entries, and publicly accessible
    web content mentioning the target entity.
    """

    bot_id = "SPIDER-1"
    domain = "web_news"
    rate_limit = 1.5
    source_reliability = 0.75

    async def validate_target(self, target: str) -> bool:
        """All targets have a web/news presence — always valid."""
        return bool(target and len(target.strip()) > 0)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        """Collect news and web intelligence for a target.

        Args:
            target: Subject to search for.
            target_type: Classification of the target.

        Returns:
            CollectionResult with news articles and web content.
        """
        start = time.monotonic()
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []
        seen_hashes: set[str] = set()

        self.logger.info("collection_started", target=target, target_type=target_type)

        async with self:
            # ── RSS / Google News ─────────────────────────────────────────────
            rss_items, rss_errors = await self._collect_rss(target, seen_hashes)
            items.extend(rss_items)
            errors.extend(rss_errors)

            # ── DuckDuckGo HTML search ────────────────────────────────────────
            ddg_items, ddg_errors = await self._collect_duckduckgo(target, seen_hashes)
            items.extend(ddg_items)
            errors.extend(ddg_errors)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_rss(
        self, target: str, seen: set[str]
    ) -> tuple[list[RawIntelItemSchema], list[str]]:
        """Fetch and parse Google News RSS for the target.

        Args:
            target: Search query / target name.
            seen: Set of already-seen content hashes (mutated in place).

        Returns:
            Tuple of (items, errors).
        """
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        encoded = target.replace(" ", "+")
        url = f"https://news.google.com/rss/search?q={encoded}&hl=en-US&gl=US&ceid=US:en"

        try:
            raw = await self._fetch(url)
            if not raw:
                return items, errors

            feed = feedparser.parse(raw)
            fetch_tasks = []

            for entry in feed.entries[:20]:
                entry_url = getattr(entry, "link", None)
                if entry_url:
                    fetch_tasks.append(self._fetch_article(entry_url, target))

            results = await asyncio.gather(*fetch_tasks, return_exceptions=True)

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    errors.append(f"RSS article fetch error: {result}")
                    continue
                if result is None:
                    continue

                content, url_used = result
                h = self._content_hash(content)
                if h in seen or len(content) < 100:
                    continue
                seen.add(h)

                entry = feed.entries[i] if i < len(feed.entries) else None
                items.append(self._build_item(
                    content=content,
                    source_url=url_used,
                    source_type="news_rss",
                    target=target,
                    target_type="news",
                    metadata={
                        "title": getattr(entry, "title", ""),
                        "published": getattr(entry, "published", ""),
                        "feed": "google_news",
                    },
                ))

        except Exception as exc:
            errors.append(f"RSS collection error: {exc}")
            self.logger.error("rss_collection_error", error=str(exc))

        return items, errors

    async def _fetch_article(self, url: str, target: str) -> tuple[str, str] | None:
        """Fetch and extract clean article text using trafilatura.

        Args:
            url: Article URL.
            target: Target subject (for relevance filtering).

        Returns:
            Tuple of (clean_text, url) or None if extraction failed.
        """
        try:
            raw = await self._fetch(url)
            if not raw or not isinstance(raw, str):
                return None

            extracted = trafilatura.extract(
                raw,
                include_comments=False,
                include_tables=True,
                no_fallback=False,
                favor_precision=True,
            )

            if not extracted or len(extracted) < 100:
                return None

            if target.lower() not in extracted.lower():
                return None  # Not relevant to target

            return extracted, url

        except Exception as exc:
            self.logger.debug("article_extraction_failed", url=url, error=str(exc))
            return None

    async def _collect_duckduckgo(
        self, target: str, seen: set[str]
    ) -> tuple[list[RawIntelItemSchema], list[str]]:
        """Scrape DuckDuckGo HTML results for the target.

        Args:
            target: Search query.
            seen: Seen content hashes (mutated in place).

        Returns:
            Tuple of (items, errors).
        """
        from bs4 import BeautifulSoup

        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        queries = [
            target,
            f'"{target}" site:linkedin.com OR site:twitter.com',
            f'"{target}" news 2024 OR 2025',
        ]

        for query in queries[:2]:
            try:
                encoded = query.replace(" ", "+")
                url = f"https://html.duckduckgo.com/html/?q={encoded}"
                raw = await self._fetch(url, headers={"Accept-Language": "en-US,en;q=0.9"})

                if not raw or not isinstance(raw, str):
                    continue

                soup = BeautifulSoup(raw, "html.parser")
                result_divs = soup.find_all("div", class_="result__body")

                for div in result_divs[:10]:
                    snippet_el = div.find("a", class_="result__snippet")
                    link_el = div.find("a", class_="result__url")

                    if not snippet_el:
                        continue

                    snippet = snippet_el.get_text(strip=True)
                    link = link_el.get_text(strip=True) if link_el else None

                    if len(snippet) < 50:
                        continue

                    h = self._content_hash(snippet)
                    if h in seen:
                        continue
                    seen.add(h)

                    items.append(self._build_item(
                        content=snippet,
                        source_url=link,
                        source_type="web_search_snippet",
                        target=target,
                        target_type="web",
                        reliability_score=0.6,
                        metadata={"query": query, "engine": "duckduckgo"},
                    ))

            except Exception as exc:
                errors.append(f"DuckDuckGo error for '{query}': {exc}")

        return items, errors
