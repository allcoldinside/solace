"""
SOLACE — SPIDER-3: Network & DNS Intelligence Collector
Collects DNS records, WHOIS data, IP intel, and Shodan data for infrastructure targets.
"""
from __future__ import annotations

import time

import dns.resolver
import whois

from collectors.base_collector import BaseCollector
from core.schemas import CollectionResult, RawIntelItemSchema, TargetType
from config import settings


class SpiderNetwork(BaseCollector):
    """SPIDER-3: Network infrastructure intelligence collector."""

    bot_id = "SPIDER-3"
    domain = "network_dns"
    rate_limit = 0.5
    source_reliability = 0.9

    async def validate_target(self, target: str) -> bool:
        """Valid for domains, IPs, and organization names."""
        import re
        domain_pattern = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
        ip_pattern = r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$'
        return bool(re.match(domain_pattern, target) or re.match(ip_pattern, target) or len(target) > 2)

    async def collect(self, target: str, target_type: TargetType) -> CollectionResult:
        start = time.monotonic()
        items: list[RawIntelItemSchema] = []
        errors: list[str] = []

        async with self:
            whois_items, whois_errors = await self._collect_whois(target)
            items.extend(whois_items)
            errors.extend(whois_errors)

            dns_items, dns_errors = await self._collect_dns(target)
            items.extend(dns_items)
            errors.extend(dns_errors)

            if settings.shodan_api_key:
                shodan_items, shodan_errors = await self._collect_shodan(target)
                items.extend(shodan_items)
                errors.extend(shodan_errors)

            censys_items, censys_errors = await self._collect_censys(target)
            items.extend(censys_items)
            errors.extend(censys_errors)

        return self._build_result(target, target_type.value, items, time.monotonic() - start, errors)

    async def _collect_whois(self, target: str) -> tuple[list, list]:
        import asyncio
        items, errors = [], []
        try:
            loop = asyncio.get_event_loop()
            w = await loop.run_in_executor(None, whois.whois, target)
            if w:
                content = f"WHOIS for {target}:\n"
                for k, v in w.items():
                    if v:
                        content += f"  {k}: {v}\n"
                items.append(self._build_item(
                    content=content, source_url=None, source_type="whois",
                    target=target, target_type="network", reliability_score=0.95,
                    metadata={"registrar": str(w.get("registrar", "")), "creation_date": str(w.get("creation_date", ""))},
                ))
        except Exception as exc:
            errors.append(f"WHOIS error: {exc}")
        return items, errors

    async def _collect_dns(self, target: str) -> tuple[list, list]:
        import asyncio
        items, errors = [], []
        record_types = ["A", "AAAA", "MX", "NS", "TXT", "CNAME"]
        dns_data = {}

        for rtype in record_types:
            try:
                loop = asyncio.get_event_loop()
                answers = await loop.run_in_executor(None, lambda rt=rtype: dns.resolver.resolve(target, rt, raise_on_no_answer=False))
                dns_data[rtype] = [str(r) for r in answers]
            except Exception:
                pass

        if dns_data:
            content = f"DNS Records for {target}:\n"
            for rtype, records in dns_data.items():
                content += f"  {rtype}: {', '.join(records)}\n"
            items.append(self._build_item(
                content=content, source_url=None, source_type="dns_records",
                target=target, target_type="network", reliability_score=0.95,
                metadata=dns_data,
            ))
        return items, errors

    async def _collect_shodan(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        try:
            url = f"https://api.shodan.io/shodan/host/search"
            params = {"key": settings.shodan_api_key, "query": target, "limit": 10}
            data = await self._fetch(url, params=params)
            if data and isinstance(data, dict) and "matches" in data:
                for match in data["matches"][:5]:
                    content = (f"Shodan Match:\n  IP: {match.get('ip_str')}\n"
                               f"  Port: {match.get('port')}\n  Banner: {str(match.get('data', ''))[:500]}\n"
                               f"  OS: {match.get('os')}\n  Org: {match.get('org')}")
                    items.append(self._build_item(
                        content=content, source_url=f"https://shodan.io/host/{match.get('ip_str')}",
                        source_type="shodan", target=target, target_type="network",
                        reliability_score=0.9, metadata={"ip": match.get("ip_str"), "port": match.get("port")},
                    ))
        except Exception as exc:
            errors.append(f"Shodan error: {exc}")
        return items, errors

    async def _collect_censys(self, target: str) -> tuple[list, list]:
        items, errors = [], []
        if not (settings.censys_api_id and settings.censys_api_secret):
            return items, errors
        try:
            import base64
            creds = base64.b64encode(f"{settings.censys_api_id}:{settings.censys_api_secret}".encode()).decode()
            headers = {"Authorization": f"Basic {creds}"}
            data = await self._fetch(
                "https://search.censys.io/api/v2/hosts/search",
                params={"q": target, "per_page": 5}, headers=headers,
            )
            if data and isinstance(data, dict):
                for host in data.get("result", {}).get("hits", []):
                    content = f"Censys Host:\n  IP: {host.get('ip')}\n  Services: {host.get('services', [])}"
                    items.append(self._build_item(
                        content=content, source_url=f"https://search.censys.io/hosts/{host.get('ip')}",
                        source_type="censys", target=target, target_type="network",
                        reliability_score=0.88, metadata=host,
                    ))
        except Exception as exc:
            errors.append(f"Censys error: {exc}")
        return items, errors
