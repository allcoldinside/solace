"""
SOLACE — Pydantic Schemas
Validation schemas for API requests/responses and inter-service data contracts.
"""
from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, HttpUrl


# ── Enums ─────────────────────────────────────────────────────────────────────

class TargetType(str, Enum):
    ORGANIZATION = "organization"
    PERSON = "person"
    INFRASTRUCTURE = "infrastructure"
    EVENT = "event"
    THREAT_ACTOR = "threat_actor"


class Classification(str, Enum):
    WHITE = "TLP:WHITE"
    GREEN = "TLP:GREEN"
    AMBER = "TLP:AMBER"
    RED = "TLP:RED"


class ConfidenceLevel(str, Enum):
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class CollectorID(str, Enum):
    SPIDER_WEB_NEWS = "SPIDER-1"
    SPIDER_SOCIAL = "SPIDER-2"
    SPIDER_NETWORK = "SPIDER-3"
    SPIDER_DARKWEB = "SPIDER-4"
    SPIDER_CORPORATE = "SPIDER-5"
    SPIDER_GEO = "SPIDER-6"
    SPIDER_DOCUMENTS = "SPIDER-7"
    SPIDER_THREAT = "SPIDER-8"
    AGGREGATOR = "AGGREGATOR"
    REPORT_WRITER = "REPORT-WRITER"


class AnalystID(str, Enum):
    CLAUDE = "ANALYST-ALPHA"
    CHATGPT = "ANALYST-BRAVO"
    GEMINI = "SESSION-DIRECTOR"


class PanelStatus(str, Enum):
    ACTIVE = "ACTIVE"
    REDIRECTING = "REDIRECTING"
    LOOP_BREAK = "LOOP-BREAK"
    CONCLUDING = "CONCLUDING"
    COMPLETE = "COMPLETE"


# ── Collection Schemas ────────────────────────────────────────────────────────

class RawIntelItemSchema(BaseModel):
    """Raw item collected by a spider bot."""
    collector_id: str
    source_url: str | None = None
    source_type: str
    content: str
    language: str = "en"
    target: str
    target_type: str
    reliability_score: float = Field(ge=0.0, le=1.0, default=0.5)
    metadata: dict[str, Any] = Field(default_factory=dict)
    collected_at: datetime = Field(default_factory=datetime.utcnow)


class CollectionResult(BaseModel):
    """Result from a single spider bot run."""
    collector_id: str
    target: str
    target_type: str
    items: list[RawIntelItemSchema]
    duration_seconds: float
    errors: list[str] = Field(default_factory=list)
    collected_at: datetime = Field(default_factory=datetime.utcnow)


class EnrichedIntelItem(RawIntelItemSchema):
    """NLP-enriched intel item."""
    content_en: str | None = None
    sentiment_score: float | None = None
    sentiment_label: str | None = None
    keywords: list[str] = Field(default_factory=list)
    named_entities: dict[str, list[str]] = Field(default_factory=dict)
    embedding: list[float] | None = None


# ── Report Schemas ────────────────────────────────────────────────────────────

class KeyFinding(BaseModel):
    """A single key finding in a report."""
    number: int
    finding: str
    confidence: ConfidenceLevel
    source_count: int
    first_observed: str
    evidence: list[str] = Field(default_factory=list)


class TimelineEntry(BaseModel):
    """A single entry in the report timeline."""
    timestamp: str
    event: str
    source: str
    confidence: ConfidenceLevel
    significance: str = ""


class BehavioralIndicator(BaseModel):
    """A detected behavioral pattern or anomaly."""
    indicator: str
    pattern_type: str
    significance: str
    confidence: ConfidenceLevel
    evidence: list[str] = Field(default_factory=list)


class SourceLogEntry(BaseModel):
    """A single source in the report source log."""
    url: str | None = None
    collector: str
    source_type: str
    collected_at: str
    reliability_score: float
    content_hash: str
    notes: str = ""


class ReportCreate(BaseModel):
    """Schema for creating a new report."""
    subject: str
    subject_type: TargetType
    classification: Classification = Classification.WHITE
    tags: list[str] = Field(default_factory=list)


class ReportSummary(BaseModel):
    """Lightweight report summary for list views."""
    id: str
    report_id: str
    subject: str
    subject_type: str
    classification: str
    confidence: str
    confidence_score: float
    tags: list[str]
    executive_summary: str
    created_at: datetime
    google_drive_file_id: str | None = None

    model_config = {"from_attributes": True}


class ReportFull(ReportSummary):
    """Full report with all sections."""
    analyst_bots: list[str]
    key_findings: dict[str, Any]
    entity_map: dict[str, Any]
    timeline: list[dict[str, Any]]
    behavioral_indicators: list[dict[str, Any]]
    threat_assessment: dict[str, Any]
    source_log: list[dict[str, Any]]
    gaps: list[str]
    analyst_notes: list[str]
    full_markdown: str
    collection_started: datetime | None = None
    collection_completed: datetime | None = None


# ── Panel Schemas ─────────────────────────────────────────────────────────────

class PanelTurn(BaseModel):
    """A single turn in the panel session transcript."""
    turn_id: str
    round_number: int
    analyst: AnalystID
    content: str
    status: PanelStatus | None = None
    is_loop_flagged: bool = False
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class Disagreement(BaseModel):
    """A recorded disagreement between panel analysts."""
    round_number: int
    topic: str
    alpha_position: str
    bravo_position: str
    director_note: str = ""


class PanelSessionCreate(BaseModel):
    """Schema for starting a panel session."""
    report_id: str | None = None
    topic: str
    target: str
    max_rounds: int = Field(ge=1, le=12, default=6)


class PanelSessionSummary(BaseModel):
    """Lightweight panel session summary."""
    id: str
    session_id: str
    topic: str
    target: str
    rounds_completed: int
    concluded: bool
    start_time: datetime
    end_time: datetime | None = None

    model_config = {"from_attributes": True}


class PanelSessionFull(PanelSessionSummary):
    """Full panel session with transcript."""
    transcript: list[dict[str, Any]]
    positions: dict[str, list[str]]
    disagreements: list[dict[str, Any]]
    covered_topics: list[str]
    final_synthesis: str | None = None
    google_drive_file_id: str | None = None


# ── Collection Task Schemas ───────────────────────────────────────────────────

class CollectionTaskCreate(BaseModel):
    """Schema for triggering a collection task."""
    target: str
    target_type: TargetType
    requestor: str = "api"
    priority: str = "normal"


class CollectionTaskStatus(BaseModel):
    """Status of a collection task."""
    id: str
    target: str
    target_type: str
    status: str
    celery_task_id: str | None = None
    result_report_id: str | None = None
    error: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    model_config = {"from_attributes": True}


# ── Alert Schema ──────────────────────────────────────────────────────────────

class Alert(BaseModel):
    """An outbound alert routed to messaging platforms."""
    alert_id: str
    title: str
    body: str
    classification: Classification
    report_id: str | None = None
    session_id: str | None = None
    tags: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ── API Responses ─────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    services: dict[str, str]


class PaginatedResponse(BaseModel):
    """Generic paginated response."""
    items: list[Any]
    total: int
    page: int
    page_size: int
    pages: int
