"""
SOLACE — ORM Models
All database table definitions using SQLAlchemy 2.0 declarative syntax.
"""
from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from core.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.utcnow()


# ── Entities ─────────────────────────────────────────────────────────────────

class Entity(Base):
    """A person, organization, infrastructure node, or event of interest."""

    __tablename__ = "entities"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    entity_type: Mapped[str] = mapped_column(String(50), nullable=False)  # person/org/infra/event
    name: Mapped[str] = mapped_column(String(500), nullable=False)
    aliases: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    tags: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    first_seen: Mapped[datetime] = mapped_column(DateTime, default=_now)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    observations: Mapped[list["Observation"]] = relationship(back_populates="entity")
    source_relationships: Mapped[list["EntityRelationship"]] = relationship(
        foreign_keys="EntityRelationship.source_id", back_populates="source"
    )
    target_relationships: Mapped[list["EntityRelationship"]] = relationship(
        foreign_keys="EntityRelationship.target_id", back_populates="target"
    )


class EntityRelationship(Base):
    """Directed relationship between two entities."""

    __tablename__ = "entity_relationships"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    source_id: Mapped[str] = mapped_column(ForeignKey("entities.id"), nullable=False)
    target_id: Mapped[str] = mapped_column(ForeignKey("entities.id"), nullable=False)
    rel_type: Mapped[str] = mapped_column(String(100), nullable=False)
    strength: Mapped[float] = mapped_column(Float, default=0.5)
    evidence_ids: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)

    source: Mapped["Entity"] = relationship(foreign_keys=[source_id], back_populates="source_relationships")
    target: Mapped["Entity"] = relationship(foreign_keys=[target_id], back_populates="target_relationships")


# ── Raw Intelligence ──────────────────────────────────────────────────────────

class RawIntelItem(Base):
    """Raw scraped item from a collector bot."""

    __tablename__ = "raw_intel_items"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    content_hash: Mapped[str] = mapped_column(String(64), nullable=False)
    collector_id: Mapped[str] = mapped_column(String(20), nullable=False)
    source_url: Mapped[str] = mapped_column(Text, nullable=True)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    content_en: Mapped[str | None] = mapped_column(Text, nullable=True)
    language: Mapped[str] = mapped_column(String(10), default="en")
    target: Mapped[str] = mapped_column(String(500), nullable=False)
    target_type: Mapped[str] = mapped_column(String(50), nullable=False)
    collected_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    reliability_score: Mapped[float] = mapped_column(Float, default=0.5)
    processed: Mapped[bool] = mapped_column(Boolean, default=False)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)

    __table_args__ = (UniqueConstraint("content_hash", name="uq_raw_intel_hash"),)


class Observation(Base):
    """An enriched, NLP-processed observation linked to an entity."""

    __tablename__ = "observations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    entity_id: Mapped[str | None] = mapped_column(ForeignKey("entities.id"), nullable=True)
    raw_item_id: Mapped[str] = mapped_column(ForeignKey("raw_intel_items.id"), nullable=False)
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    content: Mapped[str] = mapped_column(Text, nullable=False)
    sentiment_score: Mapped[float | None] = mapped_column(Float, nullable=True)
    sentiment_label: Mapped[str | None] = mapped_column(String(20), nullable=True)
    keywords: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    named_entities: Mapped[dict] = mapped_column(JSON, default=dict)
    embedding: Mapped[list[float] | None] = mapped_column(Vector(1024), nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=0.5)
    observed_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)

    entity: Mapped["Entity"] = relationship(back_populates="observations")


# ── Reports ──────────────────────────────────────────────────────────────────

class Report(Base):
    """A structured OSINT intelligence report."""

    __tablename__ = "reports"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    report_id: Mapped[str] = mapped_column(String(100), nullable=False, unique=True)
    subject: Mapped[str] = mapped_column(String(500), nullable=False)
    subject_type: Mapped[str] = mapped_column(String(50), nullable=False)
    classification: Mapped[str] = mapped_column(String(20), default="TLP:WHITE")
    confidence: Mapped[str] = mapped_column(String(10), default="MEDIUM")
    confidence_score: Mapped[float] = mapped_column(Float, default=0.5)
    analyst_bots: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    tags: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    related_report_ids: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    executive_summary: Mapped[str] = mapped_column(Text, nullable=False)
    key_findings: Mapped[dict] = mapped_column(JSON, default=dict)
    entity_map: Mapped[dict] = mapped_column(JSON, default=dict)
    timeline: Mapped[list[dict]] = mapped_column(JSON, default=list)
    behavioral_indicators: Mapped[list[dict]] = mapped_column(JSON, default=list)
    threat_assessment: Mapped[dict] = mapped_column(JSON, default=dict)
    source_log: Mapped[list[dict]] = mapped_column(JSON, default=list)
    gaps: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    analyst_notes: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    full_markdown: Mapped[str] = mapped_column(Text, nullable=False)
    embedding: Mapped[list[float] | None] = mapped_column(Vector(1024), nullable=True)
    google_drive_file_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    collection_started: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    collection_completed: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=_now, onupdate=_now)

    panel_sessions: Mapped[list["PanelSession"]] = relationship(back_populates="report")


# ── Panel Sessions ────────────────────────────────────────────────────────────

class PanelSession(Base):
    """A 3-AI analyst panel session record."""

    __tablename__ = "panel_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    session_id: Mapped[str] = mapped_column(String(50), nullable=False, unique=True)
    report_id: Mapped[str | None] = mapped_column(ForeignKey("reports.id"), nullable=True)
    topic: Mapped[str] = mapped_column(String(1000), nullable=False)
    target: Mapped[str] = mapped_column(String(500), nullable=False)
    transcript: Mapped[list[dict]] = mapped_column(JSON, default=list)
    positions: Mapped[dict] = mapped_column(JSON, default=dict)
    covered_topics: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    disagreements: Mapped[list[dict]] = mapped_column(JSON, default=list)
    rounds_completed: Mapped[int] = mapped_column(Integer, default=0)
    final_synthesis: Mapped[str | None] = mapped_column(Text, nullable=True)
    concluded: Mapped[bool] = mapped_column(Boolean, default=False)
    google_drive_file_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    start_time: Mapped[datetime] = mapped_column(DateTime, default=_now)
    end_time: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    report: Mapped["Report"] = relationship(back_populates="panel_sessions")


# ── IOCs ──────────────────────────────────────────────────────────────────────

class IOC(Base):
    """Indicator of Compromise."""

    __tablename__ = "iocs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    ioc_type: Mapped[str] = mapped_column(String(50), nullable=False)  # ip/domain/hash/url/email
    value: Mapped[str] = mapped_column(String(1000), nullable=False)
    malicious_score: Mapped[float] = mapped_column(Float, default=0.0)
    tags: Mapped[list[str]] = mapped_column(ARRAY(String), default=list)
    source: Mapped[str] = mapped_column(String(100), nullable=False)
    metadata_: Mapped[dict] = mapped_column("metadata", JSON, default=dict)
    first_seen: Mapped[datetime] = mapped_column(DateTime, default=_now)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=_now)
    expires: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    __table_args__ = (UniqueConstraint("ioc_type", "value", name="uq_ioc_type_value"),)


# ── Collection Tasks ──────────────────────────────────────────────────────────

class CollectionTask(Base):
    """A scheduled or on-demand collection task."""

    __tablename__ = "collection_tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid)
    target: Mapped[str] = mapped_column(String(500), nullable=False)
    target_type: Mapped[str] = mapped_column(String(50), nullable=False)
    requestor: Mapped[str] = mapped_column(String(100), default="system")
    priority: Mapped[str] = mapped_column(String(20), default="normal")
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending/running/complete/failed
    celery_task_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    result_report_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
