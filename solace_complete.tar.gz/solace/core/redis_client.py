"""
SOLACE — Redis Client
Async Redis connection pool for cache, pub/sub, and Celery broker.
"""
from __future__ import annotations

from typing import Any

import redis.asyncio as aioredis

from config import get_logger, settings

logger = get_logger("redis")

_pool: aioredis.ConnectionPool | None = None


def get_pool() -> aioredis.ConnectionPool:
    """Get or create the Redis connection pool."""
    global _pool
    if _pool is None:
        _pool = aioredis.ConnectionPool.from_url(
            settings.redis_url,
            max_connections=50,
            decode_responses=True,
        )
    return _pool


def get_redis() -> aioredis.Redis:
    """Get a Redis client from the connection pool."""
    return aioredis.Redis(connection_pool=get_pool())


async def close_redis() -> None:
    """Close the Redis connection pool."""
    global _pool
    if _pool:
        await _pool.disconnect()
        _pool = None
        logger.info("redis_pool_closed")


class RedisCache:
    """High-level Redis cache operations for SOLACE."""

    def __init__(self) -> None:
        self._client = get_redis()

    async def get(self, key: str) -> Any | None:
        """Get a cached value by key."""
        import json
        value = await self._client.get(f"solace:{key}")
        if value is None:
            return None
        try:
            return json.loads(value)
        except (json.JSONDecodeError, TypeError):
            return value

    async def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        """Set a cached value with TTL in seconds."""
        import json
        serialized = json.dumps(value) if not isinstance(value, str) else value
        await self._client.setex(f"solace:{key}", ttl, serialized)

    async def delete(self, key: str) -> None:
        """Delete a cached key."""
        await self._client.delete(f"solace:{key}")

    async def publish(self, channel: str, message: dict) -> None:
        """Publish a message to a Redis pub/sub channel."""
        import json
        await self._client.publish(f"solace:{channel}", json.dumps(message))

    async def lpush(self, key: str, value: Any) -> None:
        """Push a value to the left of a Redis list."""
        import json
        serialized = json.dumps(value) if not isinstance(value, str) else value
        await self._client.lpush(f"solace:{key}", serialized)

    async def lrange(self, key: str, start: int = 0, end: int = -1) -> list[Any]:
        """Get a range of values from a Redis list."""
        import json
        values = await self._client.lrange(f"solace:{key}", start, end)
        result = []
        for v in values:
            try:
                result.append(json.loads(v))
            except (json.JSONDecodeError, TypeError):
                result.append(v)
        return result


cache = RedisCache()
