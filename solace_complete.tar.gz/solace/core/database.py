"""
SOLACE — Database Engine & Session Management
Async SQLAlchemy 2.0 with connection pooling.
"""
from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from config import get_logger, settings

logger = get_logger("database")


class Base(DeclarativeBase):
    """Declarative base for all ORM models."""
    pass


def _create_engine() -> AsyncEngine:
    """Create the async SQLAlchemy engine with appropriate pool settings."""
    return create_async_engine(
        settings.postgres_url,
        echo=settings.debug,
        pool_size=20,
        max_overflow=10,
        pool_pre_ping=True,
        pool_recycle=3600,
    )


engine: AsyncEngine = _create_engine()

AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Async context manager for database sessions with automatic rollback on error.

    Yields:
        AsyncSession: An active database session.

    Raises:
        Exception: Re-raises any exception after rolling back the transaction.
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception as exc:
            await session.rollback()
            logger.error("database_session_error", error=str(exc), exc_info=True)
            raise


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for injecting database sessions."""
    async with get_db_session() as session:
        yield session


async def init_db() -> None:
    """Initialize database — create all tables and extensions."""
    async with engine.begin() as conn:
        await conn.execute(__import__("sqlalchemy").text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.run_sync(Base.metadata.create_all)
    logger.info("database_initialized", url=settings.postgres_url.split("@")[-1])


async def close_db() -> None:
    """Dispose the engine connection pool on shutdown."""
    await engine.dispose()
    logger.info("database_connection_pool_closed")
