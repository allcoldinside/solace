"""
SOLACE — FastAPI Application
Main API server with all routers, middleware, and WebSocket for live panel streaming.
"""
from __future__ import annotations

import asyncio
import json
import uuid
from contextlib import asynccontextmanager
from datetime import datetime

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import select, desc
from sqlalchemy.ext.asyncio import AsyncSession

from config import configure_logging, get_logger, settings
from core.database import get_db, init_db, close_db
from core.models import Report, PanelSession as PanelSessionModel, CollectionTask, Entity
from core.schemas import (
    Alert, Classification, CollectionTaskCreate, CollectionTaskStatus,
    HealthResponse, PanelSessionCreate, PanelSessionSummary, ReportSummary,
)

configure_logging(settings.log_level)
logger = get_logger("api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan — startup and shutdown."""
    logger.info("solace_api_starting", version=settings.app_version)
    await init_db()
    yield
    await close_db()
    logger.info("solace_api_stopped")


app = FastAPI(
    title="SOLACE Intelligence Platform API",
    version=settings.app_version,
    description="Solo OSINT & Layered Analysis with Collaborative Experts",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/api/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    """Platform health check."""
    return HealthResponse(
        status="operational",
        version=settings.app_version,
        services={
            "api": "up",
            "database": "up",
            "panel_engine": "ready",
        },
    )


# ── Reports ───────────────────────────────────────────────────────────────────

@app.get("/api/reports", tags=["Reports"])
async def list_reports(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    classification: str | None = None,
    confidence: str | None = None,
    tag: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    """List intelligence reports with filtering and pagination."""
    query = select(Report).order_by(desc(Report.created_at))

    if classification:
        query = query.where(Report.classification == classification)
    if confidence:
        query = query.where(Report.confidence == confidence)
    if tag:
        query = query.where(Report.tags.contains([tag]))

    offset = (page - 1) * page_size
    result = await db.execute(query.offset(offset).limit(page_size))
    reports = result.scalars().all()

    return {
        "items": [
            {
                "id": str(r.id), "report_id": r.report_id, "subject": r.subject,
                "subject_type": r.subject_type, "classification": r.classification,
                "confidence": r.confidence, "confidence_score": r.confidence_score,
                "tags": r.tags, "executive_summary": r.executive_summary[:300],
                "created_at": r.created_at.isoformat(),
            }
            for r in reports
        ],
        "page": page,
        "page_size": page_size,
    }


@app.get("/api/reports/{report_id}", tags=["Reports"])
async def get_report(report_id: str, db: AsyncSession = Depends(get_db)):
    """Get a full report by SOLACE report ID or database ID."""
    result = await db.execute(
        select(Report).where(
            (Report.report_id == report_id) | (Report.id == report_id)
        )
    )
    report = result.scalar_one_or_none()
    if not report:
        raise HTTPException(status_code=404, detail=f"Report '{report_id}' not found")

    return {
        "id": str(report.id),
        "report_id": report.report_id,
        "subject": report.subject,
        "subject_type": report.subject_type,
        "classification": report.classification,
        "confidence": report.confidence,
        "confidence_score": report.confidence_score,
        "analyst_bots": report.analyst_bots,
        "tags": report.tags,
        "executive_summary": report.executive_summary,
        "key_findings": report.key_findings,
        "entity_map": report.entity_map,
        "timeline": report.timeline,
        "behavioral_indicators": report.behavioral_indicators,
        "threat_assessment": report.threat_assessment,
        "source_log": report.source_log,
        "gaps": report.gaps,
        "analyst_notes": report.analyst_notes,
        "full_markdown": report.full_markdown,
        "google_drive_file_id": report.google_drive_file_id,
        "created_at": report.created_at.isoformat(),
    }


@app.get("/api/reports/search", tags=["Reports"])
async def search_reports(q: str = Query(..., min_length=2)):
    """Semantic search over report embeddings using pgvector."""
    from storage.pgvector_client import pgvector_client
    results = await pgvector_client.search_reports(q, limit=20)
    return {"query": q, "results": results}


# ── Collections ───────────────────────────────────────────────────────────────

@app.post("/api/collections", tags=["Collections"])
async def trigger_collection(
    task: CollectionTaskCreate,
    db: AsyncSession = Depends(get_db),
):
    """Trigger a full OSINT collection pipeline for a target."""
    from tasks.collection_tasks import run_full_osint_pipeline

    db_task = CollectionTask(
        target=task.target,
        target_type=task.target_type.value,
        requestor=task.requestor,
        priority=task.priority,
        status="pending",
    )
    db.add(db_task)
    await db.flush()

    try:
        celery_task = run_full_osint_pipeline.delay(
            target=task.target,
            target_type=task.target_type.value,
            requestor=task.requestor,
            priority=task.priority,
        )
        db_task.celery_task_id = celery_task.id
        db_task.status = "queued"
    except Exception as exc:
        db_task.status = "failed"
        db_task.error = str(exc)
        logger.error("collection_dispatch_failed", error=str(exc))

    return {
        "task_id": str(db_task.id),
        "celery_task_id": db_task.celery_task_id,
        "target": task.target,
        "status": db_task.status,
    }


@app.get("/api/collections/{task_id}", tags=["Collections"])
async def get_collection_status(task_id: str, db: AsyncSession = Depends(get_db)):
    """Get the status of a collection task."""
    result = await db.execute(select(CollectionTask).where(CollectionTask.id == task_id))
    task = result.scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    return {
        "id": str(task.id), "target": task.target, "target_type": task.target_type,
        "status": task.status, "celery_task_id": task.celery_task_id,
        "result_report_id": task.result_report_id, "error": task.error,
        "created_at": task.created_at.isoformat(),
        "started_at": task.started_at.isoformat() if task.started_at else None,
        "completed_at": task.completed_at.isoformat() if task.completed_at else None,
    }


# ── Panel Sessions ────────────────────────────────────────────────────────────

@app.post("/api/panel", tags=["Panel"])
async def start_panel_session(
    session_req: PanelSessionCreate,
    db: AsyncSession = Depends(get_db),
):
    """Start a 3-AI panel analysis session. Returns session ID for WebSocket subscription."""
    from tasks.panel_tasks import run_panel_session_task

    session_id = f"SESSION-{uuid.uuid4().hex[:8].upper()}"

    # Dispatch async Celery task
    try:
        task = run_panel_session_task.delay(
            session_id=session_id,
            report_id=session_req.report_id,
            topic=session_req.topic,
            target=session_req.target,
            max_rounds=session_req.max_rounds,
        )
        return {
            "session_id": session_id,
            "celery_task_id": task.id,
            "websocket_url": f"/api/panel/{session_id}/stream",
            "status": "started",
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to start panel: {exc}")


@app.get("/api/panel/{session_id}", tags=["Panel"])
async def get_panel_session(session_id: str, db: AsyncSession = Depends(get_db)):
    """Get a completed panel session by session ID."""
    result = await db.execute(
        select(PanelSessionModel).where(PanelSessionModel.session_id == session_id)
    )
    session = result.scalar_one_or_none()
    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    return {
        "id": str(session.id),
        "session_id": session.session_id,
        "topic": session.topic,
        "target": session.target,
        "transcript": session.transcript,
        "positions": session.positions,
        "disagreements": session.disagreements,
        "covered_topics": session.covered_topics,
        "rounds_completed": session.rounds_completed,
        "final_synthesis": session.final_synthesis,
        "concluded": session.concluded,
        "google_drive_file_id": session.google_drive_file_id,
        "start_time": session.start_time.isoformat(),
        "end_time": session.end_time.isoformat() if session.end_time else None,
    }


# ── WebSocket — Live Panel Streaming ─────────────────────────────────────────

class ConnectionManager:
    """WebSocket connection manager for live panel streaming."""

    def __init__(self) -> None:
        self.active: dict[str, list[WebSocket]] = {}

    async def connect(self, session_id: str, ws: WebSocket) -> None:
        await ws.accept()
        self.active.setdefault(session_id, []).append(ws)

    def disconnect(self, session_id: str, ws: WebSocket) -> None:
        if session_id in self.active:
            self.active[session_id].discard(ws)

    async def broadcast(self, session_id: str, message: dict) -> None:
        for ws in list(self.active.get(session_id, [])):
            try:
                await ws.send_json(message)
            except Exception:
                self.active[session_id].discard(ws)


ws_manager = ConnectionManager()


@app.websocket("/api/panel/{session_id}/stream")
async def panel_stream(session_id: str, websocket: WebSocket):
    """WebSocket endpoint for live panel session transcript streaming."""
    await ws_manager.connect(session_id, websocket)
    try:
        while True:
            # Keep connection alive — panel events are pushed from Celery task
            data = await websocket.receive_text()
            if data == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        ws_manager.disconnect(session_id, websocket)


@app.post("/api/panel/{session_id}/event", include_in_schema=False)
async def push_panel_event(session_id: str, event: dict):
    """Internal endpoint called by Celery tasks to push panel events."""
    await ws_manager.broadcast(session_id, event)
    return {"ok": True}


# ── Entities ──────────────────────────────────────────────────────────────────

@app.get("/api/entities", tags=["Entities"])
async def list_entities(
    entity_type: str | None = None,
    limit: int = Query(50, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
):
    """List known entities from the entity registry."""
    query = select(Entity).order_by(desc(Entity.last_seen)).limit(limit)
    if entity_type:
        query = query.where(Entity.entity_type == entity_type)
    result = await db.execute(query)
    entities = result.scalars().all()
    return {
        "entities": [
            {
                "id": str(e.id), "name": e.name, "entity_type": e.entity_type,
                "aliases": e.aliases, "confidence": e.confidence, "tags": e.tags,
                "first_seen": e.first_seen.isoformat(), "last_seen": e.last_seen.isoformat(),
            }
            for e in entities
        ]
    }
