"""
SOLACE — Report Schema & ID Generation
Defines the canonical report structure and generates consistent report IDs.
"""
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from core.schemas import (
    Classification, ConfidenceLevel, EnrichedIntelItem,
    KeyFinding, SourceLogEntry, TimelineEntry, BehavioralIndicator
)


def generate_report_id(subject: str) -> str:
    """Generate a canonical SOLACE report ID.

    Format: REPORT-{YYYYMMDD}-{SUBJECT_SLUG}-{UUID4[:8].upper()}

    Args:
        subject: The target subject name.

    Returns:
        Formatted report ID string.
    """
    date_str = datetime.utcnow().strftime("%Y%m%d")
    slug = re.sub(r'[^a-zA-Z0-9\s]', '', subject)
    slug = re.sub(r'\s+', '-', slug.strip().upper())[:20]
    uid = uuid.uuid4().hex[:8].upper()
    return f"REPORT-{date_str}-{slug}-{uid}"


def generate_session_id() -> str:
    """Generate a panel session ID."""
    return f"SESSION-{uuid.uuid4().hex[:8].upper()}"


@dataclass
class ReportData:
    """Full structured report data before markdown rendering."""

    report_id: str
    subject: str
    subject_type: str
    classification: str = Classification.WHITE.value
    confidence: str = ConfidenceLevel.MEDIUM.value
    confidence_score: float = 0.5
    analyst_bots: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    related_report_ids: list[str] = field(default_factory=list)
    executive_summary: str = ""
    key_findings: list[KeyFinding] = field(default_factory=list)
    entity_map: dict[str, list[str]] = field(default_factory=dict)
    timeline: list[TimelineEntry] = field(default_factory=list)
    behavioral_indicators: list[BehavioralIndicator] = field(default_factory=list)
    network_analysis: str = ""
    threat_assessment: dict[str, Any] = field(default_factory=dict)
    source_log: list[SourceLogEntry] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    analyst_notes: list[str] = field(default_factory=list)
    raw_data_summary: str = ""
    collection_started: datetime | None = None
    collection_completed: datetime | None = None
    generated_at: datetime = field(default_factory=datetime.utcnow)
    version: str = "1.0"

    def to_markdown(self) -> str:
        """Render the full report as a markdown document.

        Returns:
            Complete markdown string ready for storage and display.
        """
        lines = [
            "---",
            f"# SOLACE INTELLIGENCE REPORT",
            f"**report_id:** {self.report_id}",
            f"**subject:** {self.subject}",
            f"**subject_type:** {self.subject_type}",
            f"**classification:** {self.classification}",
            f"**confidence:** {self.confidence} ({self.confidence_score:.2f})",
            f"**analyst_bots:** {', '.join(self.analyst_bots)}",
            f"**tags:** {', '.join(self.tags)}",
            f"**collection_started:** {self.collection_started.isoformat() if self.collection_started else 'N/A'}",
            f"**collection_completed:** {self.collection_completed.isoformat() if self.collection_completed else 'N/A'}",
            f"**report_generated:** {self.generated_at.isoformat()}",
            f"**version:** {self.version}",
            "---",
            "",
            "## EXECUTIVE SUMMARY",
            "",
            self.executive_summary or "_No summary generated._",
            "",
            "## KEY FINDINGS",
            "",
        ]

        for i, finding in enumerate(self.key_findings, 1):
            lines.extend([
                f"**{i}. {finding.finding}**",
                f"- Confidence: {finding.confidence}",
                f"- Sources: {finding.source_count}",
                f"- First Observed: {finding.first_observed}",
                "",
            ])

        lines.extend(["## ENTITY MAP", ""])

        em = self.entity_map
        if em.get("people"):
            lines.append("### People")
            for p in em["people"]:
                lines.append(f"- {p}")
            lines.append("")

        if em.get("organizations"):
            lines.append("### Organizations")
            for o in em["organizations"]:
                lines.append(f"- {o}")
            lines.append("")

        if em.get("locations"):
            lines.append("### Locations")
            for loc in em["locations"]:
                lines.append(f"- {loc}")
            lines.append("")

        if em.get("infrastructure"):
            lines.append("### Infrastructure")
            for inf in em["infrastructure"]:
                lines.append(f"- {inf}")
            lines.append("")

        lines.extend(["## TIMELINE", ""])
        for entry in self.timeline:
            lines.append(f"- **{entry.timestamp}** — {entry.event} _(Source: {entry.source}, {entry.confidence})_")
        lines.append("")

        lines.extend(["## BEHAVIORAL INDICATORS", ""])
        for bi in self.behavioral_indicators:
            lines.extend([
                f"**{bi.indicator}** [{bi.pattern_type}]",
                f"- Significance: {bi.significance}",
                f"- Confidence: {bi.confidence}",
                "",
            ])

        if self.network_analysis:
            lines.extend(["## NETWORK ANALYSIS", "", self.network_analysis, ""])

        lines.extend(["## THREAT ASSESSMENT", ""])
        ta = self.threat_assessment
        if ta:
            lines.extend([
                f"- **Overall Threat Level:** {ta.get('level', 'N/A')}",
                f"- **Threat Score:** {ta.get('score', 'N/A')}",
                f"- **IOC Count:** {ta.get('ioc_count', 0)}",
                f"- **Summary:** {ta.get('summary', 'No threat indicators identified.')}",
            ])
        else:
            lines.append("_No threat assessment data._")
        lines.append("")

        lines.extend(["## SOURCE LOG", ""])
        for src in self.source_log:
            lines.append(
                f"- `{src.collector}` | {src.source_type} | Reliability: {src.reliability_score:.2f} | "
                f"{src.collected_at} | `{src.content_hash[:12]}...` | {src.url or 'N/A'}"
            )
        lines.append("")

        lines.extend(["## GAPS & COLLECTION REQUIREMENTS", ""])
        for gap in self.gaps:
            lines.append(f"- {gap}")
        lines.append("")

        lines.extend(["## ANALYST NOTES", ""])
        for note in self.analyst_notes:
            lines.append(f"> {note}")
        lines.append("")

        lines.extend([
            "## RAW DATA APPENDIX",
            "",
            f"_Total items collected: {len(self.source_log)}_",
            "_Full raw data stored in MinIO and MongoDB._",
            "",
            "---",
            f"*SOLACE Intelligence Platform v{self.version} — {self.report_id}*",
        ])

        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for database storage."""
        return {
            "report_id": self.report_id,
            "subject": self.subject,
            "subject_type": self.subject_type,
            "classification": self.classification,
            "confidence": self.confidence,
            "confidence_score": self.confidence_score,
            "analyst_bots": self.analyst_bots,
            "tags": self.tags,
            "related_report_ids": self.related_report_ids,
            "executive_summary": self.executive_summary,
            "key_findings": [f.model_dump() for f in self.key_findings],
            "entity_map": self.entity_map,
            "timeline": [t.model_dump() for t in self.timeline],
            "behavioral_indicators": [b.model_dump() for b in self.behavioral_indicators],
            "threat_assessment": self.threat_assessment,
            "source_log": [s.model_dump() for s in self.source_log],
            "gaps": self.gaps,
            "analyst_notes": self.analyst_notes,
            "full_markdown": self.to_markdown(),
            "collection_started": self.collection_started,
            "collection_completed": self.collection_completed,
        }
