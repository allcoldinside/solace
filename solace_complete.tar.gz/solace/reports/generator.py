"""
SOLACE — Report Writer Bot
Assembles fully structured intelligence reports from NLP-enriched intel items.
Uses Claude API for executive summary and behavioral analysis generation.
"""
from __future__ import annotations

import hashlib
from datetime import datetime
from typing import Any

import anthropic

from config import get_logger, settings
from core.schemas import (
    BehavioralIndicator, ConfidenceLevel, EnrichedIntelItem,
    KeyFinding, SourceLogEntry, TimelineEntry,
)
from reports.schema import ReportData, generate_report_id

logger = get_logger("REPORT-WRITER")


class ReportGeneratorBot:
    """Assembles a full SOLACE intelligence report from enriched intel items.

    Uses NLP outputs for entity extraction and structural assembly,
    then calls Claude to write the executive summary and behavioral analysis.
    """

    def __init__(self) -> None:
        self._client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    async def generate(
        self,
        enriched_items: list[EnrichedIntelItem],
        target: str,
        target_type: str,
        collection_started: datetime | None = None,
        collection_completed: datetime | None = None,
        tags: list[str] | None = None,
    ) -> ReportData:
        """Generate a complete intelligence report.

        Args:
            enriched_items: NLP-enriched intel items from all collectors.
            target: Subject of the report.
            target_type: Classification of the target.
            collection_started: When collection began.
            collection_completed: When collection finished.
            tags: Optional subject tags.

        Returns:
            Fully assembled ReportData instance.
        """
        logger.info("report_generation_started", target=target, item_count=len(enriched_items))

        report_id = generate_report_id(target)

        # ── Extract Entity Map ────────────────────────────────────────────
        entity_map = self._build_entity_map(enriched_items)

        # ── Extract Timeline ──────────────────────────────────────────────
        timeline = self._build_timeline(enriched_items, target)

        # ── Extract Source Log ────────────────────────────────────────────
        source_log = self._build_source_log(enriched_items)

        # ── Extract Behavioral Indicators ─────────────────────────────────
        behavioral_indicators = self._extract_behavioral_indicators(enriched_items, target)

        # ── Score Confidence ──────────────────────────────────────────────
        confidence_score, confidence_level = self._score_confidence(enriched_items)

        # ── Detect Threat IOCs ────────────────────────────────────────────
        threat_assessment = self._build_threat_assessment(enriched_items)

        # ── Identify Gaps ─────────────────────────────────────────────────
        gaps = self._identify_gaps(enriched_items, target_type)

        # ── Auto-generate Analyst Notes ───────────────────────────────────
        analyst_notes = self._generate_analyst_notes(enriched_items, entity_map, target)

        # ── Get Analyst Bots Used ─────────────────────────────────────────
        analyst_bots = list({item.collector_id for item in enriched_items})

        # ── AI-Generated Sections (Claude) ────────────────────────────────
        context_digest = self._build_context_digest(enriched_items, entity_map, target)

        executive_summary = await self._generate_executive_summary(
            context_digest, target, target_type, confidence_level.value
        )

        key_findings = await self._generate_key_findings(
            context_digest, target, entity_map
        )

        logger.info("report_generation_complete", report_id=report_id)

        return ReportData(
            report_id=report_id,
            subject=target,
            subject_type=target_type,
            confidence=confidence_level.value,
            confidence_score=confidence_score,
            analyst_bots=analyst_bots,
            tags=tags or self._auto_tag(entity_map, target_type),
            executive_summary=executive_summary,
            key_findings=key_findings,
            entity_map=entity_map,
            timeline=timeline,
            behavioral_indicators=behavioral_indicators,
            threat_assessment=threat_assessment,
            source_log=source_log,
            gaps=gaps,
            analyst_notes=analyst_notes,
            collection_started=collection_started,
            collection_completed=collection_completed,
        )

    def _build_entity_map(self, items: list[EnrichedIntelItem]) -> dict[str, list[str]]:
        """Aggregate and deduplicate NER results across all items."""
        entity_map: dict[str, list[str]] = {
            "people": [], "organizations": [], "locations": [],
            "infrastructure": [], "misc": [],
        }
        seen: set[str] = set()

        type_map = {"PER": "people", "ORG": "organizations", "LOC": "locations", "MISC": "misc"}

        for item in items:
            for etype, entities in item.named_entities.items():
                bucket = type_map.get(etype)
                if not bucket:
                    continue
                for entity in entities:
                    key = entity.lower().strip()
                    if key not in seen and len(key) > 1:
                        seen.add(key)
                        entity_map[bucket].append(entity)

        # Keep top 30 per category
        for key in entity_map:
            entity_map[key] = entity_map[key][:30]

        return entity_map

    def _build_timeline(
        self, items: list[EnrichedIntelItem], target: str
    ) -> list[TimelineEntry]:
        """Build a chronological timeline from collected items."""
        timeline: list[TimelineEntry] = []

        for item in items:
            if not item.collected_at:
                continue
            # Create a concise event description
            snippet = item.content[:150].replace("\n", " ").strip()
            if len(snippet) < 30:
                continue

            timeline.append(TimelineEntry(
                timestamp=item.collected_at.strftime("%Y-%m-%d %H:%M UTC"),
                event=snippet,
                source=item.source_type,
                confidence=ConfidenceLevel.MEDIUM if item.reliability_score >= 0.7 else ConfidenceLevel.LOW,
                significance=f"Observed via {item.collector_id}",
            ))

        # Deduplicate and sort chronologically
        timeline.sort(key=lambda x: x.timestamp)
        return timeline[:50]  # Cap at 50 entries

    def _build_source_log(self, items: list[EnrichedIntelItem]) -> list[SourceLogEntry]:
        """Build the full source provenance log."""
        return [
            SourceLogEntry(
                url=item.source_url,
                collector=item.collector_id,
                source_type=item.source_type,
                collected_at=item.collected_at.isoformat() if item.collected_at else "unknown",
                reliability_score=item.reliability_score,
                content_hash=hashlib.sha256(item.content.encode()).hexdigest(),
            )
            for item in items
        ]

    def _extract_behavioral_indicators(
        self, items: list[EnrichedIntelItem], target: str
    ) -> list[BehavioralIndicator]:
        """Extract behavioral patterns from sentiment and entity analysis."""
        indicators: list[BehavioralIndicator] = []

        # Sentiment trend analysis
        sentiments = [item.sentiment_score for item in items if item.sentiment_score is not None]
        if sentiments:
            avg_sentiment = sum(sentiments) / len(sentiments)
            neg_ratio = sum(1 for s in sentiments if s < -0.3) / len(sentiments)

            if neg_ratio > 0.4:
                indicators.append(BehavioralIndicator(
                    indicator=f"High negative sentiment ratio ({neg_ratio:.1%}) across {len(sentiments)} sources",
                    pattern_type="sentiment_anomaly",
                    significance="Subject associated with predominantly negative public discourse",
                    confidence=ConfidenceLevel.HIGH if len(sentiments) > 10 else ConfidenceLevel.MEDIUM,
                    evidence=[f"Average sentiment score: {avg_sentiment:.3f}"],
                ))

        # Source diversity analysis
        source_types = {item.source_type for item in items}
        if len(source_types) >= 4:
            indicators.append(BehavioralIndicator(
                indicator=f"Multi-vector presence across {len(source_types)} distinct source types",
                pattern_type="presence_breadth",
                significance="Subject has broad open-source footprint — high information density",
                confidence=ConfidenceLevel.HIGH,
                evidence=list(source_types),
            ))

        # Language diversity
        languages = {item.language for item in items if item.language and item.language != "en"}
        if languages:
            indicators.append(BehavioralIndicator(
                indicator=f"Multi-lingual presence detected: {', '.join(languages)}",
                pattern_type="geographic_spread",
                significance="Subject activities span multiple language communities / regions",
                confidence=ConfidenceLevel.MEDIUM,
                evidence=[f"Non-English sources: {len([i for i in items if i.language != 'en'])}"],
            ))

        # Threat IOC presence
        threat_items = [i for i in items if i.source_type in ("otx_alienvault", "virustotal", "greynoise", "abuseipdb")]
        if threat_items:
            indicators.append(BehavioralIndicator(
                indicator=f"Threat intelligence hits across {len(threat_items)} security feeds",
                pattern_type="threat_correlation",
                significance="Subject or associated infrastructure appears in cybersecurity threat databases",
                confidence=ConfidenceLevel.HIGH,
                evidence=[i.source_type for i in threat_items],
            ))

        return indicators

    def _score_confidence(
        self, items: list[EnrichedIntelItem]
    ) -> tuple[float, ConfidenceLevel]:
        """Calculate overall report confidence score."""
        if not items:
            return 0.1, ConfidenceLevel.LOW

        avg_reliability = sum(i.reliability_score for i in items) / len(items)
        source_diversity = min(len({i.source_type for i in items}) / 8.0, 1.0)
        volume_factor = min(len(items) / 20.0, 1.0)

        score = (avg_reliability * 0.5) + (source_diversity * 0.3) + (volume_factor * 0.2)
        score = round(score, 3)

        if score >= 0.7:
            return score, ConfidenceLevel.HIGH
        elif score >= 0.45:
            return score, ConfidenceLevel.MEDIUM
        else:
            return score, ConfidenceLevel.LOW

    def _build_threat_assessment(self, items: list[EnrichedIntelItem]) -> dict[str, Any]:
        """Build threat assessment from threat feed items."""
        threat_items = [i for i in items if i.source_type in (
            "otx_alienvault", "virustotal", "greynoise", "abuseipdb", "cisa_advisory", "opensanctions"
        )]

        ioc_count = len([i for i in items if "ioc" in i.source_type or i.source_type in ("virustotal", "otx_alienvault")])
        sanctions_hits = len([i for i in items if i.source_type == "opensanctions"])

        if sanctions_hits > 0:
            level = "CRITICAL"
            score = 9.5
        elif len(threat_items) >= 3:
            level = "HIGH"
            score = 7.5
        elif len(threat_items) >= 1:
            level = "MEDIUM"
            score = 5.0
        else:
            level = "LOW"
            score = 2.0

        return {
            "level": level,
            "score": score,
            "ioc_count": ioc_count,
            "sanctions_hits": sanctions_hits,
            "threat_feed_hits": len(threat_items),
            "summary": f"{'Sanctions match detected — IMMEDIATE REVIEW REQUIRED. ' if sanctions_hits else ''}"
                       f"{len(threat_items)} threat intelligence source(s) mention this subject.",
        }

    def _identify_gaps(self, items: list[EnrichedIntelItem], target_type: str) -> list[str]:
        """Identify collection gaps for analyst awareness."""
        gaps = []
        source_types_collected = {i.source_type for i in items}

        gap_map = {
            "organization": [
                ("sec_edgar", "No SEC/financial filing data — consider manual EDGAR search"),
                ("opencorporates", "No corporate registry data — ownership structure unknown"),
                ("opensanctions", "Sanctions check not performed or returned no results"),
            ],
            "person": [
                ("twitter_nitter", "No social media footprint captured — verify manually"),
                ("academic_paper", "No academic or professional publication record found"),
            ],
            "infrastructure": [
                ("shodan", "No Shodan scan data — exposed services unknown"),
                ("censys", "No Censys certificate data — TLS infrastructure unmapped"),
                ("dns_records", "No DNS records captured"),
            ],
        }

        for source_type, gap_msg in gap_map.get(target_type, []):
            if source_type not in source_types_collected:
                gaps.append(gap_msg)

        if len(items) < 10:
            gaps.append("Low total item count — collection may be incomplete; consider re-running with extended parameters")

        non_english = [i for i in items if i.language != "en"]
        if not non_english:
            gaps.append("No non-English sources captured — international/regional coverage may be missing")

        return gaps

    def _generate_analyst_notes(
        self,
        items: list[EnrichedIntelItem],
        entity_map: dict,
        target: str,
    ) -> list[str]:
        """Generate automated analyst flags for the AI panel."""
        notes = []

        if len(entity_map.get("people", [])) > 10:
            notes.append(f"Note: {len(entity_map['people'])} distinct individuals identified — high network complexity")

        if len(entity_map.get("organizations", [])) > 8:
            notes.append(f"Note: {len(entity_map['organizations'])} organizations in entity map — complex org structure")

        aliases = [i for i in items if "alias" in i.content.lower() or "also known as" in i.content.lower()]
        if aliases:
            notes.append(f"Note: Subject may have {len(aliases)} alias reference(s) — verify identity consolidation")

        high_reliability = [i for i in items if i.reliability_score >= 0.9]
        if high_reliability:
            notes.append(f"Note: {len(high_reliability)} items from authoritative sources (reliability ≥ 0.90) — strong factual foundation")

        neg_items = [i for i in items if i.sentiment_score and i.sentiment_score < -0.5]
        if len(neg_items) > 5:
            notes.append(f"Note: {len(neg_items)} strongly negative items detected — potential controversy or adverse history")

        return notes

    def _auto_tag(self, entity_map: dict, target_type: str) -> list[str]:
        """Auto-generate tags from entity map and target type."""
        tags = [target_type]
        if entity_map.get("locations"):
            tags.append("geo-tagged")
        if entity_map.get("organizations"):
            tags.append("multi-org")
        return tags

    def _build_context_digest(
        self,
        items: list[EnrichedIntelItem],
        entity_map: dict,
        target: str,
    ) -> str:
        """Build a condensed context string for Claude API calls."""
        top_items = sorted(items, key=lambda x: x.reliability_score, reverse=True)[:15]
        snippets = []
        for item in top_items:
            content = (item.content_en or item.content)[:400].replace("\n", " ")
            snippets.append(f"[{item.source_type} | rel:{item.reliability_score:.2f}]: {content}")

        return (
            f"TARGET: {target}\n"
            f"ENTITIES IDENTIFIED — People: {entity_map.get('people', [])[:5]} | "
            f"Orgs: {entity_map.get('organizations', [])[:5]} | "
            f"Locations: {entity_map.get('locations', [])[:5]}\n\n"
            f"TOP INTELLIGENCE ITEMS ({len(top_items)} of {len(items)} total):\n\n"
            + "\n\n".join(snippets)
        )

    async def _generate_executive_summary(
        self,
        context: str,
        target: str,
        target_type: str,
        confidence: str,
    ) -> str:
        """Use Claude to write the executive summary."""
        try:
            import asyncio
            loop = asyncio.get_event_loop()

            def _call():
                return self._client.messages.create(
                    model="claude-opus-4-5",
                    max_tokens=800,
                    system=(
                        "You are a senior intelligence analyst writing for a classified briefing. "
                        "Write a precise, factual executive summary. No speculation beyond the evidence. "
                        "Structure: Who → What → Where → When → Why it matters. "
                        "Tone: CIA all-source analyst. 2-3 paragraphs. No bullet points."
                    ),
                    messages=[{
                        "role": "user",
                        "content": (
                            f"Write an executive summary for this OSINT report on '{target}' (type: {target_type}).\n"
                            f"Overall confidence: {confidence}\n\n"
                            f"INTELLIGENCE DIGEST:\n{context}"
                        ),
                    }],
                )

            response = await loop.run_in_executor(None, _call)
            return response.content[0].text

        except Exception as exc:
            logger.error("executive_summary_generation_failed", error=str(exc))
            return (
                f"Intelligence collection on '{target}' completed with {confidence} confidence. "
                f"Refer to Key Findings and Source Log for detailed analysis."
            )

    async def _generate_key_findings(
        self,
        context: str,
        target: str,
        entity_map: dict,
    ) -> list[KeyFinding]:
        """Use Claude to generate structured key findings."""
        try:
            import asyncio, json
            loop = asyncio.get_event_loop()

            def _call():
                return self._client.messages.create(
                    model="claude-opus-4-5",
                    max_tokens=1000,
                    system=(
                        "You are an intelligence analyst. Extract key findings from collected intelligence. "
                        "Respond ONLY with a JSON array. No markdown. No preamble. "
                        "Each item: {\"finding\": str, \"confidence\": \"HIGH\"|\"MEDIUM\"|\"LOW\", "
                        "\"source_count\": int, \"first_observed\": str, \"evidence\": [str]}. "
                        "Maximum 8 findings. Only include findings directly supported by evidence."
                    ),
                    messages=[{
                        "role": "user",
                        "content": f"Extract key findings for target '{target}':\n\n{context}",
                    }],
                )

            response = await loop.run_in_executor(None, _call)
            raw_text = response.content[0].text.strip()

            # Strip any markdown fences
            raw_text = raw_text.replace("```json", "").replace("```", "").strip()
            findings_data = json.loads(raw_text)

            findings = []
            for i, f in enumerate(findings_data[:8], 1):
                findings.append(KeyFinding(
                    number=i,
                    finding=f.get("finding", ""),
                    confidence=ConfidenceLevel(f.get("confidence", "MEDIUM")),
                    source_count=f.get("source_count", 1),
                    first_observed=f.get("first_observed", "Unknown"),
                    evidence=f.get("evidence", []),
                ))
            return findings

        except Exception as exc:
            logger.error("key_findings_generation_failed", error=str(exc))
            return [KeyFinding(
                number=1,
                finding=f"Intelligence collected on {target} — see source log for details",
                confidence=ConfidenceLevel.MEDIUM,
                source_count=0,
                first_observed="N/A",
            )]


report_generator = ReportGeneratorBot()
