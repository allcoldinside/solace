"""
SOLACE — Full Test Suite
Tests for all pure-logic modules. No live DB, AI API, or network calls required.
"""
from __future__ import annotations

import os
import sys

# ── Minimal env so settings can load ─────────────────────────────────────────
os.environ.setdefault("SECRET_KEY", "test_secret_key_minimum_32_characters_x")
os.environ.setdefault("POSTGRES_URL", "postgresql+asyncpg://solace:solace@localhost:5432/solace")
os.environ.setdefault("MONGODB_URL", "mongodb://solace:solace@localhost:27017/solace")
os.environ.setdefault("NEO4J_PASSWORD", "testpassword")
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")
os.environ.setdefault("CLICKHOUSE_PASSWORD", "testpassword")
os.environ.setdefault("MINIO_ACCESS_KEY", "testkey")
os.environ.setdefault("MINIO_SECRET_KEY", "testsecret")
os.environ.setdefault("ANTHROPIC_API_KEY", "sk-ant-test-placeholder")
os.environ.setdefault("OPENAI_API_KEY", "sk-test-placeholder")
os.environ.setdefault("GOOGLE_AI_API_KEY", "test-placeholder")

import pytest
from datetime import datetime


# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def make_raw_item(**overrides):
    """Build a minimal valid RawIntelItemSchema."""
    from core.schemas import RawIntelItemSchema
    defaults = dict(
        collector_id="SPIDER-1",
        source_url="https://example.com/article",
        source_type="news_rss",
        content="Acme Corporation announced record profits in Q3 2025. " * 3,
        language="en",
        target="Acme Corporation",
        target_type="organization",
        reliability_score=0.75,
        metadata={},
    )
    defaults.update(overrides)
    return RawIntelItemSchema(**defaults)


def make_enriched_item(**overrides):
    """Build a minimal valid EnrichedIntelItem."""
    from core.schemas import EnrichedIntelItem
    defaults = dict(
        collector_id="SPIDER-1",
        source_url="https://example.com",
        source_type="news_rss",
        content="Acme Corporation announced record profits in Q3 2025. " * 3,
        language="en",
        target="Acme Corporation",
        target_type="organization",
        reliability_score=0.75,
        metadata={},
        collected_at=datetime.utcnow(),
        named_entities={"PER": ["John Smith"], "ORG": ["Acme Corporation"], "LOC": ["London"], "MISC": []},
        sentiment_score=0.45,
        sentiment_label="positive",
        keywords=["profits", "expansion", "CEO"],
        embedding=[0.1] * 1024,
    )
    defaults.update(overrides)
    return EnrichedIntelItem(**defaults)


def make_collection_result(items=None, collector_id="SPIDER-1",
                           target="Acme Corporation", target_type="organization"):
    """Build a CollectionResult."""
    from core.schemas import CollectionResult
    return CollectionResult(
        collector_id=collector_id,
        target=target,
        target_type=target_type,
        items=items if items is not None else [make_raw_item()],
        duration_seconds=1.5,
        errors=[],
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 1 · SETTINGS & CONFIG
# ═══════════════════════════════════════════════════════════════════════════════

class TestSettings:
    def test_loads_without_error(self):
        from config.settings import settings
        assert settings.app_name == "SOLACE"

    def test_version(self):
        from config.settings import settings
        assert settings.app_version == "1.0.0"

    def test_defaults(self):
        from config.settings import settings
        assert settings.max_panel_rounds == 6
        assert settings.loop_detection_threshold == 0.65
        assert settings.default_classification == "TLP:WHITE"
        assert settings.panel_max_tokens == 1500
        assert settings.environment == "production"

    def test_secret_key_min_length(self):
        from config.settings import settings
        assert len(settings.secret_key) >= 32

    def test_celery_broker_defaults_to_redis(self):
        from config.settings import settings
        assert "redis" in settings.celery_broker_url.lower()
        assert "redis" in settings.celery_result_backend.lower()


# ═══════════════════════════════════════════════════════════════════════════════
# 2 · SCHEMAS & ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

class TestSchemas:
    def test_target_type_values(self):
        from core.schemas import TargetType
        assert TargetType.ORGANIZATION.value == "organization"
        assert TargetType.PERSON.value == "person"
        assert TargetType.THREAT_ACTOR.value == "threat_actor"

    def test_classification_values(self):
        from core.schemas import Classification
        assert Classification.WHITE.value == "TLP:WHITE"
        assert Classification.RED.value == "TLP:RED"
        assert Classification.AMBER.value == "TLP:AMBER"
        assert Classification.GREEN.value == "TLP:GREEN"

    def test_analyst_ids(self):
        from core.schemas import AnalystID
        assert AnalystID.CLAUDE.value == "ANALYST-ALPHA"
        assert AnalystID.CHATGPT.value == "ANALYST-BRAVO"
        assert AnalystID.GEMINI.value == "SESSION-DIRECTOR"

    def test_panel_status_values(self):
        from core.schemas import PanelStatus
        assert PanelStatus.ACTIVE.value == "ACTIVE"
        assert PanelStatus.CONCLUDING.value == "CONCLUDING"
        assert PanelStatus.LOOP_BREAK.value == "LOOP-BREAK"
        assert PanelStatus.REDIRECTING.value == "REDIRECTING"

    def test_raw_intel_item_validates(self):
        item = make_raw_item()
        assert item.collector_id == "SPIDER-1"
        assert item.reliability_score == 0.75
        assert item.source_type == "news_rss"

    def test_raw_intel_item_default_reliability(self):
        from core.schemas import RawIntelItemSchema
        item = RawIntelItemSchema(
            collector_id="SPIDER-1", source_type="test",
            content="x" * 100, target="T", target_type="organization",
        )
        assert item.reliability_score == 0.5

    def test_key_finding_validates(self):
        from core.schemas import KeyFinding, ConfidenceLevel
        kf = KeyFinding(
            number=1, finding="Subject has offshore accounts",
            confidence=ConfidenceLevel.HIGH, source_count=4,
            first_observed="2025-01-15",
            evidence=["Reuters article", "SEC filing"],
        )
        assert kf.confidence == ConfidenceLevel.HIGH
        assert kf.source_count == 4
        assert len(kf.evidence) == 2

    def test_alert_validates(self):
        from core.schemas import Alert, Classification
        alert = Alert(
            alert_id="ALERT-TEST001", title="Test Alert",
            body="Collection complete",
            classification=Classification.GREEN,
            report_id="REPORT-20250412-TEST-AB123456",
            tags=["test", "org"],
        )
        assert alert.alert_id == "ALERT-TEST001"
        assert alert.classification == Classification.GREEN

    def test_panel_session_create_defaults(self):
        from core.schemas import PanelSessionCreate
        req = PanelSessionCreate(topic="Assessment", target="Acme Corp")
        assert req.max_rounds == 6
        assert req.report_id is None

    def test_disagreement_schema(self):
        from core.schemas import Disagreement
        d = Disagreement(
            round_number=3, topic="Threat level",
            alpha_position="HIGH threat", bravo_position="MEDIUM threat",
            director_note="Both preserved",
        )
        assert d.round_number == 3
        assert "HIGH" in d.alpha_position

    def test_collection_result_validates(self):
        result = make_collection_result()
        assert result.collector_id == "SPIDER-1"
        assert len(result.items) == 1
        assert result.duration_seconds == 1.5

    def test_enriched_item_extends_raw(self):
        item = make_enriched_item()
        assert item.collector_id == "SPIDER-1"
        assert item.sentiment_score == 0.45
        assert item.sentiment_label == "positive"
        assert len(item.keywords) == 3
        assert len(item.embedding) == 1024
        assert "John Smith" in item.named_entities.get("PER", [])


# ═══════════════════════════════════════════════════════════════════════════════
# 3 · REPORT SCHEMA & GENERATION
# ═══════════════════════════════════════════════════════════════════════════════

class TestReportSchema:
    def test_report_id_prefix(self):
        from reports.schema import generate_report_id
        rid = generate_report_id("Acme Corp")
        assert rid.startswith("REPORT-")

    def test_report_id_date_segment(self):
        from reports.schema import generate_report_id
        rid = generate_report_id("Target")
        parts = rid.split("-")
        assert len(parts[1]) == 8
        assert parts[1].isdigit()

    def test_report_id_uid_uppercase(self):
        from reports.schema import generate_report_id
        rid = generate_report_id("Target")
        uid = rid.split("-")[-1]
        assert uid == uid.upper()
        assert len(uid) == 8

    def test_report_id_strips_specials(self):
        from reports.schema import generate_report_id
        rid = generate_report_id("Acme & Partners LLC !!!")
        assert " " not in rid
        assert "&" not in rid
        assert "!" not in rid

    def test_report_ids_unique(self):
        from reports.schema import generate_report_id
        ids = {generate_report_id("Target") for _ in range(20)}
        assert len(ids) == 20

    def test_session_id_format(self):
        from reports.schema import generate_session_id
        sid = generate_session_id()
        assert sid.startswith("SESSION-")
        assert len(sid) == 16
        assert sid[8:].isupper()

    def test_session_ids_unique(self):
        from reports.schema import generate_session_id
        ids = {generate_session_id() for _ in range(20)}
        assert len(ids) == 20

    def _make_report(self):
        from reports.schema import ReportData, generate_report_id
        from core.schemas import KeyFinding, ConfidenceLevel, SourceLogEntry
        return ReportData(
            report_id=generate_report_id("Test Corp"),
            subject="Test Corp",
            subject_type="organization",
            executive_summary="This is a test executive summary of intelligence collected on Test Corp.",
            key_findings=[
                KeyFinding(number=1, finding="Subject has significant financial exposure",
                           confidence=ConfidenceLevel.HIGH, source_count=5,
                           first_observed="2025-01-01",
                           evidence=["Reuters", "SEC EDGAR"])
            ],
            entity_map={
                "people": ["Alice Smith", "Bob Jones"],
                "organizations": ["Test Corp", "Beta LLC"],
                "locations": ["London", "New York"],
            },
            source_log=[
                SourceLogEntry(url="https://reuters.com/article", collector="SPIDER-1",
                               source_type="news_rss", collected_at=datetime.utcnow().isoformat(),
                               reliability_score=0.85, content_hash="abc123def456")
            ],
            gaps=["No dark web presence detected", "Financial history incomplete"],
            analyst_notes=["Note: 3 high-reliability sources confirm expansion"],
            collection_started=datetime.utcnow(),
            collection_completed=datetime.utcnow(),
        )

    def test_markdown_has_all_sections(self):
        r = self._make_report()
        md = r.to_markdown()
        for section in [
            "EXECUTIVE SUMMARY", "KEY FINDINGS", "ENTITY MAP",
            "TIMELINE", "BEHAVIORAL INDICATORS", "SOURCE LOG",
            "GAPS", "ANALYST NOTES", r.report_id, r.subject,
        ]:
            assert section in md, f"Missing section: {section}"

    def test_markdown_contains_finding(self):
        r = self._make_report()
        md = r.to_markdown()
        assert "financial exposure" in md

    def test_markdown_contains_entities(self):
        r = self._make_report()
        md = r.to_markdown()
        assert "Alice Smith" in md
        assert "London" in md

    def test_markdown_contains_source(self):
        r = self._make_report()
        md = r.to_markdown()
        assert "SPIDER-1" in md
        assert "abc123def456" in md

    def test_to_dict_keys(self):
        r = self._make_report()
        d = r.to_dict()
        for key in ["report_id", "subject", "subject_type", "classification",
                    "confidence", "confidence_score", "executive_summary",
                    "key_findings", "entity_map", "timeline",
                    "source_log", "gaps", "analyst_notes", "full_markdown"]:
            assert key in d, f"Missing key: {key}"

    def test_to_dict_full_markdown_non_empty(self):
        r = self._make_report()
        d = r.to_dict()
        assert len(d["full_markdown"]) > 500

    def test_default_classification_white(self):
        from reports.schema import ReportData, generate_report_id
        from core.schemas import Classification
        r = ReportData(report_id=generate_report_id("X"), subject="X",
                       subject_type="organization", executive_summary="s")
        assert r.classification == Classification.WHITE.value

    def test_default_confidence_medium(self):
        from reports.schema import ReportData, generate_report_id
        from core.schemas import ConfidenceLevel
        r = ReportData(report_id=generate_report_id("X"), subject="X",
                       subject_type="organization", executive_summary="s")
        assert r.confidence == ConfidenceLevel.MEDIUM.value
        assert r.confidence_score == 0.5


# ═══════════════════════════════════════════════════════════════════════════════
# 4 · COLLECTOR — BASE & AGGREGATOR
# ═══════════════════════════════════════════════════════════════════════════════

class TestBaseCollector:
    def test_content_hash_deterministic(self):
        from collectors.base_collector import BaseCollector
        h1 = BaseCollector._content_hash("hello world intel")
        h2 = BaseCollector._content_hash("hello world intel")
        assert h1 == h2

    def test_content_hash_sha256_length(self):
        from collectors.base_collector import BaseCollector
        h = BaseCollector._content_hash("test content")
        assert len(h) == 64

    def test_content_hash_different_inputs(self):
        from collectors.base_collector import BaseCollector
        h1 = BaseCollector._content_hash("content A about Acme Corp")
        h2 = BaseCollector._content_hash("content B about Beta Corp")
        assert h1 != h2

    def test_content_hash_empty_string(self):
        from collectors.base_collector import BaseCollector
        h = BaseCollector._content_hash("")
        assert len(h) == 64  # SHA-256 of empty string still valid


class TestAggregator:
    def test_deduplicates_identical_content(self):
        from collectors.aggregator import AggregatorBot
        content = "Identical content about Acme Corporation. " * 5
        item1 = make_raw_item(content=content, collector_id="SPIDER-1")
        item2 = make_raw_item(content=content, collector_id="SPIDER-2",
                              source_url="https://other.com")
        result = make_collection_result(items=[item1, item2])
        merged = AggregatorBot().process([result])
        assert len(merged) == 1

    def test_keeps_unique_content(self):
        from collectors.aggregator import AggregatorBot
        items = [
            make_raw_item(content=f"Unique intelligence item number {i} about the target. " * 4,
                          source_url=f"https://source{i}.com")
            for i in range(5)
        ]
        result = make_collection_result(items=items)
        merged = AggregatorBot().process([result])
        assert len(merged) == 5

    def test_filters_content_under_80_chars(self):
        from collectors.aggregator import AggregatorBot
        item = make_raw_item(content="Too short")
        result = make_collection_result(items=[item])
        merged = AggregatorBot().process([result])
        assert len(merged) == 0

    def test_keeps_content_exactly_80_chars(self):
        from collectors.aggregator import AggregatorBot
        item = make_raw_item(content="A" * 80)
        result = make_collection_result(items=[item])
        merged = AggregatorBot().process([result])
        assert len(merged) == 1

    def test_normalizes_reliability_score(self):
        from collectors.aggregator import AggregatorBot, SOURCE_RELIABILITY
        item = make_raw_item(source_type="cisa_advisory", reliability_score=0.1)
        result = make_collection_result(items=[item])
        merged = AggregatorBot().process([result])
        assert merged[0].reliability_score == SOURCE_RELIABILITY["cisa_advisory"]
        assert merged[0].reliability_score == 0.98

    def test_sorts_by_reliability_descending(self):
        from collectors.aggregator import AggregatorBot
        items = [
            make_raw_item(content="C" * 100, source_type="twitter_nitter",
                          source_url="https://a.com"),
            make_raw_item(content="D" * 100, source_type="sec_edgar",
                          source_url="https://b.com"),
            make_raw_item(content="E" * 100, source_type="cisa_advisory",
                          source_url="https://c.com"),
        ]
        result = make_collection_result(items=items)
        merged = AggregatorBot().process([result])
        scores = [m.reliability_score for m in merged]
        assert scores == sorted(scores, reverse=True)

    def test_merges_multiple_collectors(self):
        from collectors.aggregator import AggregatorBot
        results = []
        for i in range(4):
            item = make_raw_item(
                content=f"Spider {i} collected this unique intelligence item. " * 4,
                collector_id=f"SPIDER-{i+1}",
                source_url=f"https://source{i}.com",
            )
            results.append(make_collection_result(items=[item], collector_id=f"SPIDER-{i+1}"))
        merged = AggregatorBot().process(results)
        assert len(merged) == 4

    def test_handles_empty_results(self):
        from collectors.aggregator import AggregatorBot
        merged = AggregatorBot().process([])
        assert merged == []

    def test_handles_all_empty_items(self):
        from collectors.aggregator import AggregatorBot
        result = make_collection_result(items=[])
        merged = AggregatorBot().process([result])
        assert merged == []

    def test_source_reliability_table_completeness(self):
        from collectors.aggregator import SOURCE_RELIABILITY
        expected_sources = [
            "sec_edgar", "cisa_advisory", "opensanctions", "opencorporates",
            "whois", "dns_records", "shodan", "censys", "otx_alienvault",
            "virustotal", "greynoise", "abuseipdb", "news_rss", "hackernews",
            "reddit_post", "twitter_nitter", "web_search_snippet",
            "academic_paper", "onion_content",
        ]
        for src in expected_sources:
            assert src in SOURCE_RELIABILITY, f"Missing reliability entry: {src}"
            assert 0.0 <= SOURCE_RELIABILITY[src] <= 1.0


# ═══════════════════════════════════════════════════════════════════════════════
# 5 · NLP PIPELINE (no heavy models loaded)
# ═══════════════════════════════════════════════════════════════════════════════

class TestNLPPipeline:
    def test_keyword_fallback_extracts_terms(self):
        from nlp.pipeline import _simple_keyword_fallback
        text = ("The intelligence analyst identified suspicious network traffic "
                "originating from Russia targeting NATO infrastructure systems")
        keywords = _simple_keyword_fallback(text)
        assert isinstance(keywords, list)
        assert len(keywords) > 0
        assert any(k in keywords for k in
                   ["intelligence", "analyst", "network", "russia", "nato", "infrastructure"])

    def test_keyword_fallback_removes_stopwords(self):
        from nlp.pipeline import _simple_keyword_fallback
        text = "the a and is was the the the the the and or but"
        keywords = _simple_keyword_fallback(text)
        for stop in ["the", "and", "is", "was", "or", "but"]:
            assert stop not in keywords

    def test_keyword_fallback_max_15(self):
        from nlp.pipeline import _simple_keyword_fallback
        text = " ".join([f"keyword{i}" for i in range(100)])
        keywords = _simple_keyword_fallback(text)
        assert len(keywords) <= 15

    def test_keyword_fallback_empty_text(self):
        from nlp.pipeline import _simple_keyword_fallback
        keywords = _simple_keyword_fallback("")
        assert isinstance(keywords, list)

    def test_keyword_fallback_min_word_length(self):
        from nlp.pipeline import _simple_keyword_fallback
        text = "intelligence analysis cybersecurity osint"
        keywords = _simple_keyword_fallback(text)
        # All words >= 3 chars
        for k in keywords:
            assert len(k) >= 3

    def test_language_detection_english(self):
        from nlp.pipeline import detect_language
        lang = detect_language(
            "The quick brown fox jumps over the lazy dog near the city of London"
        )
        assert lang == "en"

    def test_language_detection_russian(self):
        from nlp.pipeline import detect_language
        lang = detect_language(
            "Разведывательный анализ показал подозрительную сетевую активность"
        )
        assert lang != "en"

    def test_language_detection_returns_string(self):
        from nlp.pipeline import detect_language
        lang = detect_language("hello world")
        assert isinstance(lang, str)
        assert len(lang) >= 2


# ═══════════════════════════════════════════════════════════════════════════════
# 6 · PANEL SESSION STATE
# ═══════════════════════════════════════════════════════════════════════════════

class TestPanelSessionState:
    def _make_session(self, **kwargs):
        from panel.session import PanelSessionState
        defaults = dict(target="Acme Corp", topic="Full intelligence assessment",
                        report_content="Report content here")
        defaults.update(kwargs)
        return PanelSessionState(**defaults)

    def test_session_id_format(self):
        s = self._make_session()
        assert s.session_id.startswith("SESSION-")
        assert len(s.session_id) == 16

    def test_session_id_uppercase(self):
        s = self._make_session()
        uid = s.session_id[8:]
        assert uid == uid.upper()

    def test_initial_round_zero(self):
        s = self._make_session()
        assert s.round == 0

    def test_not_concluded_initially(self):
        from core.schemas import PanelStatus
        s = self._make_session()
        assert s.concluded is False
        assert s.status == PanelStatus.ACTIVE

    def test_empty_history(self):
        s = self._make_session()
        assert len(s.history) == 0
        assert len(s.positions) == 0
        assert len(s.covered_topics) == 0
        assert len(s.disagreements) == 0

    def test_add_turn_claude(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 1
        turn = s.add_turn(AnalystID.CLAUDE, "Alpha analysis of behavioral patterns in the data")
        assert len(s.history) == 1
        assert turn.analyst == AnalystID.CLAUDE
        assert turn.round_number == 1
        assert not turn.is_loop_flagged
        assert "behavioral" in turn.content

    def test_add_turn_flagged(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 2
        turn = s.add_turn(AnalystID.CHATGPT, "Repeated analysis", is_loop_flagged=True)
        assert turn.is_loop_flagged is True

    def test_add_multiple_turns(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 1
        s.add_turn(AnalystID.CLAUDE, "Alpha turn")
        s.add_turn(AnalystID.CHATGPT, "Bravo turn")
        s.add_turn(AnalystID.GEMINI, "Director turn")
        assert len(s.history) == 3

    def test_record_position(self):
        s = self._make_session()
        s.record_position("ANALYST-ALPHA", "The subject exhibits financial anomalies")
        assert "ANALYST-ALPHA" in s.positions
        assert len(s.positions["ANALYST-ALPHA"]) == 1

    def test_record_position_truncates_at_300(self):
        s = self._make_session()
        s.record_position("ANALYST-ALPHA", "X" * 600)
        assert len(s.positions["ANALYST-ALPHA"][0]) == 300

    def test_record_multiple_positions(self):
        s = self._make_session()
        for i in range(5):
            s.record_position("ANALYST-ALPHA", f"Point {i}: analysis of subject behavior")
        assert len(s.positions["ANALYST-ALPHA"]) == 5

    def test_record_positions_separate_analysts(self):
        s = self._make_session()
        s.record_position("ANALYST-ALPHA", "Alpha point about financial connections")
        s.record_position("ANALYST-BRAVO", "Bravo point about behavioral patterns")
        assert len(s.positions["ANALYST-ALPHA"]) == 1
        assert len(s.positions["ANALYST-BRAVO"]) == 1

    def test_add_disagreement(self):
        s = self._make_session()
        s.add_disagreement(
            round_number=3, topic="Threat level assessment",
            alpha_position="Subject is HIGH threat based on IOC correlation",
            bravo_position="Subject is MEDIUM — attribution confidence is low",
            director_note="Both positions preserved",
        )
        assert len(s.disagreements) == 1
        assert s.disagreements[0].round_number == 3
        assert s.disagreements[0].topic == "Threat level assessment"
        assert "HIGH" in s.disagreements[0].alpha_position
        assert "MEDIUM" in s.disagreements[0].bravo_position

    def test_add_multiple_disagreements(self):
        s = self._make_session()
        s.add_disagreement(2, "Topic A", "Alpha A", "Bravo A")
        s.add_disagreement(4, "Topic B", "Alpha B", "Bravo B")
        assert len(s.disagreements) == 2

    def test_mark_covered_records_round(self):
        s = self._make_session()
        s.round = 3
        s.mark_covered("behavioral indicators")
        assert "behavioral indicators" in s.covered_topics
        assert s.covered_topics["behavioral indicators"] == 3

    def test_mark_multiple_covered(self):
        s = self._make_session()
        s.round = 2
        for topic in ["behavioral indicators", "financial connections", "network analysis"]:
            s.mark_covered(topic)
        assert len(s.covered_topics) == 3

    def test_get_recent_context_limits(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 1
        for i in range(10):
            s.add_turn(AnalystID.CLAUDE, f"Analysis turn number {i} about intelligence")
        ctx = s.get_recent_context(n_turns=3)
        assert "turn number 9" in ctx
        assert "turn number 7" in ctx
        assert "turn number 0" not in ctx

    def test_get_recent_context_all_if_few(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 1
        s.add_turn(AnalystID.CLAUDE, "Only turn here")
        ctx = s.get_recent_context(n_turns=10)
        assert "Only turn here" in ctx

    def test_duration_str_format(self):
        s = self._make_session()
        dur = s.duration_str
        assert "m" in dur
        assert "s" in dur

    def test_to_db_dict_all_keys(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 2
        s.concluded = True
        s.add_turn(AnalystID.CLAUDE, "Alpha analysis")
        s.add_turn(AnalystID.CHATGPT, "Bravo analysis")
        s.final_synthesis = "Final assessment text"
        d = s.to_db_dict()
        for key in ["session_id", "topic", "target", "transcript", "positions",
                    "covered_topics", "disagreements", "rounds_completed",
                    "final_synthesis", "concluded", "start_time", "end_time"]:
            assert key in d, f"Missing key: {key}"
        assert d["rounds_completed"] == 2
        assert d["concluded"] is True
        assert len(d["transcript"]) == 2
        assert d["final_synthesis"] == "Final assessment text"

    def test_turn_has_unique_id(self):
        from core.schemas import AnalystID
        s = self._make_session()
        s.round = 1
        t1 = s.add_turn(AnalystID.CLAUDE, "Turn one content")
        t2 = s.add_turn(AnalystID.CHATGPT, "Turn two content")
        assert t1.turn_id != t2.turn_id


# ═══════════════════════════════════════════════════════════════════════════════
# 7 · LOOP DETECTOR
# ═══════════════════════════════════════════════════════════════════════════════

class TestLoopDetector:
    def _make_detector(self, threshold=0.65):
        from panel.loop_detector import LoopDetector
        return LoopDetector(threshold=threshold)

    def test_empty_prior_never_loop(self):
        d = self._make_detector()
        is_loop, matched, sim = d.is_loop("ALPHA", "any content at all", [])
        assert is_loop is False
        assert matched is None
        assert sim == 0.0

    def test_identical_keyword_loop(self):
        d = self._make_detector(threshold=0.65)
        content = ("The subject exhibits significant financial connections "
                   "to offshore entities suggesting money laundering activity")
        is_loop, matched, sim = d._keyword_fallback(content, [content])
        assert is_loop is True

    def test_novel_content_no_loop(self):
        d = self._make_detector(threshold=0.65)
        prior = "Subject has financial connections to offshore accounts in Cayman Islands"
        novel = "Behavioral analysis reveals deceptive linguistic patterns in all press releases"
        is_loop, matched, sim = d._keyword_fallback(novel, [prior])
        assert is_loop is False

    def test_high_threshold_allows_similarity(self):
        d = self._make_detector(threshold=0.99)  # Basically impossible to trigger
        content = "The subject has significant financial offshore connections"
        similar = "Subject has major financial offshore connections and accounts"
        is_loop, _, _ = d._keyword_fallback(similar, [content])
        assert is_loop is False  # 0.99 threshold, won't trigger on similar

    def test_low_threshold_triggers_easily(self):
        d = self._make_detector(threshold=0.1)  # Triggers on minimal overlap
        prior = "analysis subject intelligence"
        new_content = "analysis subject threat network connections"
        is_loop, _, sim = d._keyword_fallback(new_content, [prior])
        assert is_loop is True

    def test_multiple_priors_checked(self):
        d = self._make_detector(threshold=0.65)
        priors = [
            "The financial connections are suspicious entities offshore",
            "Behavioral analysis shows deceptive patterns communication media",
            "Network infrastructure reveals malicious actor activity targeting",
        ]
        # Content matching the last prior
        new_content = "Network infrastructure reveals malicious actor targeting systems"
        is_loop, matched, sim = d._keyword_fallback(new_content, priors)
        assert is_loop is True
        assert matched == priors[2]

    def test_find_least_covered_returns_string(self):
        d = self._make_detector()
        result = d.find_least_covered_section("report content", {})
        assert isinstance(result, str)
        assert len(result) > 5

    def test_find_least_covered_avoids_covered(self):
        d = self._make_detector()
        covered = {"behavioral indicators": 1, "network analysis": 2}
        result = d.find_least_covered_section("content", covered)
        # Should suggest something not in the covered set
        assert "behavioral indicators" not in result or "network analysis" not in result

    def test_find_least_covered_all_sections(self):
        d = self._make_detector()
        all_covered = {
            "behavioral indicators": 1, "network analysis": 2,
            "threat assessment": 3, "timeline events": 4,
            "entity relationships": 5, "source reliability": 6,
            "gaps and uncertainties": 7,
        }
        result = d.find_least_covered_section("content", all_covered)
        assert isinstance(result, str)
        assert len(result) > 5  # Returns fallback

    def test_embedding_cache_stores(self):
        d = self._make_detector()
        import hashlib
        text = "test content for caching"
        key = hashlib.md5(text[:500].encode()).hexdigest()
        # Pre-populate cache manually
        d._embedding_cache[key] = [0.1] * 100
        result = d._get_cached_embedding(text)
        assert result == [0.1] * 100


# ═══════════════════════════════════════════════════════════════════════════════
# 8 · PANEL PROMPTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestPanelPrompts:
    def test_claude_system_prompt_length(self):
        from panel.prompts import CLAUDE_SYSTEM
        assert len(CLAUDE_SYSTEM) > 500

    def test_chatgpt_system_prompt_length(self):
        from panel.prompts import CHATGPT_SYSTEM
        assert len(CHATGPT_SYSTEM) > 500

    def test_gemini_system_prompt_length(self):
        from panel.prompts import GEMINI_SYSTEM
        assert len(GEMINI_SYSTEM) > 500

    def test_synthesis_template_length(self):
        from panel.prompts import SYNTHESIS_PROMPT_TEMPLATE
        assert len(SYNTHESIS_PROMPT_TEMPLATE) > 300

    def test_analyst_identifiers_in_prompts(self):
        from panel.prompts import CLAUDE_SYSTEM, CHATGPT_SYSTEM, GEMINI_SYSTEM
        assert "ANALYST-ALPHA" in CLAUDE_SYSTEM
        assert "ANALYST-BRAVO" in CHATGPT_SYSTEM
        assert "SESSION DIRECTOR" in GEMINI_SYSTEM

    def test_gemini_anti_loop_directives(self):
        from panel.prompts import GEMINI_SYSTEM
        gemini_upper = GEMINI_SYSTEM.upper()
        assert "LOOP" in gemini_upper
        assert "CONCLUDING" in gemini_upper
        assert "QUESTION" in gemini_upper

    def test_gemini_output_format_enforced(self):
        from panel.prompts import GEMINI_SYSTEM
        assert "[DIRECTOR]" in GEMINI_SYSTEM
        assert "[QUESTION]" in GEMINI_SYSTEM
        assert "[STATUS]" in GEMINI_SYSTEM
        assert "[ROUND]" in GEMINI_SYSTEM

    def test_synthesis_template_format_vars(self):
        from panel.prompts import SYNTHESIS_PROMPT_TEMPLATE
        for var in ["{session_id}", "{report_id}", "{target}", "{rounds}",
                    "{duration}", "{transcript}", "{disagreements}", "{covered_topics}"]:
            assert var in SYNTHESIS_PROMPT_TEMPLATE, f"Missing: {var}"

    def test_synthesis_template_renderable(self):
        from panel.prompts import SYNTHESIS_PROMPT_TEMPLATE
        rendered = SYNTHESIS_PROMPT_TEMPLATE.format(
            session_id="SESSION-ABCD1234",
            report_id="REPORT-20250412-TEST-AB123456",
            target="Test Corporation",
            rounds=6, duration="12m 30s",
            transcript="[Full transcript here]",
            disagreements="None recorded",
            covered_topics="behavioral indicators, financial connections",
        )
        assert "SESSION-ABCD1234" in rendered
        assert "Test Corporation" in rendered

    def test_claude_prompt_response_structure(self):
        from panel.prompts import CLAUDE_SYSTEM
        # Must enforce structured output format
        assert "[FINDING]" in CLAUDE_SYSTEM
        assert "[EVIDENCE]" in CLAUDE_SYSTEM
        assert "[CONFIDENCE]" in CLAUDE_SYSTEM
        assert "[IMPLICATION]" in CLAUDE_SYSTEM

    def test_chatgpt_prompt_response_structure(self):
        from panel.prompts import CHATGPT_SYSTEM
        assert "[OBSERVATION]" in CHATGPT_SYSTEM
        assert "[PATTERN]" in CHATGPT_SYSTEM
        assert "[INTERPRETATION]" in CHATGPT_SYSTEM
        assert "[CONFIDENCE]" in CHATGPT_SYSTEM

    def test_prompts_mention_no_loop_rule(self):
        from panel.prompts import CLAUDE_SYSTEM, CHATGPT_SYSTEM
        assert "NEVER" in CLAUDE_SYSTEM or "never" in CLAUDE_SYSTEM
        assert "NEVER" in CHATGPT_SYSTEM or "never" in CHATGPT_SYSTEM


# ═══════════════════════════════════════════════════════════════════════════════
# 9 · GEMINI DIRECTOR OUTPUT PARSING
# ═══════════════════════════════════════════════════════════════════════════════

class TestDirectorParsing:
    def test_extract_question_standard(self):
        from panel.claude_analyst import GeminiDirector
        output = ("[DIRECTOR]: Good round.\n"
                  "[QUESTION]: What behavioral anomalies suggest deceptive intent in the timeline?\n"
                  "[STATUS]: ACTIVE\n[ROUND]: 2 of 6\n[COVERED]: financial")
        q = GeminiDirector.extract_question(output)
        assert "behavioral anomalies" in q
        assert "deceptive intent" in q

    def test_extract_question_no_tag_fallback(self):
        from panel.claude_analyst import GeminiDirector
        q = GeminiDirector.extract_question("No question tag present here")
        assert isinstance(q, str)
        assert len(q) > 10

    def test_extract_question_strips_tag(self):
        from panel.claude_analyst import GeminiDirector
        output = "[QUESTION]: Is the subject involved in sanctions evasion?"
        q = GeminiDirector.extract_question(output)
        assert "[QUESTION]" not in q
        assert "sanctions evasion" in q

    def test_extract_status_active(self):
        from panel.claude_analyst import GeminiDirector
        assert GeminiDirector.extract_status("[STATUS]: ACTIVE") == "ACTIVE"

    def test_extract_status_concluding(self):
        from panel.claude_analyst import GeminiDirector
        assert GeminiDirector.extract_status("[STATUS]: CONCLUDING") == "CONCLUDING"

    def test_extract_status_redirecting(self):
        from panel.claude_analyst import GeminiDirector
        assert GeminiDirector.extract_status("[STATUS]: REDIRECTING") == "REDIRECTING"

    def test_extract_status_loop_break(self):
        from panel.claude_analyst import GeminiDirector
        assert GeminiDirector.extract_status("[STATUS]: LOOP-BREAK") == "LOOP-BREAK"

    def test_extract_status_uppercase(self):
        from panel.claude_analyst import GeminiDirector
        status = GeminiDirector.extract_status("[STATUS]: Active")
        assert status == "ACTIVE"

    def test_extract_status_missing_fallback(self):
        from panel.claude_analyst import GeminiDirector
        status = GeminiDirector.extract_status("No status tag here")
        assert status == "ACTIVE"  # Default fallback

    def test_extract_covered_topics_three(self):
        from panel.claude_analyst import GeminiDirector
        output = "[COVERED]: financial connections, behavioral indicators, entity map"
        topics = GeminiDirector.extract_covered_topics(output)
        assert len(topics) == 3
        assert "financial connections" in topics
        assert "behavioral indicators" in topics
        assert "entity map" in topics

    def test_extract_covered_none(self):
        from panel.claude_analyst import GeminiDirector
        topics = GeminiDirector.extract_covered_topics("[COVERED]: None")
        assert topics == []

    def test_extract_covered_empty(self):
        from panel.claude_analyst import GeminiDirector
        topics = GeminiDirector.extract_covered_topics("No covered tag here")
        assert topics == []

    def test_extract_covered_strips_whitespace(self):
        from panel.claude_analyst import GeminiDirector
        output = "[COVERED]:  financial connections ,  behavioral indicators "
        topics = GeminiDirector.extract_covered_topics(output)
        assert "financial connections" in topics
        assert "behavioral indicators" in topics


# ═══════════════════════════════════════════════════════════════════════════════
# 10 · REPORT GENERATOR LOGIC (no AI calls)
# ═══════════════════════════════════════════════════════════════════════════════

class TestReportGeneratorLogic:
    def _bot(self):
        from reports.generator import ReportGeneratorBot
        return ReportGeneratorBot.__new__(ReportGeneratorBot)

    def test_entity_map_deduplicates(self):
        bot = self._bot()
        item1 = make_enriched_item(
            named_entities={"ORG": ["Acme Corp"], "PER": [], "LOC": [], "MISC": []})
        item2 = make_enriched_item(
            content="Different content about the same org. " * 5,
            source_url="https://other.com",
            named_entities={"ORG": ["Acme Corp", "Beta Inc"], "PER": [], "LOC": [], "MISC": []})
        em = bot._build_entity_map([item1, item2])
        assert em["organizations"].count("Acme Corp") == 1
        assert "Beta Inc" in em["organizations"]

    def test_entity_map_caps_at_30(self):
        bot = self._bot()
        items = [
            make_enriched_item(
                content=f"Content {i} " * 10,
                source_url=f"https://src{i}.com",
                named_entities={"ORG": [f"Org{i}"], "PER": [], "LOC": [], "MISC": []})
            for i in range(40)
        ]
        em = bot._build_entity_map(items)
        assert len(em["organizations"]) <= 30

    def test_confidence_low_on_empty(self):
        from core.schemas import ConfidenceLevel
        bot = self._bot()
        score, level = bot._score_confidence([])
        assert score == 0.1
        assert level == ConfidenceLevel.LOW

    def test_confidence_increases_with_items(self):
        bot = self._bot()
        few_items = [make_enriched_item(reliability_score=0.7)]
        many_items = [make_enriched_item(
            content=f"Content {i} " * 10,
            source_url=f"https://src{i}.com",
            reliability_score=0.9) for i in range(25)]
        score_few, _ = bot._score_confidence(few_items)
        score_many, _ = bot._score_confidence(many_items)
        assert score_many > score_few

    def test_confidence_high_requires_high_reliability(self):
        from core.schemas import ConfidenceLevel
        bot = self._bot()
        items = [make_enriched_item(
            content=f"Content {i} " * 10,
            source_url=f"https://src{i}.com",
            source_type=f"source_{i}",
            reliability_score=0.95) for i in range(20)]
        score, level = bot._score_confidence(items)
        assert level == ConfidenceLevel.HIGH

    def test_threat_critical_on_sanctions(self):
        bot = self._bot()
        item = make_enriched_item(source_type="opensanctions")
        ta = bot._build_threat_assessment([item])
        assert ta["level"] == "CRITICAL"
        assert ta["sanctions_hits"] >= 1
        assert "IMMEDIATE" in ta["summary"]

    def test_threat_high_on_multiple_feeds(self):
        bot = self._bot()
        items = [
            make_enriched_item(source_type="otx_alienvault",
                               content=f"Threat {i} " * 10,
                               source_url=f"https://otx{i}.com")
            for i in range(3)
        ]
        ta = bot._build_threat_assessment(items)
        assert ta["level"] == "HIGH"

    def test_threat_low_on_clean_news(self):
        bot = self._bot()
        items = [make_enriched_item(source_type="news_rss")]
        ta = bot._build_threat_assessment(items)
        assert ta["level"] == "LOW"
        assert ta["sanctions_hits"] == 0
        assert ta["ioc_count"] == 0

    def test_gaps_org_missing_edgar(self):
        bot = self._bot()
        item = make_enriched_item(source_type="news_rss")
        gaps = bot._identify_gaps([item], "organization")
        gap_text = " ".join(gaps).upper()
        assert "EDGAR" in gap_text or "SEC" in gap_text or "FILING" in gap_text

    def test_gaps_org_missing_sanctions(self):
        bot = self._bot()
        item = make_enriched_item(source_type="news_rss")
        gaps = bot._identify_gaps([item], "organization")
        gap_text = " ".join(gaps).lower()
        assert "sanction" in gap_text

    def test_gaps_low_item_count(self):
        bot = self._bot()
        item = make_enriched_item(source_type="sec_edgar")
        gaps = bot._identify_gaps([item], "organization")
        gap_text = " ".join(gaps).lower()
        assert "low" in gap_text or "incomplete" in gap_text

    def test_analyst_notes_high_person_count(self):
        bot = self._bot()
        item = make_enriched_item()
        entity_map = {"people": [f"Person {i}" for i in range(15)],
                      "organizations": [], "locations": []}
        notes = bot._generate_analyst_notes([item], entity_map, "Test Corp")
        assert any("15" in n or "individuals" in n or "persons" in n.lower()
                   for n in notes)

    def test_analyst_notes_high_reliability_sources(self):
        bot = self._bot()
        items = [make_enriched_item(
            reliability_score=0.95,
            content=f"High reliability item {i} " * 5,
            source_url=f"https://src{i}.com") for i in range(5)]
        entity_map = {"people": [], "organizations": [], "locations": []}
        notes = bot._generate_analyst_notes(items, entity_map, "Corp")
        assert any("authoritative" in n.lower() or "high" in n.lower()
                   or "reliability" in n.lower() for n in notes)

    def test_auto_tag_includes_type(self):
        bot = self._bot()
        tags = bot._auto_tag({"people": [], "organizations": [], "locations": []},
                             "organization")
        assert "organization" in tags

    def test_source_log_built_correctly(self):
        bot = self._bot()
        item = make_enriched_item(
            source_url="https://reuters.com/article",
            source_type="news_rss",
            collector_id="SPIDER-1",
        )
        log = bot._build_source_log([item])
        assert len(log) == 1
        assert log[0].collector == "SPIDER-1"
        assert log[0].source_type == "news_rss"
        assert log[0].url == "https://reuters.com/article"
        assert len(log[0].content_hash) == 64

    def test_context_digest_contains_target(self):
        bot = self._bot()
        items = [make_enriched_item()]
        entity_map = {"people": ["John Smith"], "organizations": ["Acme Corp"], "locations": []}
        digest = bot._build_context_digest(items, entity_map, "Acme Corporation")
        assert "Acme Corporation" in digest
        assert "John Smith" in digest


# ═══════════════════════════════════════════════════════════════════════════════
# 11 · INTEGRATION — PIPELINE FLOW (data only, no AI/DB)
# ═══════════════════════════════════════════════════════════════════════════════

class TestIntegrationFlow:
    def test_aggregator_to_entity_map_pipeline(self):
        """Full flow: raw items → aggregator → generator entity map."""
        from collectors.aggregator import AggregatorBot
        from reports.generator import ReportGeneratorBot

        items = [
            make_raw_item(
                content=f"Intelligence item {i} about Acme Corporation in London. " * 4,
                source_url=f"https://source{i}.com",
                source_type=["news_rss", "reddit_post", "opencorporates", "sec_edgar"][i % 4],
            )
            for i in range(8)
        ]
        result = make_collection_result(items=items)
        merged = AggregatorBot().process([result])
        assert len(merged) == 8

        enriched = [make_enriched_item(
            content=item.content,
            source_url=item.source_url,
            source_type=item.source_type,
            collector_id=item.collector_id,
        ) for item in merged]

        bot = ReportGeneratorBot.__new__(ReportGeneratorBot)
        em = bot._build_entity_map(enriched)
        assert isinstance(em, dict)
        assert all(isinstance(v, list) for v in em.values())

    def test_full_report_data_pipeline(self):
        """Build a ReportData from enriched items and verify markdown."""
        from reports.schema import ReportData, generate_report_id
        from reports.generator import ReportGeneratorBot
        from core.schemas import ConfidenceLevel, SourceLogEntry

        items = [make_enriched_item(
            content=f"Intelligence {i}: Acme Corp expansion into Eastern Europe. " * 4,
            source_url=f"https://src{i}.com",
            source_type="news_rss",
        ) for i in range(5)]

        bot = ReportGeneratorBot.__new__(ReportGeneratorBot)
        em = bot._build_entity_map(items)
        timeline = bot._build_timeline(items, "Acme Corp")
        source_log = bot._build_source_log(items)
        bi = bot._extract_behavioral_indicators(items, "Acme Corp")
        score, level = bot._score_confidence(items)
        ta = bot._build_threat_assessment(items)
        gaps = bot._identify_gaps(items, "organization")
        notes = bot._generate_analyst_notes(items, em, "Acme Corp")

        report = ReportData(
            report_id=generate_report_id("Acme Corp"),
            subject="Acme Corp",
            subject_type="organization",
            executive_summary="Acme Corp is expanding into Eastern European markets.",
            entity_map=em,
            timeline=timeline,
            source_log=source_log,
            behavioral_indicators=bi,
            confidence=level.value,
            confidence_score=score,
            threat_assessment=ta,
            gaps=gaps,
            analyst_notes=notes,
        )

        md = report.to_markdown()
        d = report.to_dict()

        assert report.report_id.startswith("REPORT-")
        assert len(md) > 1000
        assert "Acme Corp" in md
        assert "EXECUTIVE SUMMARY" in md
        assert "full_markdown" in d
        assert len(d["full_markdown"]) > 500

    def test_session_full_lifecycle(self):
        """Simulate a full 3-round panel session state lifecycle."""
        from panel.session import PanelSessionState
        from panel.loop_detector import LoopDetector
        from core.schemas import AnalystID, PanelStatus

        session = PanelSessionState(
            target="Acme Corp",
            topic="Full intelligence assessment of Acme Corp",
            report_content="Report with financial and behavioral intelligence.",
            max_rounds=3,
        )

        detector = LoopDetector(threshold=0.65)

        # Round 1
        session.round = 1
        alpha_r1 = "Acme Corp has significant offshore financial connections suggesting tax evasion."
        bravo_r1 = "Public statements from CEO contradict financial filings — deception indicators present."

        # Check not loops (first round, no priors)
        is_loop, _, _ = detector.is_loop("ALPHA", alpha_r1, session.positions.get("ALPHA", []))
        assert is_loop is False
        session.add_turn(AnalystID.CLAUDE, alpha_r1)
        session.record_position("ALPHA", alpha_r1)

        is_loop, _, _ = detector.is_loop("BRAVO", bravo_r1, session.positions.get("BRAVO", []))
        assert is_loop is False
        session.add_turn(AnalystID.CHATGPT, bravo_r1)
        session.record_position("BRAVO", bravo_r1)

        session.add_turn(AnalystID.GEMINI,
                         "[DIRECTOR]: Good.\n[QUESTION]: What network links exist?\n"
                         "[STATUS]: ACTIVE\n[ROUND]: 1 of 3\n[COVERED]: financial connections")
        session.mark_covered("financial connections")

        # Round 2
        session.round = 2
        alpha_r2 = "Network analysis reveals Acme Corp linked to three shell companies in British Virgin Islands."
        bravo_r2_loop = bravo_r1  # Deliberately repeat bravo_r1 (same analyst prior)

        is_loop, _, _ = detector.is_loop("ALPHA", alpha_r2, session.positions.get("ALPHA", []))
        assert is_loop is False
        session.add_turn(AnalystID.CLAUDE, alpha_r2)
        session.record_position("ALPHA", alpha_r2)

        # Bravo tries to loop — detect it
        is_loop, _, _ = detector.is_loop("BRAVO", bravo_r2_loop, session.positions.get("BRAVO", []))
        assert is_loop is True  # Loop detected — redirect needed
        bravo_r2_corrected = "Timeline analysis shows accelerating activity in Q4 2024 correlating with regulatory changes."
        session.add_turn(AnalystID.CHATGPT, bravo_r2_corrected, is_loop_flagged=True)
        session.record_position("BRAVO", bravo_r2_corrected)

        # Record disagreement
        session.add_disagreement(2, "Network attribution",
                                  "Three shell companies definitively linked",
                                  "Attribution requires stronger evidence — possible but unconfirmed")

        # Round 3 — conclude
        session.round = 3
        session.concluded = True
        session.status = PanelStatus.CONCLUDING
        session.final_synthesis = "## FINAL ASSESSMENT\n\nAcme Corp exhibits significant financial risk indicators."
        session.end_time = datetime.utcnow()

        # Verify full state
        assert len(session.history) == 5  # round1: alpha+bravo+gemini, round2: alpha+bravo(looped)
        assert len(session.disagreements) == 1
        assert "financial connections" in session.covered_topics
        assert session.covered_topics["financial connections"] == 1
        assert any(t.is_loop_flagged for t in session.history)
        assert session.concluded is True
        assert "FINAL ASSESSMENT" in session.final_synthesis

        # Verify db_dict is complete
        d = session.to_db_dict()
        assert d["rounds_completed"] == 3
        assert d["concluded"] is True
        assert len(d["transcript"]) == 5  # alpha1, bravo1, gemini1, alpha2, bravo2(looped)
        assert len(d["disagreements"]) == 1
