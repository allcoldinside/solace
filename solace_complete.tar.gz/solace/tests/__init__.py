"""SOLACE test suite."""
