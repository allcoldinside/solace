-- ═══════════════════════════════════════════════════════════════
-- SOLACE — PostgreSQL Initialization
-- Runs on first container start via docker-entrypoint-initdb.d
-- ═══════════════════════════════════════════════════════════════

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- Create n8n database
CREATE DATABASE n8n;
GRANT ALL PRIVILEGES ON DATABASE n8n TO solace;

-- Create authentik database
CREATE DATABASE authentik;
GRANT ALL PRIVILEGES ON DATABASE authentik TO solace;

-- Confirm
SELECT 'SOLACE PostgreSQL initialized' AS status;
