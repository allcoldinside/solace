#!/usr/bin/env python3
"""
SOLACE — CLI Panel Runner
Manually trigger a 3-AI panel session from the command line.

Usage:
  python scripts/run_panel.py --target "Acme Corp" --type organization
  python scripts/run_panel.py --report-id REPORT-20250411-ACME-CORP-A3F9B2C1
  python scripts/run_panel.py --topic "Threat assessment" --target "APT-29" --rounds 4
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from config.logging import configure_logging
from config.settings import settings

configure_logging("INFO")


async def main(args: argparse.Namespace) -> None:
    from panel.engine import panel_engine

    print("\n" + "═" * 60)
    print("  SOLACE PANEL ENGINE — CLI MODE")
    print("═" * 60)

    report_content = ""

    if args.report_id:
        print(f"  Loading report: {args.report_id}")
        try:
            from core.database import get_db_session
            from core.models import Report
            from sqlalchemy import select
            async with get_db_session() as db:
                result = await db.execute(
                    select(Report).where(
                        (Report.report_id == args.report_id) | (Report.id == args.report_id)
                    )
                )
                report = result.scalar_one_or_none()
                if report:
                    report_content = report.full_markdown
                    if not args.target:
                        args.target = report.subject
                    if not args.topic:
                        args.topic = f"Full intelligence assessment of {report.subject}"
                    print(f"  Subject: {report.subject}")
                else:
                    print(f"  WARNING: Report {args.report_id} not found in database")
        except Exception as exc:
            print(f"  WARNING: Could not load report from DB: {exc}")

    if not args.target:
        print("  ERROR: --target is required when not using --report-id")
        sys.exit(1)

    topic = args.topic or f"Full intelligence assessment of {args.target}"
    report_content = report_content or f"Ad-hoc panel analysis of: {args.target}"

    print(f"  Target:  {args.target}")
    print(f"  Topic:   {topic}")
    print(f"  Rounds:  {args.rounds}")
    print("═" * 60 + "\n")

    print("Convening panel: ANALYST-ALPHA (Claude) · ANALYST-BRAVO (ChatGPT) · SESSION DIRECTOR (Gemini)\n")

    session = await panel_engine.run(
        report_content=report_content,
        topic=topic,
        target=args.target,
        report_id=args.report_id or "",
        max_rounds=args.rounds,
    )

    print("\n" + "═" * 60)
    print("  SESSION COMPLETE")
    print(f"  Session ID:  {session.session_id}")
    print(f"  Rounds:      {session.round}/{args.rounds}")
    print(f"  Duration:    {session.duration_str}")
    print(f"  Disagreements: {len(session.disagreements)}")
    print("═" * 60)

    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            f.write(f"# SOLACE Panel Session: {session.session_id}\n\n")
            f.write(f"**Target:** {session.target}\n")
            f.write(f"**Topic:** {session.topic}\n")
            f.write(f"**Rounds:** {session.round}\n")
            f.write(f"**Duration:** {session.duration_str}\n\n")
            f.write("---\n\n")
            f.write("## FULL TRANSCRIPT\n\n")
            f.write(session.get_formatted_transcript())
            f.write("\n\n---\n\n")
            f.write("## FINAL ASSESSMENT\n\n")
            f.write(session.final_synthesis)
        print(f"\n  Output saved: {output_path}")
    else:
        print("\n" + "─" * 60)
        print("FINAL INTELLIGENCE ASSESSMENT")
        print("─" * 60)
        print(session.final_synthesis)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SOLACE Panel Engine CLI")
    parser.add_argument("--report-id", "--report_id", help="SOLACE Report ID to analyze")
    parser.add_argument("--target", help="Intelligence target subject")
    parser.add_argument("--type", dest="target_type", default="organization",
                        choices=["organization", "person", "infrastructure", "event", "threat_actor"])
    parser.add_argument("--topic", help="Analytical topic / session objective")
    parser.add_argument("--rounds", type=int, default=6, help="Maximum panel rounds (default: 6)")
    parser.add_argument("--output", "-o", help="Save session transcript to markdown file")
    args = parser.parse_args()
    asyncio.run(main(args))
