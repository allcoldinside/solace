#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════
# SOLACE — Bootstrap Script
# First-run setup: validates environment, builds services, initialises DBs
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'

print_banner() {
  echo -e "${GREEN}${BOLD}"
  echo "  ███████╗ ██████╗ ██╗      █████╗  ██████╗███████╗"
  echo "  ██╔════╝██╔═══██╗██║     ██╔══██╗██╔════╝██╔════╝"
  echo "  ███████╗██║   ██║██║     ███████║██║     █████╗  "
  echo "  ╚════██║██║   ██║██║     ██╔══██║██║     ██╔══╝  "
  echo "  ███████║╚██████╔╝███████╗██║  ██║╚██████╗███████╗"
  echo "  ╚══════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚══════╝"
  echo ""
  echo "  Solo OSINT & Layered Analysis with Collaborative Experts"
  echo "  v1.0.0 // Bootstrap"
  echo -e "${NC}"
}

check_dependency() {
  if ! command -v "$1" &> /dev/null; then
    echo -e "${RED}✗ $1 not found. Please install it first.${NC}"
    exit 1
  fi
  echo -e "${GREEN}✓ $1${NC}"
}

prompt_required() {
  local var_name="$1"
  local prompt="$2"
  local current="${!var_name:-}"
  if [[ -z "$current" ]]; then
    read -rp "  ${prompt}: " value
    echo "$value"
  else
    echo "$current"
  fi
}

print_banner

echo -e "${BOLD}── Checking Dependencies ───────────────────────────────────${NC}"
check_dependency docker
check_dependency "docker compose" || check_dependency docker-compose
check_dependency python3
check_dependency curl
echo ""

echo -e "${BOLD}── Environment Setup ───────────────────────────────────────${NC}"

if [[ ! -f .env ]]; then
  echo -e "${AMBER}No .env file found. Creating from template...${NC}"
  cp .env.example .env

  echo ""
  echo -e "${BOLD}Please provide the following required values:${NC}"
  echo ""

  # Generate a random secret key
  SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
  sed -i "s/changeme_super_secret_key_min_32_chars/$SECRET_KEY/" .env

  echo -e "${BLUE}API Keys (press Enter to skip and configure later):${NC}"

  read -rp "  Anthropic API Key (required for panel): " ANTHROPIC_KEY
  if [[ -n "$ANTHROPIC_KEY" ]]; then
    sed -i "s/sk-ant-.../$ANTHROPIC_KEY/" .env
  fi

  read -rp "  OpenAI API Key (required for panel): " OPENAI_KEY
  if [[ -n "$OPENAI_KEY" ]]; then
    sed -i "s/sk-.../$OPENAI_KEY/" .env
  fi

  read -rp "  Google AI API Key (required for panel): " GOOGLE_KEY
  if [[ -n "$GOOGLE_KEY" ]]; then
    sed -i "s/AIza.../$GOOGLE_KEY/" .env
  fi

  read -rp "  Your domain (default: solace.local): " DOMAIN
  DOMAIN="${DOMAIN:-solace.local}"
  sed -i "s/SOLACE_DOMAIN=solace.local/SOLACE_DOMAIN=$DOMAIN/" .env

  echo -e "${GREEN}✓ .env configured${NC}"
else
  echo -e "${GREEN}✓ .env exists${NC}"
fi

echo ""
echo -e "${BOLD}── Creating Directories ────────────────────────────────────${NC}"
mkdir -p credentials
echo -e "${GREEN}✓ credentials/ directory ready${NC}"
echo ""

echo -e "${BOLD}── Pulling Docker Images ────────────────────────────────────${NC}"
docker compose pull --ignore-buildable 2>/dev/null || true
echo -e "${GREEN}✓ Images pulled${NC}"
echo ""

echo -e "${BOLD}── Building SOLACE Services ─────────────────────────────────${NC}"
docker compose build --parallel
echo -e "${GREEN}✓ Services built${NC}"
echo ""

echo -e "${BOLD}── Starting Core Infrastructure ─────────────────────────────${NC}"
docker compose up -d postgres redis mongodb neo4j minio
echo -e "${AMBER}Waiting for databases to be healthy...${NC}"

MAX_WAIT=120
ELAPSED=0
while ! docker compose ps postgres | grep -q "healthy"; do
  sleep 3
  ELAPSED=$((ELAPSED + 3))
  if [[ $ELAPSED -ge $MAX_WAIT ]]; then
    echo -e "${RED}✗ Databases did not start in time. Check logs: docker compose logs postgres${NC}"
    exit 1
  fi
  echo -n "."
done
echo ""
echo -e "${GREEN}✓ Databases healthy${NC}"
echo ""

echo -e "${BOLD}── Initialising Database Schema ─────────────────────────────${NC}"
docker compose run --rm solace-api python -c "
import asyncio
from core.database import init_db
from config.logging import configure_logging
configure_logging('INFO')
asyncio.run(init_db())
print('Database schema initialised')
" || echo -e "${AMBER}Warning: DB init may need retry after first start${NC}"
echo ""

echo -e "${BOLD}── Starting Full Platform ───────────────────────────────────${NC}"
docker compose up -d
echo ""

echo -e "${BOLD}── Waiting for Services ─────────────────────────────────────${NC}"
sleep 10
curl -sf http://localhost:8000/api/health > /dev/null && \
  echo -e "${GREEN}✓ SOLACE API operational${NC}" || \
  echo -e "${AMBER}⚠ API still starting up — check: docker compose logs solace-api${NC}"
echo ""

echo -e "${GREEN}${BOLD}"
echo "  ═══════════════════════════════════════════════════════════"
echo "  SOLACE PLATFORM ONLINE"
echo "  ═══════════════════════════════════════════════════════════"
echo -e "${NC}"
echo -e "  ${BOLD}Dashboard:${NC}   http://localhost:3000"
echo -e "  ${BOLD}API Docs:${NC}    http://localhost:8000/api/docs"
echo -e "  ${BOLD}Grafana:${NC}     http://localhost:3001"
echo -e "  ${BOLD}n8n:${NC}         http://localhost:5678"
echo -e "  ${BOLD}Neo4j:${NC}       http://localhost:7474"
echo -e "  ${BOLD}MinIO:${NC}       http://localhost:9001"
echo ""
echo -e "  ${AMBER}Next steps:${NC}"
echo -e "  1. Add Google Drive service account JSON to: credentials/google_service_account.json"
echo -e "  2. Configure Telegram/Discord tokens in .env"
echo -e "  3. Pull Ollama model: docker exec solace-ollama ollama pull mistral"
echo -e "  4. Open dashboard and run your first OSINT collection!"
echo ""
echo -e "  ${BOLD}Docs:${NC} See README.md for full configuration guide"
