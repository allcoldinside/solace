#!/usr/bin/env python3
"""
SOLACE — Development Seed Data Script
Populates the database with sample reports, entities, and panel sessions
for development and testing without running real collections.

Usage:
    python scripts/seed_data.py
    python scripts/seed_data.py --reports 10 --entities 50
"""
from __future__ import annotations

import argparse
import asyncio
import random
import uuid
from datetime import datetime, timedelta

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


SAMPLE_TARGETS = [
    ("Acme Corporation", "organization"),
    ("ByteForce Security Ltd", "organization"),
    ("APT-Phantom", "threat_actor"),
    ("John Smith", "person"),
    ("Chen Wei", "person"),
    ("198.51.100.42", "infrastructure"),
    ("phantom-c2.darkweb.onion", "infrastructure"),
    ("Operation NightFall", "event"),
]

SAMPLE_FINDINGS = [
    ("Subject has significant offshore financial connections via shell companies", "HIGH"),
    ("Public statements contradict financial filings — deception indicators present", "HIGH"),
    ("Network infrastructure linked to known threat actor C2 servers", "HIGH"),
    ("Subject appears in OpenSanctions database with moderate confidence score", "MEDIUM"),
    ("Social media footprint shows pattern of life inconsistencies", "MEDIUM"),
    ("DNS records reveal historically linked infrastructure clusters", "MEDIUM"),
    ("Corporate registry shows dormant subsidiary with unusual activity", "LOW"),
    ("Academic profile contains inconsistencies with stated credentials", "LOW"),
]

SAMPLE_TAGS = ["financial", "cyber", "corporate", "geopolitical", "sanctions",
               "network", "osint", "threat-actor", "person-of-interest", "infrastructure"]

SAMPLE_ANALYST_TURNS = [
    ("ANALYST-ALPHA", "The behavioral pattern of life analysis reveals several significant anomalies. "
     "Cross-referencing the timeline data with public statements shows a 3-week gap in digital "
     "activity coinciding with a major financial transaction. Confidence: HIGH based on 4 sources."),
    ("ANALYST-BRAVO", "Building on Alpha's observation — the linguistic patterns in press releases "
     "during the same period show increased hedging language, a known deception indicator. "
     "Source reliability across 6 documents averages 0.78. Confidence: MEDIUM."),
    ("SESSION-DIRECTOR", "[DIRECTOR]: Strong analytical convergence on behavioral indicators. "
     "The financial gap and linguistic pattern are linked. Redirect to infrastructure analysis.\n"
     "[QUESTION]: What network infrastructure changes occurred during this 3-week window?\n"
     "[STATUS]: ACTIVE\n[ROUND]: 2 of 6\n[COVERED]: behavioral indicators, financial gap"),
]


async def seed_reports(count: int) -> list[str]:
    """Create sample intelligence reports."""
    from core.database import get_db_session, init_db
    from core.models import Report
    from reports.schema import generate_report_id

    await init_db()

    report_ids = []

    async with get_db_session() as db:
        for i in range(count):
            target, target_type = random.choice(SAMPLE_TARGETS)
            report_id = generate_report_id(f"{target} {i}")
            days_ago = random.randint(0, 30)
            created = datetime.utcnow() - timedelta(days=days_ago)

            # Pick 2-4 random findings
            n_findings = random.randint(2, 4)
            chosen_findings = random.sample(SAMPLE_FINDINGS, n_findings)

            key_findings = []
            for j, (finding, confidence) in enumerate(chosen_findings, 1):
                key_findings.append({
                    "number": j,
                    "finding": finding,
                    "confidence": confidence,
                    "source_count": random.randint(1, 8),
                    "first_observed": (created - timedelta(days=random.randint(1, 10))).strftime("%Y-%m-%d"),
                    "evidence": ["Source A", "Source B"],
                })

            chosen_tags = random.sample(SAMPLE_TAGS, random.randint(2, 4))
            confidence_score = round(random.uniform(0.45, 0.92), 3)
            confidence = "HIGH" if confidence_score > 0.75 else "MEDIUM" if confidence_score > 0.5 else "LOW"

            report = Report(
                id=str(uuid.uuid4()),
                report_id=report_id,
                subject=target,
                subject_type=target_type,
                classification=random.choice(["TLP:WHITE", "TLP:GREEN", "TLP:AMBER"]),
                confidence=confidence,
                confidence_score=confidence_score,
                analyst_bots=random.sample(
                    ["SPIDER-1", "SPIDER-2", "SPIDER-3", "SPIDER-5", "SPIDER-8"],
                    random.randint(2, 4)
                ),
                tags=chosen_tags,
                executive_summary=(
                    f"Intelligence collected on {target} ({target_type}) indicates "
                    f"{'significant activity requiring immediate attention' if confidence == 'HIGH' else 'notable patterns worth monitoring'}. "
                    f"Collection covered {random.randint(15, 45)} unique sources across "
                    f"{random.randint(3, 6)} intelligence domains."
                ),
                key_findings=key_findings,
                entity_map={
                    "people": [f"Person {chr(65+i)}", f"Contact {chr(65+i)}"],
                    "organizations": [target, f"Associated Org {i}"],
                    "locations": ["London", "New York", "Singapore"],
                    "infrastructure": [f"192.168.{i}.1", f"domain-{i}.example.com"],
                },
                timeline=[
                    {
                        "timestamp": (created - timedelta(days=j)).strftime("%Y-%m-%d %H:%M UTC"),
                        "event": f"Event {j}: Intelligence item observed",
                        "source": "news_rss",
                        "confidence": "MEDIUM",
                    }
                    for j in range(3)
                ],
                behavioral_indicators=[
                    {
                        "indicator": "Unusual digital activity pattern",
                        "pattern_type": "presence_anomaly",
                        "significance": "Deviation from established baseline",
                        "confidence": "MEDIUM",
                        "evidence": ["Source A"],
                    }
                ],
                threat_assessment={
                    "level": "HIGH" if i % 4 == 0 else "MEDIUM" if i % 3 == 0 else "LOW",
                    "score": round(random.uniform(2.0, 9.5), 1),
                    "ioc_count": random.randint(0, 5),
                    "sanctions_hits": 1 if i % 7 == 0 else 0,
                    "summary": "Threat intelligence assessment based on collected sources.",
                },
                source_log=[
                    {
                        "url": f"https://source{j}.example.com",
                        "collector": f"SPIDER-{(j % 8) + 1}",
                        "source_type": random.choice(["news_rss", "opencorporates", "shodan", "otx_alienvault"]),
                        "collected_at": created.isoformat(),
                        "reliability_score": round(random.uniform(0.6, 0.97), 2),
                        "content_hash": uuid.uuid4().hex[:16],
                    }
                    for j in range(random.randint(3, 8))
                ],
                gaps=[
                    "Dark web coverage not available",
                    "Financial history pre-2020 incomplete",
                ],
                analyst_notes=[
                    f"Note: {random.randint(2, 8)} high-reliability sources confirm key findings",
                    "Note: Subject has multiple online aliases — verify identity consolidation",
                ],
                full_markdown=f"# SOLACE INTELLIGENCE REPORT\n\n**report_id:** {report_id}\n"
                              f"**subject:** {target}\n**subject_type:** {target_type}\n\n"
                              f"## EXECUTIVE SUMMARY\n\nSample seed report for development.\n",
                created_at=created,
                updated_at=created,
            )
            db.add(report)
            report_ids.append(report_id)

    print(f"  ✓ Created {count} sample reports")
    return report_ids


async def seed_entities(count: int) -> None:
    """Create sample entities in the registry."""
    from core.database import get_db_session
    from core.models import Entity

    ENTITY_TYPES = ["person", "organization", "infrastructure", "location"]

    async with get_db_session() as db:
        for i in range(count):
            entity_type = random.choice(ENTITY_TYPES)
            names = {
                "person": [f"Alice Johnson {i}", f"Bob Chen {i}", f"Maria García {i}"],
                "organization": [f"TechCorp {i} Ltd", f"Global Holdings {i}", f"Alpha Group {i}"],
                "infrastructure": [f"192.168.{i % 255}.{i % 100}", f"domain-{i}.net"],
                "location": ["London", "New York", "Moscow", "Beijing", "Dubai"],
            }
            name = random.choice(names[entity_type])
            entity = Entity(
                id=str(uuid.uuid4()),
                entity_type=entity_type,
                name=name,
                aliases=[f"aka {name.split()[0]}"],
                confidence=round(random.uniform(0.4, 0.95), 2),
                tags=random.sample(SAMPLE_TAGS, 2),
                metadata_={"seed": True},
                first_seen=datetime.utcnow() - timedelta(days=random.randint(1, 90)),
                last_seen=datetime.utcnow() - timedelta(days=random.randint(0, 10)),
            )
            db.add(entity)

    print(f"  ✓ Created {count} sample entities")


async def seed_panel_sessions(report_ids: list[str]) -> None:
    """Create sample panel sessions linked to reports."""
    from core.database import get_db_session
    from core.models import PanelSession
    from reports.schema import generate_session_id

    if not report_ids:
        return

    async with get_db_session() as db:
        for report_id in report_ids[:5]:  # Seed 5 panel sessions
            session_id = generate_session_id()
            started = datetime.utcnow() - timedelta(hours=random.randint(1, 72))

            # Build a realistic transcript
            transcript = []
            for round_num in range(1, random.randint(3, 6)):
                for turn in SAMPLE_ANALYST_TURNS:
                    analyst, content = turn
                    transcript.append({
                        "turn_id": uuid.uuid4().hex[:8],
                        "round_number": round_num,
                        "analyst": analyst,
                        "content": content,
                        "is_loop_flagged": False,
                        "timestamp": (started + timedelta(minutes=round_num * 8)).isoformat(),
                    })

            panel = PanelSession(
                id=str(uuid.uuid4()),
                session_id=session_id,
                topic=f"Full intelligence assessment of subject",
                target=random.choice(SAMPLE_TARGETS)[0],
                transcript=transcript,
                positions={
                    "ANALYST-ALPHA": ["Financial connections analysis", "Behavioral indicators"],
                    "ANALYST-BRAVO": ["Linguistic patterns identified", "Source reliability assessment"],
                },
                covered_topics=["behavioral indicators", "financial connections", "network infrastructure"],
                disagreements=[
                    {
                        "round_number": 2,
                        "topic": "Threat attribution confidence",
                        "alpha_position": "HIGH confidence based on IOC correlation",
                        "bravo_position": "MEDIUM confidence — attribution requires additional validation",
                        "director_note": "Both positions preserved",
                    }
                ],
                rounds_completed=len(set(t["round_number"] for t in transcript)),
                final_synthesis=(
                    "## FINAL INTELLIGENCE ASSESSMENT\n\n"
                    "### KEY FINDINGS\n"
                    "1. [HIGH] Subject exhibits significant financial anomalies\n"
                    "2. [HIGH] Linguistic patterns indicate deceptive communication\n"
                    "3. [MEDIUM] Network infrastructure shows historical threat actor linkage\n\n"
                    "### ANALYST AGREEMENTS\n"
                    "Both analysts confirmed the behavioral pattern anomalies.\n\n"
                    "### ANALYST DISAGREEMENTS\n"
                    "Attribution confidence: ALPHA (HIGH) vs BRAVO (MEDIUM)\n\n"
                    "### OVERALL ASSESSMENT\n"
                    "Subject warrants continued monitoring. Recommend follow-on collection."
                ),
                concluded=True,
                start_time=started,
                end_time=started + timedelta(minutes=random.randint(15, 45)),
            )
            db.add(panel)

    print(f"  ✓ Created {min(5, len(report_ids))} sample panel sessions")


async def main(reports: int, entities: int) -> None:
    """Run all seed operations."""
    print()
    print("═" * 50)
    print("  SOLACE — Seeding Development Data")
    print("═" * 50)
    print()

    print("Seeding reports...")
    report_ids = await seed_reports(reports)

    print("Seeding entities...")
    await seed_entities(entities)

    print("Seeding panel sessions...")
    await seed_panel_sessions(report_ids)

    print()
    print("═" * 50)
    print(f"  ✓ Seed complete")
    print(f"    Reports:  {reports}")
    print(f"    Entities: {entities}")
    print(f"    Sessions: {min(5, reports)}")
    print("═" * 50)
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed SOLACE with development data")
    parser.add_argument("--reports", type=int, default=10, help="Number of reports to create")
    parser.add_argument("--entities", type=int, default=30, help="Number of entities to create")
    args = parser.parse_args()
    asyncio.run(main(args.reports, args.entities))
