"""
SOLACE — Loop Detector
Detects when an analyst is repeating previously covered analytical ground.
Uses BAAI/bge-m3 cosine similarity — not brittle keyword matching.
"""
from __future__ import annotations

import numpy as np
from functools import lru_cache

from config import get_logger, settings

logger = get_logger("loop_detector")


@lru_cache(maxsize=1)
def _get_embedding_model():
    """Lazy-load and cache the sentence transformer model."""
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer("BAAI/bge-m3")


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    """Calculate cosine similarity between two vectors.

    Args:
        a: First embedding vector.
        b: Second embedding vector.

    Returns:
        Cosine similarity score between -1.0 and 1.0.
    """
    va = np.array(a)
    vb = np.array(b)
    norm_a = np.linalg.norm(va)
    norm_b = np.linalg.norm(vb)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(np.dot(va, vb) / (norm_a * norm_b))


def _embed(text: str) -> list[float]:
    """Generate an embedding for loop detection.

    Args:
        text: Text to embed (truncated to 500 chars for speed).

    Returns:
        Normalized embedding vector.
    """
    try:
        model = _get_embedding_model()
        embedding = model.encode(text[:500], normalize_embeddings=True)
        return embedding.tolist()
    except Exception as exc:
        logger.warning("embedding_failed_for_loop_detection", error=str(exc))
        return []


class LoopDetector:
    """Detects analytical loops in panel sessions using semantic similarity.

    Each analyst's prior points are embedded and compared against new content.
    Threshold is configurable (default 0.65 = 65% semantic similarity).
    """

    def __init__(self, threshold: float | None = None) -> None:
        self.threshold = threshold or settings.loop_detection_threshold
        # Cache embeddings to avoid re-computing: {text_hash: embedding}
        self._embedding_cache: dict[str, list[float]] = {}

    def is_loop(
        self,
        analyst_id: str,
        new_content: str,
        prior_positions: list[str],
    ) -> tuple[bool, str | None, float]:
        """Check whether new content semantically repeats prior positions.

        Args:
            analyst_id: The analyst's ID (for logging).
            new_content: The new content to check.
            prior_positions: List of prior point summaries from this analyst.

        Returns:
            Tuple of (is_loop: bool, matched_prior: str | None, max_similarity: float).
        """
        if not prior_positions:
            return False, None, 0.0

        new_embedding = self._get_cached_embedding(new_content)
        if not new_embedding:
            # Embedding failed — fall back to keyword overlap
            return self._keyword_fallback(new_content, prior_positions)

        max_sim = 0.0
        matched_prior = None

        for prior in prior_positions:
            prior_embedding = self._get_cached_embedding(prior)
            if not prior_embedding:
                continue
            sim = _cosine_similarity(new_embedding, prior_embedding)
            if sim > max_sim:
                max_sim = sim
                matched_prior = prior

        is_loop = max_sim >= self.threshold

        if is_loop:
            logger.info(
                "loop_detected",
                analyst=analyst_id,
                similarity=round(max_sim, 3),
                threshold=self.threshold,
                matched_prior_snippet=matched_prior[:80] if matched_prior else "",
            )

        return is_loop, matched_prior, max_sim

    def find_least_covered_section(
        self,
        report_content: str,
        covered_topics: dict[str, int],
    ) -> str:
        """Identify the section of the report least covered by prior analysis.

        Args:
            report_content: Full report markdown text.
            covered_topics: Dict of {topic_key: round_first_covered}.

        Returns:
            A redirect suggestion pointing at an under-analyzed report section.
        """
        sections = [
            ("behavioral indicators", "## BEHAVIORAL INDICATORS"),
            ("network analysis", "## NETWORK ANALYSIS"),
            ("threat assessment", "## THREAT ASSESSMENT"),
            ("timeline events", "## TIMELINE"),
            ("entity relationships", "## ENTITY MAP"),
            ("source reliability", "## SOURCE LOG"),
            ("gaps and uncertainties", "## GAPS"),
        ]

        covered_keys = set(covered_topics.keys())
        uncovered = [label for label, _ in sections if label not in covered_keys]

        if uncovered:
            return f"the report's {uncovered[0]} section"

        # Everything covered — point to deepest finding
        return "the most recent timeline entries and their cross-referencing with the entity map"

    def _get_cached_embedding(self, text: str) -> list[float]:
        """Get or compute a cached embedding for text."""
        import hashlib
        key = hashlib.md5(text[:500].encode()).hexdigest()
        if key not in self._embedding_cache:
            self._embedding_cache[key] = _embed(text)
        return self._embedding_cache[key]

    def _keyword_fallback(
        self,
        new_content: str,
        prior_positions: list[str],
    ) -> tuple[bool, str | None, float]:
        """Keyword overlap fallback when embedding fails.

        Args:
            new_content: New content to check.
            prior_positions: Prior positions to compare against.

        Returns:
            Loop detection result tuple.
        """
        STOPWORDS = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
            "of", "with", "by", "from", "is", "was", "are", "this", "that", "it",
            "be", "as", "also", "not", "have", "has", "had", "which", "who",
        }
        new_words = set(new_content.lower().split()) - STOPWORDS
        max_overlap = 0.0
        matched = None

        for prior in prior_positions:
            prior_words = set(prior.lower().split()) - STOPWORDS
            if not new_words:
                continue
            overlap = len(new_words & prior_words) / len(new_words)
            if overlap > max_overlap:
                max_overlap = overlap
                matched = prior

        return max_overlap >= self.threshold, matched, max_overlap
