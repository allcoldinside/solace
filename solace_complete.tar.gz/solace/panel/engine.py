"""
SOLACE — Panel Engine
Orchestrates the complete 3-AI analyst panel session.
This is the crown jewel of the SOLACE platform.
"""
from __future__ import annotations

import asyncio
from datetime import datetime
from typing import AsyncGenerator

from config import get_logger
from core.schemas import AnalystID, PanelStatus
from panel.claude_analyst import ClaudeAnalyst, ChatGPTAnalyst, GeminiDirector
from panel.loop_detector import LoopDetector
from panel.session import PanelSessionState

logger = get_logger("panel_engine")


class PanelEngine:
    """Orchestrates the 3-AI SOLACE intelligence analysis panel.

    Manages the full lifecycle of a panel session:
      1. Gemini opens session and sets agenda
      2. Per round: Claude analyzes → GPT responds → Gemini directs
      3. Loop detection on every analyst turn
      4. Disagreement tracking
      5. Gemini synthesizes final assessment

    The engine emits events via async generator for live streaming to the dashboard.
    """

    def __init__(self) -> None:
        self.claude = ClaudeAnalyst()
        self.chatgpt = ChatGPTAnalyst()
        self.gemini = GeminiDirector()
        self.loop_detector = LoopDetector()

    async def run(
        self,
        report_content: str,
        topic: str,
        target: str,
        report_id: str = "",
        max_rounds: int = 6,
    ) -> PanelSessionState:
        """Run a complete panel session synchronously (non-streaming).

        Args:
            report_content: Full report markdown for analysts to analyze.
            topic: The analytical topic / session objective.
            target: The intelligence target subject.
            report_id: Optional linked report ID.
            max_rounds: Maximum analysis rounds (default 6).

        Returns:
            Completed PanelSessionState with full transcript and synthesis.
        """
        session = PanelSessionState(
            report_id=report_id,
            topic=topic,
            target=target,
            report_content=report_content,
            max_rounds=max_rounds,
        )

        logger.info(
            "panel_session_started",
            session_id=session.session_id,
            target=target,
            max_rounds=max_rounds,
        )

        # ── Opening ───────────────────────────────────────────────────────────
        opening = await self.gemini.open_session(session)
        session.add_turn(AnalystID.GEMINI, opening)
        current_question = self.gemini.extract_question(opening)
        logger.info("session_opened", first_question=current_question[:80])

        # ── Panel Rounds ──────────────────────────────────────────────────────
        while session.round < session.max_rounds and not session.concluded:
            session.round += 1
            logger.info("round_started", round=session.round, session_id=session.session_id)

            # ── ANALYST-ALPHA (Claude) ────────────────────────────────────────
            alpha_response = await self._get_alpha_turn(session, current_question)

            # ── ANALYST-BRAVO (ChatGPT) ───────────────────────────────────────
            bravo_response = await self._get_bravo_turn(session, current_question, alpha_response)

            # ── Detect Disagreements ──────────────────────────────────────────
            self._detect_disagreement(session, alpha_response, bravo_response)

            # ── SESSION-DIRECTOR (Gemini) ─────────────────────────────────────
            direction = await self.gemini.direct(session, alpha_response, bravo_response)
            session.add_turn(AnalystID.GEMINI, direction)

            # Update covered topics from Gemini's output
            new_covered = self.gemini.extract_covered_topics(direction)
            for topic_key in new_covered:
                session.mark_covered(topic_key)

            # Extract next question and status
            current_question = self.gemini.extract_question(direction)
            status = self.gemini.extract_status(direction)

            logger.info(
                "round_complete",
                round=session.round,
                status=status,
                covered_count=len(session.covered_topics),
                disagreements=len(session.disagreements),
            )

            # Check for conclusion
            if "CONCLUDING" in status or session.round >= session.max_rounds:
                session.concluded = True
                session.status = PanelStatus.CONCLUDING
                break

        # ── Final Synthesis ───────────────────────────────────────────────────
        logger.info("generating_final_synthesis", session_id=session.session_id)
        session.final_synthesis = await self.gemini.synthesize(session)
        session.end_time = datetime.utcnow()

        logger.info(
            "panel_session_complete",
            session_id=session.session_id,
            rounds=session.round,
            duration=session.duration_str,
            disagreements=len(session.disagreements),
            covered_topics=len(session.covered_topics),
        )

        return session

    async def stream(
        self,
        report_content: str,
        topic: str,
        target: str,
        report_id: str = "",
        max_rounds: int = 6,
    ) -> AsyncGenerator[dict, None]:
        """Run a panel session with streaming events for live dashboard updates.

        Yields event dicts that can be sent via WebSocket or SSE.

        Args:
            report_content: Full report markdown.
            topic: Analytical topic.
            target: Intelligence target.
            report_id: Optional linked report ID.
            max_rounds: Maximum rounds.

        Yields:
            Event dicts with type, analyst, content, round, etc.
        """
        session = PanelSessionState(
            report_id=report_id,
            topic=topic,
            target=target,
            report_content=report_content,
            max_rounds=max_rounds,
        )

        yield {
            "type": "session_started",
            "session_id": session.session_id,
            "target": target,
            "topic": topic,
            "max_rounds": max_rounds,
        }

        # Opening
        opening = await self.gemini.open_session(session)
        session.add_turn(AnalystID.GEMINI, opening)
        current_question = self.gemini.extract_question(opening)

        yield {
            "type": "director_turn",
            "round": 0,
            "analyst": "SESSION-DIRECTOR",
            "content": opening,
            "question": current_question,
            "status": "ACTIVE",
        }

        while session.round < session.max_rounds and not session.concluded:
            session.round += 1

            yield {"type": "round_started", "round": session.round}

            # Alpha turn
            alpha_response = await self._get_alpha_turn(session, current_question)
            yield {
                "type": "analyst_turn",
                "round": session.round,
                "analyst": "ANALYST-ALPHA",
                "content": alpha_response,
            }

            await asyncio.sleep(0.1)  # Brief pause for stream flushing

            # Bravo turn
            bravo_response = await self._get_bravo_turn(session, current_question, alpha_response)
            yield {
                "type": "analyst_turn",
                "round": session.round,
                "analyst": "ANALYST-BRAVO",
                "content": bravo_response,
            }

            # Disagreement detection
            disagreement = self._detect_disagreement(session, alpha_response, bravo_response)
            if disagreement:
                yield {"type": "disagreement_detected", "round": session.round, "topic": disagreement}

            await asyncio.sleep(0.1)

            # Director turn
            direction = await self.gemini.direct(session, alpha_response, bravo_response)
            session.add_turn(AnalystID.GEMINI, direction)

            new_covered = self.gemini.extract_covered_topics(direction)
            for topic_key in new_covered:
                session.mark_covered(topic_key)

            current_question = self.gemini.extract_question(direction)
            status = self.gemini.extract_status(direction)

            yield {
                "type": "director_turn",
                "round": session.round,
                "analyst": "SESSION-DIRECTOR",
                "content": direction,
                "question": current_question,
                "status": status,
                "covered_topics": list(session.covered_topics.keys()),
            }

            if "CONCLUDING" in status or session.round >= session.max_rounds:
                session.concluded = True
                break

        # Synthesis
        yield {"type": "synthesis_started"}
        session.final_synthesis = await self.gemini.synthesize(session)
        session.end_time = datetime.utcnow()

        yield {
            "type": "session_complete",
            "session_id": session.session_id,
            "rounds_completed": session.round,
            "duration": session.duration_str,
            "disagreements": len(session.disagreements),
            "final_synthesis": session.final_synthesis,
        }

    async def _get_alpha_turn(
        self, session: PanelSessionState, question: str
    ) -> str:
        """Get ANALYST-ALPHA's turn with loop detection and auto-correction.

        Args:
            session: Current session state.
            question: Director's question for this round.

        Returns:
            Alpha's analysis content.
        """
        alpha_id = AnalystID.CLAUDE.value
        response = await self.claude.analyze(session, question)

        is_loop, matched_prior, sim = self.loop_detector.is_loop(
            alpha_id, response, session.positions.get(alpha_id, [])
        )

        if is_loop:
            logger.info("alpha_loop_detected_regenerating", similarity=sim)
            redirect_section = self.loop_detector.find_least_covered_section(
                session.report_content, session.covered_topics
            )
            augmented_question = (
                f"{question}\n\n"
                f"[DIRECTOR LOOP-BREAK]: Your prior point was already covered. "
                f"Redirect your analysis to {redirect_section}. "
                f"Do not restate: '{matched_prior[:100] if matched_prior else ''}'"
            )
            response = await self.claude.analyze(session, augmented_question)
            session.add_turn(AnalystID.CLAUDE, response, is_loop_flagged=True)
        else:
            session.add_turn(AnalystID.CLAUDE, response)

        session.record_position(alpha_id, response)
        return response

    async def _get_bravo_turn(
        self, session: PanelSessionState, question: str, alpha_response: str
    ) -> str:
        """Get ANALYST-BRAVO's turn with loop detection and auto-correction.

        Args:
            session: Current session state.
            question: Director's question.
            alpha_response: Alpha's response this round (Bravo sees this).

        Returns:
            Bravo's analysis content.
        """
        bravo_id = AnalystID.CHATGPT.value
        response = await self.chatgpt.analyze(session, question, alpha_response)

        is_loop, matched_prior, sim = self.loop_detector.is_loop(
            bravo_id, response, session.positions.get(bravo_id, [])
        )

        if is_loop:
            logger.info("bravo_loop_detected_regenerating", similarity=sim)
            redirect_section = self.loop_detector.find_least_covered_section(
                session.report_content, session.covered_topics
            )
            augmented_question = (
                f"{question}\n\n"
                f"[DIRECTOR LOOP-BREAK]: That analytical ground was already covered. "
                f"Find a new angle in {redirect_section}. "
                f"Do not echo: '{matched_prior[:100] if matched_prior else ''}'"
            )
            response = await self.chatgpt.analyze(session, augmented_question, alpha_response)
            session.add_turn(AnalystID.CHATGPT, response, is_loop_flagged=True)
        else:
            session.add_turn(AnalystID.CHATGPT, response)

        session.record_position(bravo_id, response)
        return response

    def _detect_disagreement(
        self,
        session: PanelSessionState,
        alpha_response: str,
        bravo_response: str,
    ) -> str | None:
        """Detect and record significant disagreements between analysts.

        Uses keyword divergence as a fast heuristic — semantic similarity
        divergence on key intelligence terms indicates genuine disagreement.

        Args:
            session: Session state (mutated with disagreement if found).
            alpha_response: Alpha's analysis this round.
            bravo_response: Bravo's analysis this round.

        Returns:
            Topic of disagreement, or None if none detected.
        """
        # Check for explicit disagreement markers in Bravo's response
        disagreement_markers = [
            "i disagree", "challenge this", "counter to", "contrary to",
            "alpha overlooks", "alpha misses", "however, the data suggests",
            "a different interpretation", "this contradicts",
        ]

        bravo_lower = bravo_response.lower()
        has_explicit_disagreement = any(m in bravo_lower for m in disagreement_markers)

        if has_explicit_disagreement:
            # Extract topic from response (first 50 chars after disagreement marker)
            topic = "Analytical interpretation"
            for marker in disagreement_markers:
                idx = bravo_lower.find(marker)
                if idx >= 0:
                    topic_snippet = bravo_response[max(0, idx-30):idx+60].strip()
                    topic = topic_snippet[:60] if topic_snippet else "Analytical interpretation"
                    break

            session.add_disagreement(
                round_number=session.round,
                topic=topic,
                alpha_position=alpha_response[:400],
                bravo_position=bravo_response[:400],
                director_note="[Auto-detected via disagreement marker analysis]",
            )
            logger.info("disagreement_recorded", round=session.round, topic=topic[:50])
            return topic

        return None


panel_engine = PanelEngine()
