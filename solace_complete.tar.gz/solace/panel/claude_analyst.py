"""
SOLACE — Panel AI Analyst Clients
Thin async wrappers for Claude, ChatGPT, and Gemini panel roles.
"""
from __future__ import annotations

import anthropic
import google.generativeai as genai
from openai import OpenAI

from config import get_logger, settings
from panel.prompts import CLAUDE_SYSTEM, CHATGPT_SYSTEM, GEMINI_SYSTEM
from panel.session import PanelSessionState

logger = get_logger("panel_analysts")


# ── Claude — ANALYST-ALPHA ─────────────────────────────────────────────────────

class ClaudeAnalyst:
    """ANALYST-ALPHA: Claude — OSINT + behavioral analysis specialist."""

    def __init__(self) -> None:
        self._client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

    async def analyze(self, session: PanelSessionState, question: str) -> str:
        """Generate an analysis turn from ANALYST-ALPHA.

        Args:
            session: Current panel session state.
            question: The director's analytical question for this round.

        Returns:
            Analysis content string.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        # Build message with full context
        user_prompt = self._build_prompt(session, question)

        def _call() -> str:
            response = self._client.messages.create(
                model="claude-opus-4-5",
                max_tokens=settings.panel_max_tokens,
                system=CLAUDE_SYSTEM,
                messages=[{"role": "user", "content": user_prompt}],
            )
            return response.content[0].text

        try:
            result = await loop.run_in_executor(None, _call)
            logger.info("claude_turn_complete", round=session.round, length=len(result))
            return result
        except Exception as exc:
            logger.error("claude_analyst_error", error=str(exc), round=session.round)
            return f"[ANALYST-ALPHA ERROR — Round {session.round}]: Analysis unavailable. Error: {str(exc)[:100]}"

    def _build_prompt(self, session: PanelSessionState, question: str) -> str:
        """Build the full prompt for Claude including report and session context."""
        recent_context = session.get_recent_context(n_turns=4)
        covered = list(session.covered_topics.keys())

        return (
            f"INTELLIGENCE REPORT UNDER ANALYSIS:\n"
            f"{'─' * 60}\n"
            f"{session.report_content[:4000]}\n"
            f"{'─' * 60}\n\n"
            f"DIRECTOR'S ANALYTICAL QUESTION (Round {session.round}):\n"
            f"{question}\n\n"
            f"TOPICS ALREADY COVERED (do NOT revisit):\n"
            f"{', '.join(covered) if covered else 'None yet'}\n\n"
            f"RECENT PANEL EXCHANGE:\n"
            f"{recent_context if recent_context else 'Session opening.'}\n\n"
            f"Provide your analysis now. Advance the analysis — do not restate covered ground."
        )


# ── ChatGPT — ANALYST-BRAVO ────────────────────────────────────────────────────

class ChatGPTAnalyst:
    """ANALYST-BRAVO: ChatGPT — OSINT methodology + human patterns specialist."""

    def __init__(self) -> None:
        self._client = OpenAI(api_key=settings.openai_api_key)

    async def analyze(
        self, session: PanelSessionState, question: str, alpha_response: str
    ) -> str:
        """Generate an analysis turn from ANALYST-BRAVO.

        BRAVO always sees ALPHA's response for this round before responding.

        Args:
            session: Current panel session state.
            question: The director's analytical question.
            alpha_response: ANALYST-ALPHA's response this round.

        Returns:
            Analysis content string.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        user_prompt = self._build_prompt(session, question, alpha_response)

        def _call() -> str:
            messages = [
                {"role": "system", "content": CHATGPT_SYSTEM},
                {"role": "user", "content": user_prompt},
            ]
            response = self._client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                max_tokens=settings.panel_max_tokens,
            )
            return response.choices[0].message.content

        try:
            result = await loop.run_in_executor(None, _call)
            logger.info("chatgpt_turn_complete", round=session.round, length=len(result))
            return result
        except Exception as exc:
            logger.error("chatgpt_analyst_error", error=str(exc), round=session.round)
            return f"[ANALYST-BRAVO ERROR — Round {session.round}]: Analysis unavailable. Error: {str(exc)[:100]}"

    def _build_prompt(
        self, session: PanelSessionState, question: str, alpha_response: str
    ) -> str:
        """Build the prompt for GPT including Alpha's response this round."""
        covered = list(session.covered_topics.keys())
        prior_context = session.get_recent_context(n_turns=3)

        return (
            f"INTELLIGENCE REPORT UNDER ANALYSIS:\n"
            f"{'─' * 60}\n"
            f"{session.report_content[:4000]}\n"
            f"{'─' * 60}\n\n"
            f"DIRECTOR'S ANALYTICAL QUESTION (Round {session.round}):\n"
            f"{question}\n\n"
            f"ANALYST-ALPHA'S RESPONSE THIS ROUND:\n"
            f"{alpha_response}\n\n"
            f"TOPICS ALREADY COVERED (do NOT revisit):\n"
            f"{', '.join(covered) if covered else 'None yet'}\n\n"
            f"PRIOR CONTEXT:\n"
            f"{prior_context if prior_context else 'Session opening.'}\n\n"
            f"Build on, challenge, or extend ANALYST-ALPHA's analysis. "
            f"Find a new analytical angle — do not restate what ALPHA just said."
        )


# ── Gemini — SESSION-DIRECTOR ──────────────────────────────────────────────────

class GeminiDirector:
    """SESSION-DIRECTOR: Gemini — panel manager, anti-loop enforcer, synthesizer."""

    def __init__(self) -> None:
        genai.configure(api_key=settings.google_ai_api_key)
        self._model = genai.GenerativeModel("gemini-1.5-pro")

    async def direct(
        self,
        session: PanelSessionState,
        alpha_response: str,
        bravo_response: str,
    ) -> str:
        """Generate director commentary and next question after a round.

        Args:
            session: Current panel session state.
            alpha_response: ANALYST-ALPHA's content this round.
            bravo_response: ANALYST-BRAVO's content this round.

        Returns:
            Director commentary with status and next question.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        prompt = self._build_direction_prompt(session, alpha_response, bravo_response)

        def _call() -> str:
            full_prompt = f"{GEMINI_SYSTEM}\n\n{prompt}"
            response = self._model.generate_content(full_prompt)
            return response.text

        try:
            result = await loop.run_in_executor(None, _call)
            logger.info("gemini_director_complete", round=session.round, length=len(result))
            return result
        except Exception as exc:
            logger.error("gemini_director_error", error=str(exc), round=session.round)
            return (
                f"[DIRECTOR]\nRound {session.round} complete. Proceeding.\n"
                f"[QUESTION]: What additional behavioral indicators can be inferred from the timeline data?\n"
                f"[STATUS]: ACTIVE\n[ROUND]: {session.round} of {session.max_rounds}\n[COVERED]: See session log"
            )

    async def open_session(self, session: PanelSessionState) -> str:
        """Generate the opening director statement and first question.

        Args:
            session: Session state with report content and topic loaded.

        Returns:
            Opening director statement with first analytical question.
        """
        import asyncio
        loop = asyncio.get_event_loop()

        prompt = (
            f"OPENING SESSION\n\n"
            f"Topic: {session.topic}\n"
            f"Target: {session.target}\n"
            f"Max Rounds: {session.max_rounds}\n\n"
            f"REPORT SUMMARY (first 3000 chars):\n{session.report_content[:3000]}\n\n"
            f"Open the session. Set the analytical agenda. "
            f"Issue your first targeted question. What should the analysts examine first?"
        )

        def _call() -> str:
            full_prompt = f"{GEMINI_SYSTEM}\n\n{prompt}"
            response = self._model.generate_content(full_prompt)
            return response.text

        try:
            result = await loop.run_in_executor(None, _call)
            logger.info("session_opened_by_director")
            return result
        except Exception as exc:
            logger.error("gemini_open_session_error", error=str(exc))
            return (
                f"[DIRECTOR]: Session open. Analysts, review the report on {session.target}.\n"
                f"[QUESTION]: What is the primary behavioral pattern visible in the collected intelligence?\n"
                f"[STATUS]: ACTIVE\n[ROUND]: 0 of {session.max_rounds}\n[COVERED]: None"
            )

    async def synthesize(self, session: PanelSessionState) -> str:
        """Generate the final intelligence assessment synthesis.

        Args:
            session: Completed session with full transcript.

        Returns:
            Final structured intelligence assessment markdown.
        """
        import asyncio
        from panel.prompts import SYNTHESIS_PROMPT_TEMPLATE
        loop = asyncio.get_event_loop()

        transcript_text = session.get_formatted_transcript()
        disagreements_text = "\n".join(
            f"Round {d.round_number} — {d.topic}:\n  ALPHA: {d.alpha_position}\n  BRAVO: {d.bravo_position}"
            for d in session.disagreements
        ) or "No formal disagreements recorded."

        synthesis_prompt = SYNTHESIS_PROMPT_TEMPLATE.format(
            session_id=session.session_id,
            report_id=session.report_id or "N/A",
            target=session.target,
            rounds=session.round,
            duration=session.duration_str,
            transcript=transcript_text[-8000:],  # Last 8k chars to fit context
            disagreements=disagreements_text,
            covered_topics=", ".join(session.covered_topics.keys()) or "None recorded",
        )

        def _call() -> str:
            full_prompt = f"{GEMINI_SYSTEM}\n\n{synthesis_prompt}"
            response = self._model.generate_content(full_prompt)
            return response.text

        try:
            result = await loop.run_in_executor(None, _call)
            logger.info("synthesis_complete", session_id=session.session_id)
            return result
        except Exception as exc:
            logger.error("synthesis_error", error=str(exc))
            return f"[SYNTHESIS ERROR]: Final assessment generation failed. Transcript preserved. Error: {exc}"

    def _build_direction_prompt(
        self,
        session: PanelSessionState,
        alpha_response: str,
        bravo_response: str,
    ) -> str:
        """Build the round-end direction prompt for Gemini."""
        covered = list(session.covered_topics.keys())
        positions_summary = {
            analyst: pts[-3:] for analyst, pts in session.positions.items()
        }

        return (
            f"ROUND {session.round} COMPLETE\n\n"
            f"REPORT SUMMARY:\n{session.report_content[:2000]}\n\n"
            f"ANALYST-ALPHA THIS ROUND:\n{alpha_response[:800]}\n\n"
            f"ANALYST-BRAVO THIS ROUND:\n{bravo_response[:800]}\n\n"
            f"TOPICS COVERED SO FAR:\n{', '.join(covered) if covered else 'None'}\n\n"
            f"RECENT POSITIONS:\n{positions_summary}\n\n"
            f"Rounds remaining: {session.max_rounds - session.round}\n\n"
            f"Review this round. Detect any loops. Record disagreements. "
            f"Issue your next direction. If coverage is complete, call CONCLUDING."
        )

    @staticmethod
    def extract_question(director_output: str) -> str:
        """Extract the [QUESTION] line from director output.

        Args:
            director_output: Raw director response text.

        Returns:
            The question string, or a fallback.
        """
        for line in director_output.split("\n"):
            if line.strip().startswith("[QUESTION]"):
                return line.replace("[QUESTION]:", "").replace("[QUESTION]", "").strip()
        return "What additional patterns or anomalies can be identified from the remaining report data?"

    @staticmethod
    def extract_status(director_output: str) -> str:
        """Extract the [STATUS] from director output."""
        for line in director_output.split("\n"):
            if line.strip().startswith("[STATUS]"):
                return line.replace("[STATUS]:", "").replace("[STATUS]", "").strip().upper()
        return "ACTIVE"

    @staticmethod
    def extract_covered_topics(director_output: str) -> list[str]:
        """Extract [COVERED] topics from director output."""
        for line in director_output.split("\n"):
            if line.strip().startswith("[COVERED]"):
                covered_str = line.replace("[COVERED]:", "").replace("[COVERED]", "").strip()
                return [t.strip() for t in covered_str.split(",") if t.strip() and t.strip().lower() != "none"]
        return []
