"""
SOLACE — Panel Session State
Dataclass managing all state for a 3-AI analyst panel session.
"""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from core.schemas import AnalystID, Disagreement, PanelStatus, PanelTurn


def _sid() -> str:
    return f"SESSION-{uuid.uuid4().hex[:8].upper()}"


@dataclass
class PanelSessionState:
    """Complete mutable state for a live panel session.

    This is the single source of truth during a panel run.
    Persisted to PostgreSQL at the end of each round.
    """

    # Identity
    session_id: str = field(default_factory=_sid)
    report_id: str = ""
    topic: str = ""
    target: str = ""

    # Content
    report_content: str = ""

    # Transcript — ordered list of all turns
    history: list[PanelTurn] = field(default_factory=list)

    # Per-analyst position tracking for loop detection
    # {analyst_id: [content of each substantive point made]}
    positions: dict[str, list[str]] = field(default_factory=dict)

    # Topic fingerprints for loop detection
    # {topic_key: round_first_covered}
    covered_topics: dict[str, int] = field(default_factory=dict)

    # Disagreements between analysts
    disagreements: list[Disagreement] = field(default_factory=list)

    # Questions Gemini has asked that are still open
    open_questions: list[str] = field(default_factory=list)

    # Session control
    round: int = 0
    max_rounds: int = 6
    concluded: bool = False
    status: PanelStatus = PanelStatus.ACTIVE

    # Timing
    start_time: datetime = field(default_factory=datetime.utcnow)
    end_time: datetime | None = None

    # Output
    final_synthesis: str = ""

    def add_turn(self, analyst: AnalystID, content: str, is_loop_flagged: bool = False) -> PanelTurn:
        """Add a turn to the session transcript.

        Args:
            analyst: The analyst who produced this turn.
            content: The content of the turn.
            is_loop_flagged: Whether this turn was flagged as a loop.

        Returns:
            The created PanelTurn.
        """
        turn = PanelTurn(
            turn_id=uuid.uuid4().hex[:8],
            round_number=self.round,
            analyst=analyst,
            content=content,
            is_loop_flagged=is_loop_flagged,
        )
        self.history.append(turn)
        return turn

    def record_position(self, analyst_id: str, content: str) -> None:
        """Record a substantive point for loop detection.

        Args:
            analyst_id: Analyst identifier string.
            content: Point content (first 300 chars stored).
        """
        if analyst_id not in self.positions:
            self.positions[analyst_id] = []
        self.positions[analyst_id].append(content[:300])

    def add_disagreement(
        self,
        round_number: int,
        topic: str,
        alpha_position: str,
        bravo_position: str,
        director_note: str = "",
    ) -> None:
        """Record an analytical disagreement between Alpha and Bravo.

        Args:
            round_number: The round this disagreement occurred in.
            topic: Topic of disagreement.
            alpha_position: ANALYST-ALPHA's position.
            bravo_position: ANALYST-BRAVO's position.
            director_note: Optional director commentary.
        """
        self.disagreements.append(Disagreement(
            round_number=round_number,
            topic=topic,
            alpha_position=alpha_position[:400],
            bravo_position=bravo_position[:400],
            director_note=director_note,
        ))

    def mark_covered(self, topic_key: str) -> None:
        """Mark a topic as covered at the current round."""
        self.covered_topics[topic_key] = self.round

    def get_formatted_transcript(self) -> str:
        """Format the full transcript for synthesis prompts."""
        lines = []
        for turn in self.history:
            label = turn.analyst.value
            loop_note = " [LOOP FLAGGED]" if turn.is_loop_flagged else ""
            lines.append(f"\n--- Round {turn.round_number} | {label}{loop_note} ---\n{turn.content}")
        return "\n".join(lines)

    def get_recent_context(self, n_turns: int = 6) -> str:
        """Get the last N turns as a context string.

        Args:
            n_turns: Number of recent turns to include.

        Returns:
            Formatted string of recent turns.
        """
        recent = self.history[-n_turns:] if len(self.history) > n_turns else self.history
        lines = []
        for turn in recent:
            lines.append(f"[{turn.analyst.value}]: {turn.content[:600]}")
        return "\n\n".join(lines)

    @property
    def duration_str(self) -> str:
        """Human-readable session duration string."""
        end = self.end_time or datetime.utcnow()
        delta = end - self.start_time
        minutes = int(delta.total_seconds() // 60)
        seconds = int(delta.total_seconds() % 60)
        return f"{minutes}m {seconds}s"

    def to_db_dict(self) -> dict[str, Any]:
        """Serialize to dict for database storage."""
        return {
            "session_id": self.session_id,
            "topic": self.topic,
            "target": self.target,
            "transcript": [t.model_dump() for t in self.history],
            "positions": self.positions,
            "covered_topics": list(self.covered_topics.keys()),
            "disagreements": [d.model_dump() for d in self.disagreements],
            "rounds_completed": self.round,
            "final_synthesis": self.final_synthesis,
            "concluded": self.concluded,
            "start_time": self.start_time,
            "end_time": self.end_time,
        }
