"""SOLACE panel — 3-AI analyst engine.

Note: panel_engine is lazily imported to avoid eager AI client instantiation
at module load time (which requires valid API keys even in test environments).
"""
from panel.session import PanelSessionState
from panel.loop_detector import LoopDetector

def get_panel_engine():
    """Lazy accessor for the panel engine singleton."""
    from panel.engine import panel_engine
    return panel_engine

__all__ = [
    "PanelSessionState",
    "LoopDetector",
    "get_panel_engine",
]
