"""
SOLACE — Discord Bot
Channel-per-topic intel delivery, slash commands, and live panel streaming.
"""
from __future__ import annotations

import discord
from discord.ext import commands
from discord import app_commands

from config import get_logger, settings
from core.schemas import Alert, Classification

logger = get_logger("discord_bot")

CONFIDENCE_COLORS = {
    "HIGH": 0x00ff88,
    "MEDIUM": 0xffaa00,
    "LOW": 0x888888,
}

CLASSIFICATION_EMOJI = {
    "TLP:WHITE": "⬜",
    "TLP:GREEN": "🟢",
    "TLP:AMBER": "🟡",
    "TLP:RED": "🔴",
}


class SolaceDiscordBot(commands.Bot):
    """SOLACE Discord bot for intel delivery and command interface."""

    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)
        self._guild_id = int(settings.discord_guild_id) if settings.discord_guild_id else None

    async def setup_hook(self) -> None:
        """Register slash commands with Discord on startup."""
        if self._guild_id:
            guild = discord.Object(id=self._guild_id)
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        logger.info("discord_slash_commands_synced")

    async def on_ready(self) -> None:
        logger.info("discord_bot_ready", user=str(self.user))
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name="SOLACE Intelligence Feed")
        )

    async def post_alert(self, alert: Alert) -> bool:
        """Post an intelligence alert to the appropriate Discord channel.

        Args:
            alert: Alert to post.

        Returns:
            True if posted successfully.
        """
        try:
            channel_id = int(settings.discord_alerts_channel_id)
            channel = self.get_channel(channel_id)
            if not channel:
                logger.warning("discord_alerts_channel_not_found")
                return False

            color = CONFIDENCE_COLORS.get("HIGH" if alert.classification == Classification.RED else "MEDIUM", 0x555555)
            emoji = CLASSIFICATION_EMOJI.get(alert.classification.value, "⬜")

            embed = discord.Embed(
                title=f"{emoji} {alert.title}",
                description=alert.body[:2000],
                color=color,
            )
            embed.add_field(name="Classification", value=alert.classification.value, inline=True)
            embed.add_field(name="Alert ID", value=f"`{alert.alert_id}`", inline=True)
            if alert.report_id:
                embed.add_field(name="Report", value=f"`{alert.report_id}`", inline=True)
            embed.set_footer(text=f"SOLACE Intelligence Platform • {alert.created_at.strftime('%Y-%m-%d %H:%M UTC')}")

            await channel.send(embed=embed)
            logger.info("discord_alert_posted", alert_id=alert.alert_id)
            return True

        except Exception as exc:
            logger.error("discord_alert_failed", error=str(exc))
            return False

    async def post_panel_turn(self, session_id: str, analyst: str, content: str, round_num: int) -> None:
        """Post a panel turn to the panel sessions channel.

        Args:
            session_id: Panel session ID.
            analyst: Analyst identifier.
            content: Turn content.
            round_num: Round number.
        """
        try:
            channel_id = int(settings.discord_panel_channel_id)
            channel = self.get_channel(channel_id)
            if not channel:
                return

            colors = {
                "ANALYST-ALPHA": 0x00ff88,
                "ANALYST-BRAVO": 0x0088ff,
                "SESSION-DIRECTOR": 0xffaa00,
            }

            embed = discord.Embed(
                title=f"Round {round_num} — {analyst}",
                description=content[:2000],
                color=colors.get(analyst, 0x555555),
            )
            embed.set_footer(text=f"Session: {session_id}")
            await channel.send(embed=embed)

        except Exception as exc:
            logger.error("discord_panel_post_failed", error=str(exc))

    async def get_or_create_topic_channel(self, tag: str) -> discord.TextChannel | None:
        """Get or create a dedicated channel for an intel topic/tag.

        Args:
            tag: Topic tag (becomes channel name).

        Returns:
            The Discord text channel.
        """
        if not self._guild_id:
            return None

        guild = self.get_guild(self._guild_id)
        if not guild:
            return None

        channel_name = f"intel-{tag.lower().replace(' ', '-')[:80]}"
        existing = discord.utils.get(guild.text_channels, name=channel_name)
        if existing:
            return existing

        try:
            category = discord.utils.get(guild.categories, name="SOLACE Intel")
            if not category:
                category = await guild.create_category("SOLACE Intel")

            channel = await guild.create_text_channel(
                channel_name,
                category=category,
                topic=f"SOLACE intelligence feed for topic: {tag}",
            )
            logger.info("discord_channel_created", channel=channel_name)
            return channel
        except Exception as exc:
            logger.error("discord_channel_creation_failed", error=str(exc))
            return None


discord_bot = SolaceDiscordBot()


# ── Slash Commands ─────────────────────────────────────────────────────────────

@discord_bot.tree.command(name="osint", description="Trigger an OSINT collection run")
@app_commands.describe(target="Target subject", target_type="Type: organization/person/infrastructure/event")
async def osint_command(interaction: discord.Interaction, target: str, target_type: str = "organization"):
    await interaction.response.defer()
    try:
        from tasks.collection_tasks import run_full_osint_pipeline
        task = run_full_osint_pipeline.delay(
            target=target,
            target_type=target_type,
            requestor=f"discord:{interaction.user.id}",
        )
        embed = discord.Embed(
            title="🕷️ OSINT Collection Started",
            description=f"**Target:** {target}\n**Type:** {target_type}\n**Task ID:** `{task.id}`",
            color=0x00ff88,
        )
        await interaction.followup.send(embed=embed)
    except Exception as exc:
        await interaction.followup.send(f"❌ Error: {exc}")


@discord_bot.tree.command(name="panel", description="Start a 3-AI panel analysis session on a report")
@app_commands.describe(report_id="SOLACE Report ID to analyze")
async def panel_command(interaction: discord.Interaction, report_id: str):
    await interaction.response.defer()
    embed = discord.Embed(
        title="🧠 Panel Session Initiating",
        description=(
            f"**Report:** `{report_id}`\n\n"
            f"Convening panel:\n"
            f"🟢 ANALYST-ALPHA (Claude)\n"
            f"🔵 ANALYST-BRAVO (ChatGPT)\n"
            f"🟡 SESSION-DIRECTOR (Gemini)\n\n"
            f"Transcript will stream to this channel."
        ),
        color=0xffaa00,
    )
    await interaction.followup.send(embed=embed)


@discord_bot.tree.command(name="search", description="Semantic search across SOLACE reports")
@app_commands.describe(query="Natural language search query")
async def search_command(interaction: discord.Interaction, query: str):
    await interaction.response.defer()
    try:
        from storage.pgvector_client import pgvector_client
        results = await pgvector_client.search_reports(query, limit=5)
        if not results:
            await interaction.followup.send(f"No results found for: `{query}`")
            return

        embed = discord.Embed(title=f"🔎 Search: {query}", color=0x0088ff)
        for r in results:
            sim = r.get("similarity", 0)
            embed.add_field(
                name=f"{r['report_id']} ({sim:.1%})",
                value=f"**{r['subject']}** — {r['classification']}\n{r.get('executive_summary', '')[:100]}…",
                inline=False,
            )
        await interaction.followup.send(embed=embed)
    except Exception as exc:
        await interaction.followup.send(f"Search error: {exc}")


# ── Notification Router ────────────────────────────────────────────────────────

class NotificationRouter:
    """Routes intelligence alerts to appropriate channels based on classification."""

    def __init__(self) -> None:
        from comms.telegram_bot import telegram_bot as tg
        self._telegram = tg
        self._discord = discord_bot

    async def route(self, alert: Alert) -> None:
        """Route an alert to appropriate comms channels by classification.

        Args:
            alert: The alert to route.
        """
        classification = alert.classification

        if classification == Classification.RED:
            # TLP:RED → Signal + Telegram (priority) + Discord alerts
            await self._try_signal(alert)
            await self._telegram.send_alert(alert)
            await self._discord.post_alert(alert)
            logger.info("alert_routed_red", alert_id=alert.alert_id)

        elif classification == Classification.AMBER:
            # TLP:AMBER → Telegram + Discord alerts
            await self._telegram.send_alert(alert)
            await self._discord.post_alert(alert)
            logger.info("alert_routed_amber", alert_id=alert.alert_id)

        else:
            # TLP:WHITE / GREEN → Discord topic channel only
            for tag in alert.tags[:3]:
                channel = await self._discord.get_or_create_topic_channel(tag)
                if channel:
                    embed = discord.Embed(
                        title=alert.title,
                        description=alert.body[:1500],
                        color=0x444444,
                    )
                    embed.set_footer(text=f"{alert.classification.value} • {alert.alert_id}")
                    await channel.send(embed=embed)
            logger.info("alert_routed_white_green", alert_id=alert.alert_id)

    async def _try_signal(self, alert: Alert) -> None:
        """Attempt to send via Signal CLI for critical alerts."""
        if not settings.signal_sender_number:
            return
        try:
            from comms.signal_client import signal_client
            await signal_client.send(
                f"🔴 SOLACE CRITICAL ALERT\n{alert.title}\n\n{alert.body[:500]}"
            )
        except Exception as exc:
            logger.warning("signal_delivery_failed", error=str(exc))


notification_router = NotificationRouter()
