"""
SOLACE — Telegram Bot
Dual-purpose: collection monitor (Telethon MTProto) + alert bot (Bot API).
Supports command interface for triggering OSINT runs from Telegram.
"""
from __future__ import annotations

import asyncio
from typing import Any

from config import get_logger, settings
from core.schemas import Alert, Classification

logger = get_logger("telegram_bot")

# Command handlers registry
COMMANDS: dict[str, str] = {
    "/run": "Trigger OSINT collection — usage: /run <target> <type>",
    "/status": "Show bot team and pipeline status",
    "/report": "Retrieve a report summary — usage: /report <report_id>",
    "/panel": "Start AI panel on a report — usage: /panel <report_id>",
    "/search": "Semantic search reports — usage: /search <query>",
    "/help": "Show available commands",
}

CLASSIFICATION_COLORS = {
    Classification.WHITE: "⬜",
    Classification.GREEN: "🟢",
    Classification.AMBER: "🟡",
    Classification.RED: "🔴",
}


class TelegramBot:
    """SOLACE Telegram integration.

    Collection mode: Uses Telethon (MTProto) to monitor public channels/groups.
    Alert mode: Uses Bot API to send formatted intelligence alerts.
    Command mode: Processes /commands to trigger platform actions.
    """

    def __init__(self) -> None:
        self._bot_client = None  # python-telegram-bot client
        self._telethon_client = None  # Telethon MTProto client
        self._running = False

    async def start_alert_bot(self) -> None:
        """Start the Telegram Bot API client for alerts and commands."""
        if not settings.telegram_bot_token:
            logger.warning("telegram_bot_token_not_configured")
            return

        try:
            from telegram import Update
            from telegram.ext import Application, CommandHandler, MessageHandler, filters

            app = Application.builder().token(settings.telegram_bot_token).build()

            app.add_handler(CommandHandler("run", self._handle_run))
            app.add_handler(CommandHandler("status", self._handle_status))
            app.add_handler(CommandHandler("report", self._handle_report))
            app.add_handler(CommandHandler("panel", self._handle_panel))
            app.add_handler(CommandHandler("search", self._handle_search))
            app.add_handler(CommandHandler("help", self._handle_help))

            self._bot_client = app
            await app.initialize()
            await app.start()
            logger.info("telegram_alert_bot_started")

        except Exception as exc:
            logger.error("telegram_bot_start_failed", error=str(exc))

    async def start_collection_monitor(
        self, channels: list[str], keywords: list[str]
    ) -> None:
        """Start Telethon MTProto client to monitor public channels.

        Args:
            channels: List of channel usernames or IDs to monitor.
            keywords: Keywords to filter for in messages.
        """
        if not (settings.telegram_api_id and settings.telegram_api_hash):
            logger.warning("telegram_api_credentials_not_configured")
            return

        try:
            from telethon import TelegramClient, events

            client = TelegramClient(
                "solace_collector",
                int(settings.telegram_api_id),
                settings.telegram_api_hash,
            )

            @client.on(events.NewMessage(chats=channels))
            async def _on_message(event):
                text = event.message.text or ""
                if any(kw.lower() in text.lower() for kw in keywords):
                    await self._process_monitored_message(text, event)

            await client.start()
            self._telethon_client = client
            self._running = True
            logger.info("telegram_collection_monitor_started", channels=channels)
            await client.run_until_disconnected()

        except Exception as exc:
            logger.error("telegram_collection_monitor_failed", error=str(exc))

    async def send_alert(self, alert: Alert) -> bool:
        """Send a formatted intelligence alert to the configured chat.

        Args:
            alert: Alert object to send.

        Returns:
            True if sent successfully.
        """
        if not (settings.telegram_bot_token and settings.telegram_alert_chat_id):
            return False

        try:
            import httpx
            color = CLASSIFICATION_COLORS.get(alert.classification, "⬜")
            text = (
                f"{color} *SOLACE INTELLIGENCE ALERT*\n\n"
                f"🔖 `{alert.alert_id}`\n"
                f"📌 *{self._escape_md(alert.title)}*\n\n"
                f"{self._escape_md(alert.body[:800])}\n\n"
                f"🏷️ Classification: `{alert.classification.value}`\n"
                f"🕐 {alert.created_at.strftime('%Y-%m-%d %H:%M UTC')}"
            )
            if alert.report_id:
                text += f"\n📄 Report: `{alert.report_id}`"

            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"https://api.telegram.org/bot{settings.telegram_bot_token}/sendMessage",
                    json={
                        "chat_id": settings.telegram_alert_chat_id,
                        "text": text,
                        "parse_mode": "MarkdownV2",
                        "disable_web_page_preview": True,
                    },
                    timeout=10,
                )
                resp.raise_for_status()
                logger.info("telegram_alert_sent", alert_id=alert.alert_id)
                return True

        except Exception as exc:
            logger.error("telegram_alert_failed", error=str(exc), alert_id=alert.alert_id)
            return False

    async def _handle_run(self, update, context) -> None:
        """Handle /run <target> <type> command."""
        args = context.args
        if len(args) < 1:
            await update.message.reply_text("Usage: /run <target> [type]\nExample: /run 'Acme Corp' organization")
            return

        target = " ".join(args[:-1]) if len(args) > 1 else args[0]
        target_type = args[-1] if len(args) > 1 else "organization"

        await update.message.reply_text(
            f"🚀 *OSINT Collection Started*\n\n"
            f"Target: `{target}`\nType: `{target_type}`\n\nBot team deploying…",
            parse_mode="Markdown",
        )

        # Trigger via Celery
        try:
            from tasks.collection_tasks import run_full_osint_pipeline
            task = run_full_osint_pipeline.delay(
                target=target,
                target_type=target_type,
                requestor=f"telegram:{update.effective_user.id}",
            )
            await update.message.reply_text(f"✅ Task queued: `{task.id}`", parse_mode="Markdown")
        except Exception as exc:
            await update.message.reply_text(f"❌ Error: {exc}")

    async def _handle_status(self, update, context) -> None:
        """Handle /status command."""
        status_text = (
            "🤖 *SOLACE Bot Team Status*\n\n"
            "SPIDER-1 (Web/News): 🟢 Active\n"
            "SPIDER-2 (Social): 🟢 Active\n"
            "SPIDER-3 (Network): 🟢 Active\n"
            "SPIDER-4 (DarkWeb): 🟡 Standby\n"
            "SPIDER-5 (Corporate): 🟢 Active\n"
            "SPIDER-6 (Geo): 🟢 Active\n"
            "SPIDER-7 (Documents): 🟢 Active\n"
            "SPIDER-8 (Threat): 🟢 Active\n\n"
            "Panel Engine: 🟢 Ready\n"
            "Google Drive: 🟢 Connected\n"
        )
        await update.message.reply_text(status_text, parse_mode="Markdown")

    async def _handle_report(self, update, context) -> None:
        """Handle /report <report_id> command."""
        if not context.args:
            await update.message.reply_text("Usage: /report <report_id>")
            return

        report_id = context.args[0]
        await update.message.reply_text(f"🔍 Fetching report `{report_id}`…", parse_mode="Markdown")
        # TODO: Query DB and return summary
        await update.message.reply_text(f"Report lookup for `{report_id}` — check the dashboard for full details.", parse_mode="Markdown")

    async def _handle_panel(self, update, context) -> None:
        """Handle /panel <report_id> command."""
        if not context.args:
            await update.message.reply_text("Usage: /panel <report_id>")
            return
        report_id = context.args[0]
        await update.message.reply_text(
            f"🧠 *Starting Panel Session*\nReport: `{report_id}`\n\n"
            f"Convening ANALYST-ALPHA, ANALYST-BRAVO, and SESSION-DIRECTOR…\n"
            f"Results will be posted when complete.",
            parse_mode="Markdown",
        )

    async def _handle_search(self, update, context) -> None:
        """Handle /search <query> command."""
        if not context.args:
            await update.message.reply_text("Usage: /search <query>")
            return
        query = " ".join(context.args)
        try:
            from storage.pgvector_client import pgvector_client
            results = await pgvector_client.search_reports(query, limit=5)
            if not results:
                await update.message.reply_text(f"No results for: `{query}`", parse_mode="Markdown")
                return
            text = f"🔎 *Search Results for:* `{query}`\n\n"
            for r in results:
                sim = r.get("similarity", 0)
                text += f"• `{r['report_id']}` — {r['subject']} ({sim:.1%})\n"
            await update.message.reply_text(text, parse_mode="Markdown")
        except Exception as exc:
            await update.message.reply_text(f"Search error: {exc}")

    async def _handle_help(self, update, context) -> None:
        """Handle /help command."""
        text = "🛡️ *SOLACE Command Interface*\n\n"
        for cmd, desc in COMMANDS.items():
            text += f"`{cmd}` — {desc}\n"
        await update.message.reply_text(text, parse_mode="Markdown")

    async def _process_monitored_message(self, text: str, event) -> None:
        """Process a message from a monitored Telegram channel."""
        logger.info("monitored_message_captured", text_length=len(text))

    @staticmethod
    def _escape_md(text: str) -> str:
        """Escape special characters for Telegram MarkdownV2."""
        special = r"_*[]()~`>#+-=|{}.!"
        for char in special:
            text = text.replace(char, f"\\{char}")
        return text


telegram_bot = TelegramBot()
