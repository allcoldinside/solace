"""
SOLACE — Signal CLI Client
Subprocess wrapper for signal-cli daemon for encrypted alert delivery.
Outbound-only. TLP:RED and critical alerts only.
"""
from __future__ import annotations

import asyncio
import subprocess
from pathlib import Path

from config import get_logger, settings

logger = get_logger("signal_client")


class SignalClient:
    """Wraps signal-cli for encrypted message delivery.

    Only used for TLP:RED and CRITICAL alerts.
    No collection — outbound only.
    """

    def __init__(self) -> None:
        self._sender = settings.signal_sender_number
        self._config = settings.signal_cli_config_path

    async def send(self, message: str, recipients: list[str] | None = None) -> bool:
        """Send an encrypted Signal message.

        Args:
            message: Message text to send.
            recipients: List of recipient phone numbers. Defaults to configured sender.

        Returns:
            True if sent successfully.
        """
        if not self._sender:
            logger.warning("signal_sender_not_configured")
            return False

        targets = recipients or [self._sender]

        for recipient in targets:
            try:
                cmd = [
                    "signal-cli",
                    "-a", self._sender,
                    "--config", str(self._config),
                    "send",
                    "-m", message,
                    recipient,
                ]
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=30.0)

                if process.returncode != 0:
                    logger.error(
                        "signal_send_failed",
                        recipient=recipient,
                        stderr=stderr.decode()[:200],
                    )
                    return False

                logger.info("signal_message_sent", recipient=recipient)
                return True

            except asyncio.TimeoutError:
                logger.error("signal_send_timeout", recipient=recipient)
                return False
            except FileNotFoundError:
                logger.error("signal_cli_not_found", hint="Install signal-cli and ensure it's on PATH")
                return False
            except Exception as exc:
                logger.error("signal_send_error", error=str(exc))
                return False

        return True

    async def is_available(self) -> bool:
        """Check whether signal-cli is available on the system."""
        try:
            process = await asyncio.create_subprocess_exec(
                "signal-cli", "--version",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(process.communicate(), timeout=5.0)
            return process.returncode == 0
        except Exception:
            return False


signal_client = SignalClient()
