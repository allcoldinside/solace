import React, { useState } from 'react'
import { Outlet, NavLink, useLocation } from 'react-router-dom'
import {
  Shield, FileText, Brain, Share2, Radio,
  Activity, AlertTriangle, ChevronRight, Zap
} from 'lucide-react'
import { useAlertFeed } from '../../hooks/useAlertFeed'

const NAV = [
  { to: '/',          icon: Activity,     label: 'HQ OVERVIEW',    shortLabel: 'HQ'  },
  { to: '/reports',   icon: FileText,     label: 'INTEL REPORTS',  shortLabel: 'RPT' },
  { to: '/panel',     icon: Brain,        label: 'PANEL ENGINE',   shortLabel: 'PNL' },
  { to: '/entities',  icon: Share2,       label: 'ENTITY GRAPH',   shortLabel: 'ENT' },
  { to: '/collectors',icon: Radio,        label: 'BOT TEAM',       shortLabel: 'BOT' },
]

export default function Layout() {
  const location = useLocation()
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const { alerts } = useAlertFeed()
  const criticalCount = alerts.filter(a => a.classification === 'TLP:RED').length

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      background: 'var(--bg-primary)',
      overflow: 'hidden',
    }}>
      {/* ── Sidebar ─────────────────────────────────────────────── */}
      <aside style={{
        width: sidebarCollapsed ? 56 : 220,
        background: 'var(--bg-secondary)',
        borderRight: '1px solid var(--border-color)',
        display: 'flex',
        flexDirection: 'column',
        transition: 'width 0.2s ease',
        flexShrink: 0,
        position: 'relative',
        zIndex: 10,
      }}>
        {/* Logo */}
        <div style={{
          padding: sidebarCollapsed ? '16px 12px' : '20px 20px 16px',
          borderBottom: '1px solid var(--border-color)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Shield size={20} color="var(--accent-green)" style={{ flexShrink: 0 }} />
            {!sidebarCollapsed && (
              <div>
                <div style={{
                  fontFamily: 'var(--font-ui)',
                  fontWeight: 700,
                  fontSize: '1rem',
                  letterSpacing: '0.15em',
                  color: 'var(--accent-green)',
                  lineHeight: 1,
                }}>
                  SOLACE
                </div>
                <div style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.6rem',
                  color: 'var(--text-dim)',
                  letterSpacing: '0.08em',
                  marginTop: 2,
                }}>
                  INTELLIGENCE PLATFORM
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav style={{ flex: 1, padding: '12px 0' }}>
          {NAV.map(({ to, icon: Icon, label, shortLabel }) => {
            const active = location.pathname === to ||
              (to !== '/' && location.pathname.startsWith(to))
            return (
              <NavLink key={to} to={to} style={{ textDecoration: 'none' }}>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 10,
                  padding: sidebarCollapsed ? '10px 16px' : '10px 20px',
                  margin: '2px 8px',
                  borderRadius: 2,
                  background: active ? 'var(--accent-dim)' : 'transparent',
                  borderLeft: active ? '2px solid var(--accent-green)' : '2px solid transparent',
                  cursor: 'pointer',
                  transition: 'all 0.15s',
                }}>
                  <Icon
                    size={16}
                    color={active ? 'var(--accent-green)' : 'var(--text-dim)'}
                    style={{ flexShrink: 0 }}
                  />
                  {!sidebarCollapsed && (
                    <span style={{
                      fontFamily: 'var(--font-ui)',
                      fontWeight: 600,
                      fontSize: '0.75rem',
                      letterSpacing: '0.1em',
                      color: active ? 'var(--accent-green)' : 'var(--text-secondary)',
                    }}>
                      {label}
                    </span>
                  )}
                </div>
              </NavLink>
            )
          })}
        </nav>

        {/* Alert count + collapse toggle */}
        <div style={{
          borderTop: '1px solid var(--border-color)',
          padding: '12px',
        }}>
          {criticalCount > 0 && !sidebarCollapsed && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 10px',
              background: '#ff333318',
              border: '1px solid #ff333330',
              borderRadius: 2,
              marginBottom: 8,
            }}>
              <AlertTriangle size={13} color="var(--accent-red)" />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--accent-red)' }}>
                {criticalCount} CRITICAL
              </span>
            </div>
          )}
          <button
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            style={{
              width: '100%',
              background: 'none',
              border: '1px solid var(--border-color)',
              borderRadius: 2,
              padding: '6px',
              cursor: 'pointer',
              display: 'flex',
              justifyContent: 'center',
            }}
          >
            <ChevronRight
              size={14}
              color="var(--text-dim)"
              style={{ transform: sidebarCollapsed ? 'rotate(0deg)' : 'rotate(180deg)', transition: 'transform 0.2s' }}
            />
          </button>
        </div>
      </aside>

      {/* ── Main Content ─────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* TopBar */}
        <TopBar />

        {/* Page Content */}
        <main style={{
          flex: 1,
          overflow: 'auto',
          padding: '20px',
          background: 'var(--bg-primary)',
        }}>
          <Outlet />
        </main>

        {/* Status Bar */}
        <StatusBar />
      </div>
    </div>
  )
}

function TopBar() {
  const now = new Date()
  return (
    <header style={{
      height: 44,
      background: 'var(--bg-secondary)',
      borderBottom: '1px solid var(--border-color)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 20px',
      gap: 16,
      flexShrink: 0,
    }}>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        <Zap size={12} color="var(--accent-green)" />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-dim)' }}>
          {now.toUTCString().replace('GMT', 'UTC')}
        </span>
      </div>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 6,
        padding: '4px 10px',
        background: 'var(--accent-dim)',
        border: '1px solid var(--border-accent)',
        borderRadius: 2,
      }}>
        <div className="status-dot active" />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--accent-green)' }}>
          PLATFORM OPERATIONAL
        </span>
      </div>
    </header>
  )
}

function StatusBar() {
  return (
    <footer style={{
      height: 28,
      background: 'var(--bg-secondary)',
      borderTop: '1px solid var(--border-color)',
      display: 'flex',
      alignItems: 'center',
      padding: '0 16px',
      gap: 24,
      flexShrink: 0,
    }}>
      {[
        { label: 'PANEL', status: 'READY' },
        { label: 'SPIDERS', status: '8/8' },
        { label: 'DRIVE', status: 'SYNC' },
        { label: 'NLP', status: 'LOADED' },
      ].map(({ label, status }) => (
        <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', letterSpacing: '0.08em' }}>
            {label}
          </span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--accent-green)', letterSpacing: '0.08em' }}>
            {status}
          </span>
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>
        SOLACE v1.0.0 // TLP:WHITE
      </span>
    </footer>
  )
}
