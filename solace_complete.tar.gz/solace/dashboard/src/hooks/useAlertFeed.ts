// ═══════════════════════════════════════════════════════════════
// useAlertFeed hook
// ═══════════════════════════════════════════════════════════════
import { useState, useEffect } from 'react'

export interface Alert {
  alert_id: string
  title: string
  body: string
  classification: string
  created_at: string
}

export function useAlertFeed() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  // In production: subscribe to WebSocket alert feed
  // For now: empty — alerts populate via comms bots
  return { alerts }
}
