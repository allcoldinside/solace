// ═══════════════════════════════════════════════════════════════
// SOLACE Dashboard — API Client
// ═══════════════════════════════════════════════════════════════

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options?.headers },
    ...options,
  })
  if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`)
  return res.json()
}

export const apiClient = {
  // Reports
  getReports: (page = 1, pageSize = 20, params: Record<string, string> = {}) => {
    const qs = new URLSearchParams({ page: String(page), page_size: String(pageSize), ...params })
    return request<any>(`/api/reports?${qs}`)
  },
  getReport: (reportId: string) => request<any>(`/api/reports/${reportId}`),
  searchReports: (q: string) => request<any>(`/api/reports/search?q=${encodeURIComponent(q)}`),

  // Collections
  triggerCollection: (target: string, targetType: string) =>
    request<any>('/api/collections', {
      method: 'POST',
      body: JSON.stringify({ target, target_type: targetType, requestor: 'dashboard' }),
    }),
  getCollectionStatus: (taskId: string) => request<any>(`/api/collections/${taskId}`),

  // Panel
  startPanelSession: (params: { topic: string; target: string; max_rounds: number; report_id?: string }) =>
    request<any>('/api/panel', {
      method: 'POST',
      body: JSON.stringify({
        topic: params.topic,
        target: params.target,
        max_rounds: params.max_rounds,
        report_id: params.report_id || null,
      }),
    }),
  getPanelSession: (sessionId: string) => request<any>(`/api/panel/${sessionId}`),

  // Entities
  getEntities: (entityType?: string) => {
    const qs = entityType ? `?entity_type=${entityType}` : ''
    return request<any>(`/api/entities${qs}`)
  },

  // Health
  health: () => request<any>('/api/health'),
}
