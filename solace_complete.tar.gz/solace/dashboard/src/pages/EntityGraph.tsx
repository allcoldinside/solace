// EntityGraph.tsx — Entity relationship visualization
import React, { useEffect, useState } from 'react'
import { Share2 } from 'lucide-react'
import { apiClient } from '../api/client'

export default function EntityGraph() {
  const [entities, setEntities] = useState<any[]>([])
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    apiClient.getEntities().then(d => setEntities(d?.entities || [])).catch(() => {})
  }, [])

  const types = ['all', 'person', 'organization', 'infrastructure', 'event', 'threat_actor']
  const filtered = filter === 'all' ? entities : entities.filter(e => e.entity_type === filter)

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.25rem', letterSpacing: '0.1em', color: 'var(--accent-green)' }}>
          ENTITY REGISTRY
        </h1>
        <div style={{ display: 'flex', gap: 6 }}>
          {types.map(t => (
            <button key={t} onClick={() => setFilter(t)} style={{
              background: filter === t ? '#00ff8818' : 'none',
              border: `1px solid ${filter === t ? 'var(--accent-green)' : 'var(--border-color)'}`,
              borderRadius: 2, padding: '5px 10px', cursor: 'pointer',
              color: filter === t ? 'var(--accent-green)' : 'var(--text-dim)',
              fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.06em',
            }}>{t.toUpperCase()}</button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: 60, gap: 12 }}>
          <Share2 size={32} color="var(--text-dim)" />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-dim)' }}>
            NO ENTITIES IN REGISTRY
          </span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-dim)' }}>
            Run OSINT collections to populate the entity graph
          </span>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 10 }}>
          {filtered.map(entity => (
            <div key={entity.id} className="card fade-in" style={{ padding: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--accent-amber)' }}>
                  {entity.entity_type?.toUpperCase()}
                </span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: entity.confidence >= 0.7 ? 'var(--accent-green)' : 'var(--text-dim)' }}>
                  {(entity.confidence * 100).toFixed(0)}%
                </span>
              </div>
              <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)', marginBottom: 4 }}>
                {entity.name}
              </div>
              {entity.aliases?.length > 0 && (
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', marginBottom: 6 }}>
                  AKA: {entity.aliases.slice(0, 3).join(', ')}
                </div>
              )}
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>
                First seen: {new Date(entity.first_seen).toLocaleDateString()}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
