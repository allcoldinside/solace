// ReportViewer.tsx
import React, { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Brain, Download, ExternalLink } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import { apiClient } from '../api/client'

export default function ReportViewer() {
  const { reportId } = useParams()
  const navigate = useNavigate()
  const [report, setReport] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState<'summary' | 'full'>('summary')

  useEffect(() => {
    if (!reportId) return
    apiClient.getReport(reportId).then(setReport).finally(() => setLoading(false))
  }, [reportId])

  if (loading) return (
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem', color: 'var(--text-dim)', padding: 40 }}>
      LOADING REPORT...
    </div>
  )
  if (!report) return (
    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem', color: 'var(--accent-red)', padding: 40 }}>
      REPORT NOT FOUND: {reportId}
    </div>
  )

  const CONF_COLOR = report.confidence === 'HIGH' ? 'var(--accent-green)' : report.confidence === 'MEDIUM' ? 'var(--accent-amber)' : 'var(--text-dim)'

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 1200, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-dim)', padding: 4 }}>
          <ArrowLeft size={18} />
        </button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--accent-green)', marginBottom: 4 }}>
            {report.report_id}
          </div>
          <h1 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.5rem', color: 'var(--text-primary)' }}>
            {report.subject}
          </h1>
          <div style={{ display: 'flex', gap: 10, marginTop: 6, flexWrap: 'wrap', alignItems: 'center' }}>
            {[
              { label: report.classification },
              { label: `${report.subject_type?.toUpperCase()}` },
              { label: `CONFIDENCE: ${report.confidence}`, color: CONF_COLOR },
            ].map(({ label, color }) => (
              <span key={label} style={{
                fontFamily: 'var(--font-mono)', fontSize: '0.65rem',
                color: color || 'var(--text-dim)',
                padding: '2px 8px', border: '1px solid var(--border-color)', borderRadius: 1,
              }}>{label}</span>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button
            onClick={() => navigate(`/panel?report_id=${report.report_id}`)}
            style={{
              background: '#00ff8818', border: '1px solid var(--accent-green)',
              borderRadius: 2, padding: '7px 14px', cursor: 'pointer',
              color: 'var(--accent-green)', fontFamily: 'var(--font-mono)', fontSize: '0.7rem',
              display: 'flex', alignItems: 'center', gap: 6,
            }}
          >
            <Brain size={13} /> PANEL ANALYSIS
          </button>
          {report.google_drive_file_id && (
            <a
              href={`https://docs.google.com/document/d/${report.google_drive_file_id}`}
              target="_blank" rel="noreferrer"
              style={{
                background: 'none', border: '1px solid var(--border-color)',
                borderRadius: 2, padding: '7px 12px', cursor: 'pointer',
                color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', fontSize: '0.7rem',
                display: 'flex', alignItems: 'center', gap: 6, textDecoration: 'none',
              }}
            >
              <ExternalLink size={13} /> DRIVE
            </a>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 0, borderBottom: '1px solid var(--border-color)' }}>
        {(['summary', 'full'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              padding: '8px 20px',
              fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.75rem', letterSpacing: '0.08em',
              color: activeTab === tab ? 'var(--accent-green)' : 'var(--text-dim)',
              borderBottom: activeTab === tab ? '2px solid var(--accent-green)' : '2px solid transparent',
              marginBottom: -1,
            }}
          >
            {tab === 'summary' ? 'STRUCTURED VIEW' : 'FULL REPORT'}
          </button>
        ))}
      </div>

      {/* Content */}
      {activeTab === 'summary' ? (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {/* Executive Summary */}
          <div className="card" style={{ padding: 16, gridColumn: '1 / -1' }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 10 }}>EXECUTIVE SUMMARY</div>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '0.875rem', color: 'var(--text-secondary)', lineHeight: 1.7 }}>{report.executive_summary}</p>
          </div>

          {/* Key Findings */}
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 10 }}>KEY FINDINGS</div>
            {report.key_findings && Object.values(report.key_findings).length > 0 ? (
              (Array.isArray(report.key_findings) ? report.key_findings : Object.values(report.key_findings)).map((f: any, i: number) => (
                <div key={i} style={{ marginBottom: 10, paddingLeft: 12, borderLeft: '2px solid var(--accent-green)' }}>
                  <div style={{ fontFamily: 'var(--font-ui)', fontSize: '0.8rem', color: 'var(--text-primary)', marginBottom: 2 }}>{f.finding || f}</div>
                  {f.confidence && <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: f.confidence === 'HIGH' ? 'var(--accent-green)' : 'var(--accent-amber)' }}>{f.confidence}</span>}
                </div>
              ))
            ) : <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-dim)' }}>No findings extracted</div>}
          </div>

          {/* Entity Map */}
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 10 }}>ENTITY MAP</div>
            {report.entity_map && Object.entries(report.entity_map).map(([type, entities]: [string, any]) => (
              entities?.length > 0 && (
                <div key={type} style={{ marginBottom: 10 }}>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--accent-amber)', marginBottom: 4, letterSpacing: '0.08em' }}>{type.toUpperCase()}</div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                    {entities.slice(0, 10).map((e: string) => (
                      <span key={e} style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-secondary)', background: 'var(--bg-secondary)', padding: '2px 6px', borderRadius: 1 }}>{e}</span>
                    ))}
                  </div>
                </div>
              )
            ))}
          </div>

          {/* Threat Assessment */}
          {report.threat_assessment?.level && (
            <div className={`card card-${report.threat_assessment.level === 'CRITICAL' || report.threat_assessment.level === 'HIGH' ? 'red' : 'amber'}`} style={{ padding: 16, gridColumn: '1 / -1' }}>
              <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 8 }}>THREAT ASSESSMENT</div>
              <div style={{ display: 'flex', gap: 20, alignItems: 'center' }}>
                <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.5rem', color: report.threat_assessment.level === 'LOW' ? 'var(--accent-green)' : report.threat_assessment.level === 'MEDIUM' ? 'var(--accent-amber)' : 'var(--accent-red)' }}>
                  {report.threat_assessment.level}
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontSize: '0.8rem', color: 'var(--text-secondary)' }}>
                  {report.threat_assessment.summary}
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="card report-content" style={{ padding: 24 }}>
          <ReactMarkdown>{report.full_markdown || '_No full report content._'}</ReactMarkdown>
        </div>
      )}
    </div>
  )
}
