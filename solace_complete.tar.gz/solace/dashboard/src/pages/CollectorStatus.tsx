// CollectorStatus.tsx
import React from 'react'
import { Radio, Activity } from 'lucide-react'

const BOTS = [
  { id: 'SPIDER-1', name: 'Web & News Collector',       sources: ['Google News RSS', 'DuckDuckGo', 'Article Extraction'], status: 'active',  reliability: 0.75 },
  { id: 'SPIDER-2', name: 'Social & Forums',             sources: ['Reddit', 'HackerNews', 'Nitter/Twitter'],              status: 'active',  reliability: 0.65 },
  { id: 'SPIDER-3', name: 'Network & DNS Intel',          sources: ['WHOIS', 'DNS Records', 'Shodan', 'Censys'],            status: 'active',  reliability: 0.92 },
  { id: 'SPIDER-4', name: 'Dark Web Monitor',             sources: ['Tor Onion Sites'],                                      status: 'standby', reliability: 0.40 },
  { id: 'SPIDER-5', name: 'Corporate & Financial',        sources: ['OpenCorporates', 'SEC EDGAR', 'OpenSanctions'],         status: 'active',  reliability: 0.92 },
  { id: 'SPIDER-6', name: 'Geo & Satellite Intel',        sources: ['OpenStreetMap/Overpass', 'MaxMind GeoIP'],              status: 'active',  reliability: 0.80 },
  { id: 'SPIDER-7', name: 'Document & Leak Harvest',      sources: ['CISA Advisories', 'Semantic Scholar', 'PyMuPDF'],       status: 'active',  reliability: 0.80 },
  { id: 'SPIDER-8', name: 'Threat Feed Aggregator',       sources: ['OTX AlienVault', 'VirusTotal', 'GreyNoise', 'Abuse.ch'],status: 'active',  reliability: 0.88 },
]

const STATUS_COLOR: Record<string, string> = {
  active: 'var(--accent-green)',
  standby: 'var(--accent-amber)',
  offline: 'var(--text-dim)',
}

export default function CollectorStatus() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.25rem', letterSpacing: '0.1em', color: 'var(--accent-green)' }}>
          BOT TEAM STATUS
        </h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div className="status-dot active" />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--accent-green)' }}>
            {BOTS.filter(b => b.status === 'active').length}/{BOTS.length} ACTIVE
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: 12 }}>
        {BOTS.map(bot => (
          <div key={bot.id} className={`card ${bot.status === 'active' ? '' : 'card-amber'}`} style={{ padding: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: STATUS_COLOR[bot.status], fontWeight: 600 }}>
                  {bot.id}
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.9rem', color: 'var(--text-primary)', marginTop: 2 }}>
                  {bot.name}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <div className={`status-dot ${bot.status}`} />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: STATUS_COLOR[bot.status] }}>
                  {bot.status.toUpperCase()}
                </span>
              </div>
            </div>

            <div style={{ marginBottom: 10 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', marginBottom: 6, letterSpacing: '0.06em' }}>
                DATA SOURCES
              </div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                {bot.sources.map(s => (
                  <span key={s} style={{
                    fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-secondary)',
                    background: 'var(--bg-secondary)', padding: '2px 6px', borderRadius: 1,
                  }}>{s}</span>
                ))}
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>
                RELIABILITY
              </div>
              <div style={{ flex: 1, height: 4, background: 'var(--bg-secondary)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${bot.reliability * 100}%`,
                  background: bot.reliability >= 0.8 ? 'var(--accent-green)' : bot.reliability >= 0.6 ? 'var(--accent-amber)' : 'var(--accent-red)',
                  borderRadius: 2,
                }} />
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-secondary)', width: 36 }}>
                {(bot.reliability * 100).toFixed(0)}%
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
