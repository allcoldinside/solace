import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Radio, FileText, Brain, AlertTriangle,
  TrendingUp, Clock, Database, Zap
} from 'lucide-react'
import { apiClient } from '../api/client'

const BOT_TEAM = [
  { id: 'SPIDER-1', label: 'Web/News',    status: 'active'  },
  { id: 'SPIDER-2', label: 'Social',      status: 'active'  },
  { id: 'SPIDER-3', label: 'Network',     status: 'active'  },
  { id: 'SPIDER-4', label: 'Dark Web',    status: 'standby' },
  { id: 'SPIDER-5', label: 'Corporate',   status: 'active'  },
  { id: 'SPIDER-6', label: 'Geo/Sat',     status: 'active'  },
  { id: 'SPIDER-7', label: 'Documents',   status: 'active'  },
  { id: 'SPIDER-8', label: 'Threat Feeds',status: 'active'  },
]

const CLASSIFICATION_COLOR: Record<string, string> = {
  'TLP:WHITE': 'var(--text-secondary)',
  'TLP:GREEN': 'var(--accent-green)',
  'TLP:AMBER': 'var(--accent-amber)',
  'TLP:RED':   'var(--accent-red)',
}

interface Report {
  report_id: string
  subject: string
  classification: string
  confidence: string
  executive_summary: string
  created_at: string
  tags: string[]
}

interface CollectionForm {
  target: string
  target_type: string
}

export default function HQOverview() {
  const navigate = useNavigate()
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState<CollectionForm>({ target: '', target_type: 'organization' })
  const [taskStatus, setTaskStatus] = useState<string | null>(null)
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  useEffect(() => {
    apiClient.getReports(1, 6).then(data => {
      if (data?.items) setReports(data.items)
    }).catch(() => {})
  }, [])

  const triggerCollection = async () => {
    if (!form.target.trim()) return
    setLoading(true)
    setTaskStatus('Deploying bot team...')
    try {
      const result = await apiClient.triggerCollection(form.target, form.target_type)
      setTaskStatus(`Task queued: ${result.task_id} — Bot team deployed`)
      setForm({ target: '', target_type: 'organization' })
    } catch (e) {
      setTaskStatus('Error dispatching task')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ display: 'grid', gap: 16 }}>

      {/* ── Header ─────────────────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{
            fontFamily: 'var(--font-ui)', fontWeight: 700,
            fontSize: '1.5rem', letterSpacing: '0.1em',
            color: 'var(--accent-green)',
          }}>
            SOLACE // HQ OVERVIEW
          </h1>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-dim)', marginTop: 4 }}>
            {time.toUTCString().replace('GMT', 'UTC')} // PLATFORM OPERATIONAL
          </div>
        </div>
      </div>

      {/* ── Stat Tiles ──────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12 }}>
        {[
          { icon: FileText,   label: 'REPORTS',       value: reports.length.toString(), color: 'var(--accent-green)' },
          { icon: Brain,      label: 'PANEL SESSIONS', value: '—',                      color: 'var(--accent-blue)'  },
          { icon: Database,   label: 'ENTITIES',       value: '—',                      color: 'var(--accent-amber)' },
          { icon: AlertTriangle, label: 'ALERTS',     value: '0',                       color: 'var(--accent-red)'  },
        ].map(({ icon: Icon, label, value, color }) => (
          <div key={label} className="card" style={{ padding: '16px 20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', letterSpacing: '0.1em' }}>
                  {label}
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.75rem', color, marginTop: 4 }}>
                  {value}
                </div>
              </div>
              <Icon size={18} color={color} style={{ opacity: 0.6 }} />
            </div>
          </div>
        ))}
      </div>

      {/* ── Main Grid ───────────────────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16 }}>

        {/* Recent Reports */}
        <div className="card" style={{ padding: '16px' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            marginBottom: 12, paddingBottom: 10,
            borderBottom: '1px solid var(--border-color)',
          }}>
            <span style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--text-secondary)' }}>
              RECENT INTELLIGENCE REPORTS
            </span>
            <button
              onClick={() => navigate('/reports')}
              style={{ background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--accent-green)' }}
            >
              VIEW ALL →
            </button>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {reports.length === 0 && (
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--text-dim)', padding: '20px 0', textAlign: 'center' }}>
                NO REPORTS YET. TRIGGER A COLLECTION TO BEGIN.
              </div>
            )}
            {reports.map(report => (
              <div
                key={report.report_id}
                onClick={() => navigate(`/reports/${report.report_id}`)}
                className="fade-in"
                style={{
                  padding: '10px 12px',
                  background: 'var(--bg-elevated)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 2,
                  cursor: 'pointer',
                  transition: 'border-color 0.15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--accent-green)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border-color)')}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--accent-green)' }}>
                    {report.report_id}
                  </span>
                  <span style={{
                    fontFamily: 'var(--font-mono)', fontSize: '0.6rem',
                    color: CLASSIFICATION_COLOR[report.classification] || 'var(--text-dim)',
                    padding: '1px 6px',
                    background: `${CLASSIFICATION_COLOR[report.classification]}18`,
                    borderRadius: 1,
                  }}>
                    {report.classification}
                  </span>
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.875rem', color: 'var(--text-primary)', marginBottom: 4 }}>
                  {report.subject}
                </div>
                <div style={{ fontFamily: 'var(--font-ui)', fontSize: '0.75rem', color: 'var(--text-dim)', lineHeight: 1.4 }}>
                  {report.executive_summary?.slice(0, 120)}...
                </div>
                <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                  {report.tags?.slice(0, 3).map(tag => (
                    <span key={tag} style={{
                      fontFamily: 'var(--font-mono)', fontSize: '0.55rem',
                      color: 'var(--text-dim)', background: 'var(--bg-secondary)',
                      padding: '1px 5px', borderRadius: 1,
                    }}>{tag}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Trigger Collection */}
          <div className="card" style={{ padding: '16px' }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 12 }}>
              DISPATCH COLLECTION
            </div>

            <input
              type="text"
              value={form.target}
              onChange={e => setForm(f => ({ ...f, target: e.target.value }))}
              placeholder="Target subject..."
              onKeyDown={e => e.key === 'Enter' && triggerCollection()}
              style={{
                width: '100%', background: 'var(--bg-secondary)',
                border: '1px solid var(--border-color)', borderRadius: 2,
                padding: '8px 10px', color: 'var(--text-primary)',
                fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
                marginBottom: 8, outline: 'none',
              }}
            />

            <select
              value={form.target_type}
              onChange={e => setForm(f => ({ ...f, target_type: e.target.value }))}
              style={{
                width: '100%', background: 'var(--bg-secondary)',
                border: '1px solid var(--border-color)', borderRadius: 2,
                padding: '8px 10px', color: 'var(--text-secondary)',
                fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
                marginBottom: 10, cursor: 'pointer',
              }}
            >
              <option value="organization">ORGANIZATION</option>
              <option value="person">PERSON</option>
              <option value="infrastructure">INFRASTRUCTURE</option>
              <option value="event">EVENT</option>
              <option value="threat_actor">THREAT ACTOR</option>
            </select>

            <button
              onClick={triggerCollection}
              disabled={loading || !form.target.trim()}
              style={{
                width: '100%', padding: '9px',
                background: loading ? 'var(--accent-dim)' : '#00ff8818',
                border: '1px solid var(--accent-green)',
                borderRadius: 2, cursor: loading ? 'not-allowed' : 'pointer',
                color: 'var(--accent-green)',
                fontFamily: 'var(--font-ui)', fontWeight: 700,
                fontSize: '0.75rem', letterSpacing: '0.1em',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              <Zap size={13} />
              {loading ? 'DEPLOYING...' : 'DEPLOY BOT TEAM'}
            </button>

            {taskStatus && (
              <div style={{
                marginTop: 8, padding: '6px 8px',
                background: 'var(--bg-secondary)', borderRadius: 2,
                fontFamily: 'var(--font-mono)', fontSize: '0.65rem',
                color: 'var(--accent-green)',
              }}>
                {taskStatus}
              </div>
            )}
          </div>

          {/* Bot Team Status */}
          <div className="card" style={{ padding: '16px' }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 10 }}>
              BOT TEAM STATUS
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {BOT_TEAM.map(bot => (
                <div key={bot.id} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div className={`status-dot ${bot.status}`} />
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--accent-green)', width: 72 }}>
                    {bot.id}
                  </span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-dim)', flex: 1 }}>
                    {bot.label}
                  </span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: bot.status === 'active' ? 'var(--accent-green)' : 'var(--accent-amber)' }}>
                    {bot.status.toUpperCase()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
