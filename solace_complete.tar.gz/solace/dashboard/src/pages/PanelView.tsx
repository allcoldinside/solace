import React, { useState, useEffect, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { Brain, Play, AlertCircle, ChevronDown, ChevronUp, Zap } from 'lucide-react'
import { apiClient } from '../api/client'

interface PanelTurn {
  turn_id: string
  round_number: number
  analyst: string
  content: string
  is_loop_flagged: boolean
  timestamp: string
}

const ANALYST_CONFIG: Record<string, { label: string; color: string; border: string; role: string }> = {
  'ANALYST-ALPHA': {
    label: 'ANALYST-ALPHA',
    color: 'var(--accent-green)',
    border: '#00ff8830',
    role: 'Claude · OSINT + Behavioral',
  },
  'ANALYST-BRAVO': {
    label: 'ANALYST-BRAVO',
    color: 'var(--accent-blue)',
    border: '#0088ff30',
    role: 'ChatGPT · OSINT + Patterns',
  },
  'SESSION-DIRECTOR': {
    label: 'SESSION DIRECTOR',
    color: 'var(--accent-amber)',
    border: '#ffaa0030',
    role: 'Gemini · Manager + Synthesizer',
  },
}

function TurnCard({ turn }: { turn: PanelTurn }) {
  const cfg = ANALYST_CONFIG[turn.analyst] || ANALYST_CONFIG['SESSION-DIRECTOR']
  const [expanded, setExpanded] = useState(true)

  return (
    <div
      className="fade-in"
      style={{
        border: `1px solid ${cfg.border}`,
        borderLeft: `3px solid ${cfg.color}`,
        background: 'var(--bg-card)',
        borderRadius: 2,
        overflow: 'hidden',
      }}
    >
      {/* Header */}
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: '8px 14px',
          background: `${cfg.color}08`,
          cursor: 'pointer',
          borderBottom: expanded ? `1px solid ${cfg.border}` : 'none',
        }}
      >
        <div style={{ width: 8, height: 8, borderRadius: '50%', background: cfg.color, flexShrink: 0 }} />
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: cfg.color, fontWeight: 600 }}>
          {cfg.label}
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>
          {cfg.role}
        </span>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', marginLeft: 'auto' }}>
          Round {turn.round_number}
        </span>
        {turn.is_loop_flagged && (
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.55rem',
            color: 'var(--accent-amber)', background: '#ffaa0018',
            padding: '1px 5px', borderRadius: 1,
          }}>
            LOOP FLAGGED
          </span>
        )}
        {expanded ? <ChevronUp size={12} color="var(--text-dim)" /> : <ChevronDown size={12} color="var(--text-dim)" />}
      </div>

      {/* Content */}
      {expanded && (
        <div style={{ padding: '14px 16px' }}>
          <pre style={{
            fontFamily: 'var(--font-ui)',
            fontSize: '0.825rem',
            color: 'var(--text-secondary)',
            lineHeight: 1.7,
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            margin: 0,
          }}>
            {turn.content}
          </pre>
        </div>
      )}
    </div>
  )
}

export default function PanelView() {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const scrollRef = useRef<HTMLDivElement>(null)
  const wsRef = useRef<WebSocket | null>(null)

  const [turns, setTurns] = useState<PanelTurn[]>([])
  const [session, setSession] = useState<any>(null)
  const [status, setStatus] = useState<string>('idle')
  const [currentRound, setCurrentRound] = useState(0)
  const [synthesis, setSynthesis] = useState<string>('')
  const [form, setForm] = useState({ topic: '', target: '', max_rounds: 6, report_id: '' })
  const [loading, setLoading] = useState(false)
  const [liveSessionId, setLiveSessionId] = useState<string | null>(sessionId || null)

  // Load existing session
  useEffect(() => {
    if (sessionId) {
      apiClient.getPanelSession(sessionId).then(data => {
        setSession(data)
        setTurns(data.transcript || [])
        setSynthesis(data.final_synthesis || '')
        setStatus(data.concluded ? 'complete' : 'active')
      }).catch(() => {})
    }
  }, [sessionId])

  // Auto-scroll transcript
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [turns])

  const startSession = async () => {
    if (!form.topic.trim() || !form.target.trim()) return
    setLoading(true)
    setTurns([])
    setSynthesis('')
    setStatus('starting')

    try {
      const result = await apiClient.startPanelSession(form)
      setLiveSessionId(result.session_id)
      setStatus('active')

      // Connect WebSocket
      const wsUrl = `ws://localhost:8000/api/panel/${result.session_id}/stream`
      const ws = new WebSocket(wsUrl)
      wsRef.current = ws

      ws.onmessage = (evt) => {
        const event = JSON.parse(evt.data)
        handlePanelEvent(event)
      }

      ws.onerror = () => setStatus('error')
      ws.onclose = () => {
        if (status !== 'complete') setStatus('disconnected')
      }

    } catch (e) {
      setStatus('error')
    } finally {
      setLoading(false)
    }
  }

  const handlePanelEvent = (event: any) => {
    switch (event.type) {
      case 'session_started':
        setStatus('active')
        break
      case 'round_started':
        setCurrentRound(event.round)
        break
      case 'analyst_turn':
      case 'director_turn':
        setTurns(prev => [...prev, {
          turn_id: Date.now().toString(),
          round_number: event.round || 0,
          analyst: event.analyst,
          content: event.content,
          is_loop_flagged: false,
          timestamp: new Date().toISOString(),
        }])
        break
      case 'synthesis_started':
        setStatus('synthesizing')
        break
      case 'session_complete':
        setSynthesis(event.final_synthesis || '')
        setStatus('complete')
        wsRef.current?.close()
        break
    }
  }

  useEffect(() => {
    return () => { wsRef.current?.close() }
  }, [])

  const statusColors: Record<string, string> = {
    idle: 'var(--text-dim)',
    starting: 'var(--accent-amber)',
    active: 'var(--accent-green)',
    synthesizing: 'var(--accent-blue)',
    complete: 'var(--accent-green)',
    error: 'var(--accent-red)',
    disconnected: 'var(--accent-amber)',
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16, height: '100%' }}>

      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.25rem', letterSpacing: '0.1em', color: 'var(--accent-green)' }}>
            PANEL ENGINE
          </h1>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-dim)', marginTop: 2 }}>
            3-AI ANALYST PANEL // CLAUDE · CHATGPT · GEMINI
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: statusColors[status] }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: statusColors[status] }}>
            {status.toUpperCase()}
            {status === 'active' && currentRound > 0 && ` // ROUND ${currentRound}`}
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr', gap: 16, flex: 1, minHeight: 0 }}>

        {/* Session Config */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="card" style={{ padding: 16 }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 12 }}>
              SESSION PARAMETERS
            </div>

            {[
              { key: 'target', placeholder: 'Intelligence target...', label: 'TARGET' },
              { key: 'topic', placeholder: 'Analytical topic / objective...', label: 'TOPIC' },
              { key: 'report_id', placeholder: 'REPORT-YYYYMMDD-... (optional)', label: 'REPORT ID' },
            ].map(({ key, placeholder, label }) => (
              <div key={key} style={{ marginBottom: 10 }}>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', marginBottom: 4, letterSpacing: '0.08em' }}>
                  {label}
                </div>
                <input
                  type="text"
                  value={(form as any)[key]}
                  onChange={e => setForm(f => ({ ...f, [key]: e.target.value }))}
                  placeholder={placeholder}
                  style={{
                    width: '100%', background: 'var(--bg-secondary)',
                    border: '1px solid var(--border-color)', borderRadius: 2,
                    padding: '7px 10px', color: 'var(--text-primary)',
                    fontFamily: 'var(--font-mono)', fontSize: '0.75rem', outline: 'none',
                  }}
                />
              </div>
            ))}

            <div style={{ marginBottom: 12 }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)', marginBottom: 4, letterSpacing: '0.08em' }}>
                MAX ROUNDS: {form.max_rounds}
              </div>
              <input
                type="range" min={2} max={10} value={form.max_rounds}
                onChange={e => setForm(f => ({ ...f, max_rounds: parseInt(e.target.value) }))}
                style={{ width: '100%', accentColor: 'var(--accent-green)' }}
              />
            </div>

            <button
              onClick={startSession}
              disabled={loading || status === 'active' || !form.topic.trim() || !form.target.trim()}
              style={{
                width: '100%', padding: '10px',
                background: (loading || status === 'active') ? 'var(--accent-dim)' : '#00ff8818',
                border: '1px solid var(--accent-green)', borderRadius: 2,
                cursor: (loading || status === 'active') ? 'not-allowed' : 'pointer',
                color: 'var(--accent-green)',
                fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.1em',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              }}
            >
              <Brain size={14} />
              {loading ? 'CONVENING PANEL...' : 'CONVENE PANEL'}
            </button>
          </div>

          {/* Analyst Legend */}
          <div className="card" style={{ padding: 14 }}>
            <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, fontSize: '0.7rem', letterSpacing: '0.1em', color: 'var(--text-secondary)', marginBottom: 10 }}>
              PANEL COMPOSITION
            </div>
            {Object.entries(ANALYST_CONFIG).map(([id, cfg]) => (
              <div key={id} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: cfg.color, flexShrink: 0 }} />
                <div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: cfg.color }}>{cfg.label}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>{cfg.role}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Transcript */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, minHeight: 0 }}>
          <div
            ref={scrollRef}
            className="scroll-area"
            style={{
              flex: 1,
              display: 'flex', flexDirection: 'column', gap: 10,
              padding: 4,
              minHeight: 0,
            }}
          >
            {turns.length === 0 && (
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                height: '100%', flexDirection: 'column', gap: 12,
              }}>
                <Brain size={32} color="var(--text-dim)" />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-dim)' }}>
                  AWAITING PANEL SESSION
                </span>
              </div>
            )}
            {turns.map((turn, i) => <TurnCard key={turn.turn_id || i} turn={turn} />)}
          </div>

          {/* Final Synthesis */}
          {synthesis && (
            <div className="card card-blue" style={{ padding: 16, maxHeight: 300, overflow: 'auto' }}>
              <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--accent-blue)', marginBottom: 10 }}>
                ▸ FINAL INTELLIGENCE ASSESSMENT
              </div>
              <pre style={{
                fontFamily: 'var(--font-ui)', fontSize: '0.8rem',
                color: 'var(--text-secondary)', lineHeight: 1.7,
                whiteSpace: 'pre-wrap', wordBreak: 'break-word',
              }}>
                {synthesis}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
