// ═══════════════════════════════════════════════════════════════
// Reports Browser Page
// ═══════════════════════════════════════════════════════════════
import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, FileText, Filter } from 'lucide-react'
import { apiClient } from '../api/client'

const CLASSIFICATION_COLOR: Record<string, string> = {
  'TLP:WHITE': '#888',
  'TLP:GREEN': 'var(--accent-green)',
  'TLP:AMBER': 'var(--accent-amber)',
  'TLP:RED':   'var(--accent-red)',
}

export default function ReportsBrowser() {
  const navigate = useNavigate()
  const [reports, setReports] = useState<any[]>([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => { loadReports() }, [])

  const loadReports = async () => {
    setLoading(true)
    try {
      const data = await apiClient.getReports(1, 50)
      setReports(data?.items || [])
    } finally { setLoading(false) }
  }

  const search = async () => {
    if (!query.trim()) { loadReports(); return }
    setLoading(true)
    try {
      const data = await apiClient.searchReports(query)
      setReports(data?.results || [])
    } finally { setLoading(false) }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1.25rem', letterSpacing: '0.1em', color: 'var(--accent-green)' }}>
          INTELLIGENCE REPORTS
        </h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            value={query} onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && search()}
            placeholder="Semantic search..."
            style={{
              background: 'var(--bg-secondary)', border: '1px solid var(--border-color)',
              borderRadius: 2, padding: '7px 12px', color: 'var(--text-primary)',
              fontFamily: 'var(--font-mono)', fontSize: '0.75rem', outline: 'none', width: 260,
            }}
          />
          <button onClick={search} style={{
            background: '#00ff8818', border: '1px solid var(--accent-green)',
            borderRadius: 2, padding: '7px 14px', cursor: 'pointer',
            color: 'var(--accent-green)', fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <Search size={13} /> SEARCH
          </button>
        </div>
      </div>

      {loading && (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-dim)', padding: 20 }}>
          LOADING REPORTS...
        </div>
      )}

      <div style={{ display: 'grid', gap: 10 }}>
        {reports.map(r => (
          <div
            key={r.report_id}
            onClick={() => navigate(`/reports/${r.report_id}`)}
            className="card fade-in"
            style={{ padding: '14px 16px', cursor: 'pointer', transition: 'border-color 0.15s' }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--accent-green)')}
            onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--border-color)')}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
              <div>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--accent-green)' }}>
                  {r.report_id}
                </span>
                <h3 style={{ fontFamily: 'var(--font-ui)', fontWeight: 700, fontSize: '1rem', color: 'var(--text-primary)', marginTop: 2 }}>
                  {r.subject}
                </h3>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.6rem',
                  color: CLASSIFICATION_COLOR[r.classification],
                  padding: '2px 8px',
                  border: `1px solid ${CLASSIFICATION_COLOR[r.classification]}44`,
                  borderRadius: 1,
                }}>
                  {r.classification}
                </span>
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)',
                  padding: '2px 8px', border: '1px solid var(--border-color)', borderRadius: 1,
                }}>
                  {r.subject_type?.toUpperCase()}
                </span>
                <span style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.6rem',
                  color: r.confidence === 'HIGH' ? 'var(--accent-green)' : r.confidence === 'MEDIUM' ? 'var(--accent-amber)' : 'var(--text-dim)',
                }}>
                  ● {r.confidence}
                </span>
              </div>
            </div>
            <p style={{ fontFamily: 'var(--font-ui)', fontSize: '0.8rem', color: 'var(--text-dim)', lineHeight: 1.5 }}>
              {r.executive_summary?.slice(0, 200)}...
            </p>
            <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
              {r.tags?.slice(0, 5).map((tag: string) => (
                <span key={tag} style={{
                  fontFamily: 'var(--font-mono)', fontSize: '0.55rem', color: 'var(--text-dim)',
                  background: 'var(--bg-secondary)', padding: '1px 6px', borderRadius: 1,
                }}>
                  {tag}
                </span>
              ))}
              <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.6rem', color: 'var(--text-dim)' }}>
                {new Date(r.created_at).toLocaleDateString()}
              </span>
            </div>
          </div>
        ))}
        {reports.length === 0 && !loading && (
          <div style={{ textAlign: 'center', padding: 40 }}>
            <FileText size={32} color="var(--text-dim)" style={{ margin: '0 auto 12px' }} />
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-dim)' }}>
              NO REPORTS FOUND
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
