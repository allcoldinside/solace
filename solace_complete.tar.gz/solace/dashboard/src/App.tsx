import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout/Layout'
import HQOverview from './pages/HQOverview'
import ReportsBrowser from './pages/ReportsBrowser'
import ReportViewer from './pages/ReportViewer'
import PanelView from './pages/PanelView'
import EntityGraph from './pages/EntityGraph'
import CollectorStatus from './pages/CollectorStatus'
import './styles/globals.css'

export default function App() {
  return (
    <BrowserRouter>
      <div className="scanlines noise" style={{ height: '100vh', display: 'flex', flexDirection: 'column' }}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HQOverview />} />
            <Route path="reports" element={<ReportsBrowser />} />
            <Route path="reports/:reportId" element={<ReportViewer />} />
            <Route path="panel" element={<PanelView />} />
            <Route path="panel/:sessionId" element={<PanelView />} />
            <Route path="entities" element={<EntityGraph />} />
            <Route path="collectors" element={<CollectorStatus />} />
          </Route>
        </Routes>
      </div>
    </BrowserRouter>
  )
}
