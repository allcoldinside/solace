/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'solace-green':  '#00ff88',
        'solace-amber':  '#ffaa00',
        'solace-red':    '#ff3333',
        'solace-blue':   '#0088ff',
        'solace-bg':     '#080a0f',
        'solace-card':   '#0f1723',
        'solace-border': '#1a2535',
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Share Tech Mono', 'monospace'],
        ui:   ['Rajdhani', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
