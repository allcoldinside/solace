"""
SOLACE — NLP Enrichment Pipeline
Runs all HuggingFace models over collected intel items.
Models are lazy-loaded and cached in memory after first use.
"""
from __future__ import annotations

import asyncio
from functools import lru_cache
from typing import Any

from config import get_logger
from core.schemas import EnrichedIntelItem, RawIntelItemSchema

logger = get_logger("nlp_pipeline")


# ── Model Registry ─────────────────────────────────────────────────────────────

@lru_cache(maxsize=1)
def _get_ner_pipeline():
    from transformers import pipeline
    logger.info("loading_model", model="dslim/bert-base-NER")
    return pipeline("ner", model="dslim/bert-base-NER", aggregation_strategy="simple")


@lru_cache(maxsize=1)
def _get_sentiment_pipeline():
    from transformers import pipeline
    logger.info("loading_model", model="cardiffnlp/twitter-roberta-base-sentiment-latest")
    return pipeline("text-classification", model="cardiffnlp/twitter-roberta-base-sentiment-latest")


@lru_cache(maxsize=1)
def _get_keyword_pipeline():
    from transformers import pipeline
    logger.info("loading_model", model="yanekyuk/bert-uncased-keyword-extractor")
    return pipeline("token-classification", model="yanekyuk/bert-uncased-keyword-extractor")


@lru_cache(maxsize=1)
def _get_embedding_model():
    from sentence_transformers import SentenceTransformer
    logger.info("loading_model", model="BAAI/bge-m3")
    return SentenceTransformer("BAAI/bge-m3")


@lru_cache(maxsize=1)
def _get_translator(src_lang: str = "mul"):
    from transformers import pipeline
    model = f"Helsinki-NLP/opus-mt-{src_lang}-en"
    logger.info("loading_model", model=model)
    return pipeline("translation", model=model)


# ── NER ─────────────────────────────────────────────────────────────────────────

def extract_entities(text: str) -> dict[str, list[str]]:
    """Extract named entities from text using BERT NER model.

    Args:
        text: Input text.

    Returns:
        Dict mapping entity type to list of entity strings.
        Keys: PER (person), ORG (organization), LOC (location), MISC.
    """
    try:
        ner = _get_ner_pipeline()
        results = ner(text[:512])  # BERT max tokens
        entities: dict[str, list[str]] = {"PER": [], "ORG": [], "LOC": [], "MISC": []}
        for result in results:
            etype = result["entity_group"].replace("B-", "").replace("I-", "")
            word = result["word"]
            if etype in entities and word not in entities[etype] and len(word) > 1:
                entities[etype].append(word)
        return entities
    except Exception as exc:
        logger.warning("ner_error", error=str(exc))
        return {"PER": [], "ORG": [], "LOC": [], "MISC": []}


# ── Sentiment ───────────────────────────────────────────────────────────────────

def score_sentiment(text: str) -> tuple[float, str]:
    """Score text sentiment using Twitter-RoBERTa model.

    Args:
        text: Input text (up to 512 tokens).

    Returns:
        Tuple of (score: -1.0 to 1.0, label: negative/neutral/positive).
    """
    try:
        classifier = _get_sentiment_pipeline()
        result = classifier(text[:512])[0]
        label = result["label"].lower()
        score = result["score"]
        # Map to -1 to 1 scale
        if "negative" in label:
            return -score, "negative"
        elif "positive" in label:
            return score, "positive"
        else:
            return 0.0, "neutral"
    except Exception as exc:
        logger.warning("sentiment_error", error=str(exc))
        return 0.0, "neutral"


# ── Keywords ────────────────────────────────────────────────────────────────────

def extract_keywords(text: str) -> list[str]:
    """Extract key terms from text.

    Args:
        text: Input text.

    Returns:
        List of extracted keyword strings.
    """
    try:
        pipe = _get_keyword_pipeline()
        results = pipe(text[:512])
        keywords = []
        for r in results:
            word = r["word"].strip()
            if len(word) > 2 and word not in keywords:
                keywords.append(word)
        return keywords[:20]
    except Exception as exc:
        logger.warning("keyword_error", error=str(exc))
        # Fallback: simple TF-based extraction
        return _simple_keyword_fallback(text)


def _simple_keyword_fallback(text: str) -> list[str]:
    """Simple frequency-based keyword extraction as fallback."""
    import re
    from collections import Counter
    STOPWORDS = {
        "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
        "of", "with", "by", "from", "is", "was", "are", "were", "be", "been",
        "have", "has", "had", "do", "does", "did", "will", "would", "could",
        "should", "may", "might", "shall", "can", "that", "this", "it", "its",
        "their", "they", "we", "i", "you", "he", "she", "not", "also", "as",
    }
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    filtered = [w for w in words if w not in STOPWORDS]
    common = Counter(filtered).most_common(15)
    return [w for w, _ in common]


# ── Embeddings ──────────────────────────────────────────────────────────────────

def generate_embedding(text: str) -> list[float]:
    """Generate a 1024-dim embedding vector using BAAI/bge-m3.

    Args:
        text: Input text.

    Returns:
        List of 1024 float values (normalized vector).
    """
    try:
        model = _get_embedding_model()
        embedding = model.encode(text[:2000], normalize_embeddings=True)
        return embedding.tolist()
    except Exception as exc:
        logger.warning("embedding_error", error=str(exc))
        return []


# ── Translation ─────────────────────────────────────────────────────────────────

def translate_to_english(text: str, src_lang: str = "mul") -> str:
    """Translate text to English using Helsinki-NLP models.

    Args:
        text: Source text.
        src_lang: Source language code (default: 'mul' for multilingual).

    Returns:
        Translated English text.
    """
    try:
        translator = _get_translator(src_lang)
        result = translator(text[:1000])
        if result and isinstance(result, list):
            return result[0].get("translation_text", text)
        return text
    except Exception as exc:
        logger.warning("translation_error", src_lang=src_lang, error=str(exc))
        return text


# ── Language Detection ──────────────────────────────────────────────────────────

def detect_language(text: str) -> str:
    """Detect the language of input text.

    Args:
        text: Input text.

    Returns:
        ISO 639-1 language code (e.g., 'en', 'ru', 'zh').
    """
    try:
        from langdetect import detect
        return detect(text[:500])
    except Exception:
        return "en"


# ── Main Pipeline ───────────────────────────────────────────────────────────────

class NLPPipeline:
    """Main NLP enrichment pipeline for SOLACE intel items.

    Applies NER, sentiment, keyword extraction, embedding generation,
    and translation to each raw intel item asynchronously.
    """

    async def enrich(self, raw_items: list[RawIntelItemSchema]) -> list[EnrichedIntelItem]:
        """Enrich a list of raw intel items with NLP analysis.

        Args:
            raw_items: List of raw collected items.

        Returns:
            List of enriched intel items with NLP outputs applied.
        """
        logger.info("nlp_enrichment_started", item_count=len(raw_items))
        loop = asyncio.get_event_loop()
        enriched_items: list[EnrichedIntelItem] = []

        for item in raw_items:
            try:
                enriched = await loop.run_in_executor(None, self._enrich_item, item)
                enriched_items.append(enriched)
            except Exception as exc:
                logger.error("enrichment_failed", error=str(exc), source=item.source_url)
                # Promote to enriched with no NLP — don't lose the data
                enriched_items.append(EnrichedIntelItem(**item.model_dump()))

        logger.info("nlp_enrichment_complete", enriched_count=len(enriched_items))
        return enriched_items

    def _enrich_item(self, item: RawIntelItemSchema) -> EnrichedIntelItem:
        """Synchronous enrichment for a single item (runs in executor).

        Args:
            item: Raw intel item.

        Returns:
            Enriched version with NLP outputs.
        """
        data = item.model_dump()
        content = item.content

        # Detect and translate if non-English
        lang = detect_language(content)
        data["language"] = lang
        if lang != "en":
            try:
                data["content_en"] = translate_to_english(content, lang)
                analysis_text = data["content_en"]
            except Exception:
                analysis_text = content
        else:
            analysis_text = content

        # Run NLP
        data["named_entities"] = extract_entities(analysis_text)
        sentiment_score, sentiment_label = score_sentiment(analysis_text)
        data["sentiment_score"] = sentiment_score
        data["sentiment_label"] = sentiment_label
        data["keywords"] = extract_keywords(analysis_text)
        data["embedding"] = generate_embedding(analysis_text)

        return EnrichedIntelItem(**data)


nlp_pipeline = NLPPipeline()
