"""SOLACE NLP enrichment pipeline."""
from nlp.pipeline import NLPPipeline, nlp_pipeline, generate_embedding, extract_entities

__all__ = ["NLPPipeline", "nlp_pipeline", "generate_embedding", "extract_entities"]
