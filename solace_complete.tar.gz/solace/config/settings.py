"""
SOLACE — Application Configuration
All settings loaded from environment variables via Pydantic BaseSettings.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Central configuration for the SOLACE platform."""

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "case_sensitive": False}

    # ── Application ──────────────────────────────────────────────
    app_name: str = "SOLACE"
    app_version: str = "1.0.0"
    environment: Literal["development", "production", "testing"] = "production"
    debug: bool = False
    secret_key: str = Field(..., min_length=32)
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    base_dir: Path = Path(__file__).parent.parent

    # ── Databases ────────────────────────────────────────────────
    postgres_url: str
    mongodb_url: str
    neo4j_url: str = "bolt://neo4j:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: str
    redis_url: str
    clickhouse_host: str = "clickhouse"
    clickhouse_port: int = 9000
    clickhouse_db: str = "solace"
    clickhouse_user: str = "solace"
    clickhouse_password: str

    # ── MinIO ────────────────────────────────────────────────────
    minio_endpoint: str = "minio:9000"
    minio_access_key: str
    minio_secret_key: str
    minio_bucket: str = "solace-artifacts"

    # ── AI APIs ──────────────────────────────────────────────────
    anthropic_api_key: str
    openai_api_key: str
    google_ai_api_key: str
    huggingface_token: str = ""
    ollama_host: str = "http://ollama:11434"
    ollama_default_model: str = "mistral"

    # ── Google Drive ─────────────────────────────────────────────
    google_drive_credentials_json: Path = Path("/app/credentials/google_service_account.json")
    google_drive_root_folder_id: str = ""
    google_drive_reports_folder_id: str = ""
    google_drive_assessments_folder_id: str = ""
    google_drive_cases_folder_id: str = ""
    google_drive_archive_folder_id: str = ""

    # ── Messaging ────────────────────────────────────────────────
    telegram_api_id: str = ""
    telegram_api_hash: str = ""
    telegram_bot_token: str = ""
    telegram_alert_chat_id: str = ""
    telegram_session_string: str = ""
    discord_bot_token: str = ""
    discord_guild_id: str = ""
    discord_alerts_channel_id: str = ""
    discord_panel_channel_id: str = ""
    signal_cli_config_path: Path = Path("/app/signal-cli-config")
    signal_sender_number: str = ""

    # ── OSINT APIs ───────────────────────────────────────────────
    shodan_api_key: str = ""
    virustotal_api_key: str = ""
    alienvault_otx_api_key: str = ""
    greynoise_api_key: str = ""
    censys_api_id: str = ""
    censys_api_secret: str = ""
    opencorporates_api_key: str = ""
    securitytrails_api_key: str = ""
    binaryedge_api_key: str = ""
    hunter_api_key: str = ""

    # ── Intel Platforms ──────────────────────────────────────────
    misp_url: str = "http://misp"
    misp_api_key: str = ""
    opencti_url: str = "http://opencti:8080"
    opencti_api_key: str = ""
    thehive_url: str = "http://thehive:9000"
    thehive_api_key: str = ""

    # ── Panel Engine ─────────────────────────────────────────────
    max_panel_rounds: int = 6
    loop_detection_threshold: float = 0.65
    default_classification: str = "TLP:WHITE"
    panel_max_tokens: int = 1500

    # ── Tor ──────────────────────────────────────────────────────
    tor_socks_proxy: str = "socks5://tor:9050"

    # ── Celery ───────────────────────────────────────────────────
    celery_broker_url: str = ""
    celery_result_backend: str = ""

    @field_validator("celery_broker_url", mode="before")
    @classmethod
    def set_celery_broker(cls, v: str, info) -> str:
        if not v:
            return info.data.get("redis_url", "redis://redis:6379/0")
        return v

    @field_validator("celery_result_backend", mode="before")
    @classmethod
    def set_celery_backend(cls, v: str, info) -> str:
        if not v:
            return info.data.get("redis_url", "redis://redis:6379/0")
        return v


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached settings instance."""
    return Settings()


settings = get_settings()
