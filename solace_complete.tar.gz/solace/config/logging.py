"""
SOLACE — Structured Logging Configuration
JSON-formatted logs with consistent fields across all components.
"""
from __future__ import annotations

import logging
import sys

import structlog


def configure_logging(log_level: str = "INFO") -> None:
    """Configure structlog for the entire application.

    Args:
        log_level: Logging level string (DEBUG/INFO/WARNING/ERROR).
    """
    shared_processors: list = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        _add_app_context,
    ]

    structlog.configure(
        processors=shared_processors + [structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.JSONRenderer(),
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.addHandler(handler)
    root_logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))

    # Silence noisy libraries
    for noisy in ("urllib3", "httpx", "asyncio", "aiohttp"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def _add_app_context(logger, method_name: str, event_dict: dict) -> dict:
    """Inject SOLACE app context into every log record."""
    event_dict.setdefault("app", "SOLACE")
    event_dict.setdefault("version", "1.0.0")
    return event_dict


def get_logger(component: str, **kwargs) -> structlog.stdlib.BoundLogger:
    """Get a pre-bound logger for a specific component.

    Args:
        component: Component name (e.g., 'SPIDER-1', 'panel_engine').
        **kwargs: Additional context to bind to the logger.

    Returns:
        A bound structlog logger instance.
    """
    return structlog.get_logger(component=component, **kwargs)
