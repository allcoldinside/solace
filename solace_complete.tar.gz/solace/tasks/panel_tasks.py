"""SOLACE — Panel session Celery task."""
from __future__ import annotations

import asyncio
from tasks.celery_app import celery_app
from config import get_logger

logger = get_logger("panel_tasks")


@celery_app.task(bind=True, max_retries=1, name="tasks.panel_tasks.run_panel_session_task")
def run_panel_session_task(
    self,
    session_id: str,
    report_id: str | None,
    topic: str,
    target: str,
    max_rounds: int = 6,
) -> dict:
    """Run a standalone 3-AI panel session task.

    Args:
        session_id: Pre-assigned session ID.
        report_id: Optional linked report ID.
        topic: Analytical topic.
        target: Intelligence target.
        max_rounds: Maximum panel rounds.

    Returns:
        Dict with session results.
    """
    return asyncio.get_event_loop().run_until_complete(
        _run_panel_async(session_id, report_id, topic, target, max_rounds)
    )


async def _run_panel_async(
    session_id: str, report_id: str | None, topic: str, target: str, max_rounds: int
) -> dict:
    from panel.engine import panel_engine
    from core.database import get_db_session
    from core.models import PanelSession as PanelSessionModel, Report

    # Load report content if report_id provided
    report_content = ""
    if report_id:
        async with get_db_session() as db:
            from sqlalchemy import select
            result = await db.execute(
                select(Report).where(
                    (Report.report_id == report_id) | (Report.id == report_id)
                )
            )
            report = result.scalar_one_or_none()
            if report:
                report_content = report.full_markdown

    # Run the panel
    session = await panel_engine.run(
        report_content=report_content or f"Ad-hoc panel analysis of: {target}",
        topic=topic,
        target=target,
        report_id=report_id or "",
        max_rounds=max_rounds,
    )
    session.session_id = session_id  # Override with pre-assigned ID

    # Persist to DB
    async with get_db_session() as db:
        db_session = PanelSessionModel(
            session_id=session.session_id,
            topic=session.topic,
            target=session.target,
            transcript=[t.model_dump() for t in session.history],
            positions=session.positions,
            covered_topics=list(session.covered_topics.keys()),
            disagreements=[d.model_dump() for d in session.disagreements],
            rounds_completed=session.round,
            final_synthesis=session.final_synthesis,
            concluded=session.concluded,
            start_time=session.start_time,
            end_time=session.end_time,
        )
        db.add(db_session)

    logger.info("panel_task_complete", session_id=session_id, rounds=session.round)
    return {
        "session_id": session_id,
        "rounds_completed": session.round,
        "concluded": session.concluded,
        "disagreements": len(session.disagreements),
    }
