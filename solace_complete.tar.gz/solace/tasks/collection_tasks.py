"""
SOLACE — Collection Pipeline Tasks
Full end-to-end OSINT pipeline: spiders → NLP → report → Drive → panel → alerts.
"""
from __future__ import annotations

import asyncio
from datetime import datetime

from tasks.celery_app import celery_app
from config import get_logger

logger = get_logger("collection_tasks")


@celery_app.task(bind=True, max_retries=3, name="tasks.collection_tasks.run_full_osint_pipeline")
def run_full_osint_pipeline(
    self,
    target: str,
    target_type: str,
    requestor: str = "system",
    priority: str = "normal",
) -> dict:
    """Execute the full SOLACE OSINT pipeline for a target.

    Steps:
    1. Deploy all spider bots concurrently
    2. Aggregate + deduplicate
    3. NLP enrichment (NER, sentiment, embeddings, translation)
    4. Generate structured report
    5. Store in all databases
    6. Upload to Google Drive
    7. Embed for semantic search
    8. Run 3-AI panel session
    9. Upload panel assessment
    10. Route notifications

    Args:
        target: Subject to collect intelligence on.
        target_type: Type classification of the target.
        requestor: Who triggered this collection.
        priority: Task priority level.

    Returns:
        Dict with report_id, session_id, and status.
    """
    return asyncio.get_event_loop().run_until_complete(
        _run_pipeline_async(self, target, target_type, requestor, priority)
    )


async def _run_pipeline_async(task, target: str, target_type: str, requestor: str, priority: str) -> dict:
    """Async implementation of the full pipeline."""
    from collectors import aggregator, get_all_spiders
    from nlp.pipeline import nlp_pipeline
    from reports.generator import report_generator
    from storage.google_drive import drive_client
    from storage.pgvector_client import pgvector_client
    from core.schemas import TargetType
    from core.database import get_db_session
    from core.models import Report as ReportModel, CollectionTask, PanelSession as PanelSessionModel

    logger.info("pipeline_started", target=target, target_type=target_type, requestor=requestor)
    collection_started = datetime.utcnow()

    try:
        target_type_enum = TargetType(target_type)
    except ValueError:
        target_type_enum = TargetType.ORGANIZATION

    # ── 1. Deploy Spider Bot Team ─────────────────────────────────────────────
    logger.info("deploying_spider_bots", target=target)
    collectors = get_all_spiders()

    results = await asyncio.gather(
        *[c.collect(target, target_type_enum) for c in collectors],
        return_exceptions=True,
    )

    valid_results = []
    for r in results:
        if isinstance(r, Exception):
            logger.error("spider_failed", error=str(r))
        else:
            valid_results.append(r)

    logger.info("spiders_complete", successful=len(valid_results), total=len(collectors))

    # ── 2. Aggregate ──────────────────────────────────────────────────────────
    raw_items = aggregator.process(valid_results)
    collection_completed = datetime.utcnow()
    logger.info("aggregation_done", items=len(raw_items))

    # ── 3. NLP Enrichment ─────────────────────────────────────────────────────
    enriched_items = await nlp_pipeline.enrich(raw_items)
    logger.info("nlp_enrichment_done", items=len(enriched_items))

    # ── 4. Generate Report ────────────────────────────────────────────────────
    report_data = await report_generator.generate(
        enriched_items=enriched_items,
        target=target,
        target_type=target_type,
        collection_started=collection_started,
        collection_completed=collection_completed,
    )
    logger.info("report_generated", report_id=report_data.report_id)

    # ── 5. Store in PostgreSQL ────────────────────────────────────────────────
    report_dict = report_data.to_dict()
    db_report_id = None

    async with get_db_session() as db_session:
        db_report = ReportModel(**report_dict)
        db_session.add(db_report)
        await db_session.flush()
        db_report_id = str(db_report.id)

    logger.info("report_stored_postgres", db_id=db_report_id)

    # ── 6. Upload to Google Drive ─────────────────────────────────────────────
    drive_file_id = None
    try:
        properties = {
            "report_id": report_data.report_id,
            "subject": report_data.subject,
            "classification": report_data.classification,
            "confidence": report_data.confidence,
            "tags": ",".join(report_data.tags),
        }
        drive_file_id = await drive_client.upload_report(
            report_data.report_id, report_data.to_markdown(), properties
        )
        async with get_db_session() as db_session:
            from sqlalchemy import text
            await db_session.execute(
                text("UPDATE reports SET google_drive_file_id = :fid WHERE id = :id"),
                {"fid": drive_file_id, "id": db_report_id},
            )
        logger.info("report_uploaded_drive", file_id=drive_file_id)
    except Exception as exc:
        logger.error("drive_upload_failed", error=str(exc))

    # ── 7. Embed for Semantic Search ──────────────────────────────────────────
    if db_report_id:
        try:
            await pgvector_client.embed_report(db_report_id, report_data.to_markdown())
        except Exception as exc:
            logger.error("embedding_failed", error=str(exc))

    # ── 8. Run 3-AI Panel Session ─────────────────────────────────────────────
    from panel.engine import panel_engine
    panel_session = await panel_engine.run(
        report_content=report_data.to_markdown(),
        topic=f"Full intelligence assessment of {target}",
        target=target,
        report_id=report_data.report_id,
    )
    logger.info("panel_session_complete", session_id=panel_session.session_id)

    # ── 9. Store Panel Session ────────────────────────────────────────────────
    session_db_id = None
    async with get_db_session() as db_session:
        db_session_obj = PanelSessionModel(
            session_id=panel_session.session_id,
            report_id=db_report_id,
            topic=panel_session.topic,
            target=panel_session.target,
            transcript=[t.model_dump() for t in panel_session.history],
            positions=panel_session.positions,
            covered_topics=list(panel_session.covered_topics.keys()),
            disagreements=[d.model_dump() for d in panel_session.disagreements],
            rounds_completed=panel_session.round,
            final_synthesis=panel_session.final_synthesis,
            concluded=panel_session.concluded,
            start_time=panel_session.start_time,
            end_time=panel_session.end_time,
        )
        db_session.add(db_session_obj)
        await db_session.flush()
        session_db_id = str(db_session_obj.id)

    # ── 10. Upload Panel Assessment to Drive ──────────────────────────────────
    try:
        assessment_props = {
            "session_id": panel_session.session_id,
            "report_id": report_data.report_id,
            "target": target,
        }
        assessment_drive_id = await drive_client.upload_assessment(
            panel_session.session_id,
            panel_session.final_synthesis,
            assessment_props,
        )
        async with get_db_session() as db_session:
            from sqlalchemy import text
            await db_session.execute(
                text("UPDATE panel_sessions SET google_drive_file_id = :fid WHERE id = :id"),
                {"fid": assessment_drive_id, "id": session_db_id},
            )
    except Exception as exc:
        logger.error("assessment_drive_upload_failed", error=str(exc))

    # ── 11. Route Notifications ───────────────────────────────────────────────
    try:
        from comms.discord_bot import notification_router
        from core.schemas import Alert, Classification
        classification = Classification(report_data.classification)
        alert = Alert(
            alert_id=f"ALERT-{report_data.report_id[-8:]}",
            title=f"New Intelligence Report: {target}",
            body=report_data.executive_summary[:800],
            classification=classification,
            report_id=report_data.report_id,
            tags=report_data.tags,
        )
        await notification_router.route(alert)
    except Exception as exc:
        logger.error("notification_routing_failed", error=str(exc))

    logger.info(
        "pipeline_complete",
        target=target,
        report_id=report_data.report_id,
        session_id=panel_session.session_id,
        drive_file_id=drive_file_id,
    )

    return {
        "status": "complete",
        "report_id": report_data.report_id,
        "session_id": panel_session.session_id,
        "drive_file_id": drive_file_id,
        "items_collected": len(enriched_items),
        "rounds_completed": panel_session.round,
    }
