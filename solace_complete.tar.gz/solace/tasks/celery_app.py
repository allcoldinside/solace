"""
SOLACE — Celery Tasks
Full OSINT pipeline and panel session task definitions.
"""
from __future__ import annotations

import asyncio
from datetime import datetime

from celery import Celery

from config import configure_logging, get_logger, settings

configure_logging(settings.log_level)
logger = get_logger("tasks")

celery_app = Celery(
    "solace",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    worker_prefetch_multiplier=1,
    task_acks_late=True,
    task_reject_on_worker_lost=True,
    task_routes={
        "tasks.collection_tasks.*": {"queue": "collection"},
        "tasks.panel_tasks.*": {"queue": "panel"},
        "tasks.nlp_tasks.*": {"queue": "nlp"},
    },
)
