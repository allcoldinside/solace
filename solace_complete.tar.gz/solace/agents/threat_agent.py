"""
SOLACE — Threat Agent
Assesses threat level, correlates IOCs, and produces threat scoring.
"""
from __future__ import annotations

from config import get_logger

logger = get_logger("threat_agent")


async def run_threat_agent(state: dict) -> dict:
    """Threat agent: checks IOCs, sanctions, and threat feeds.

    Args:
        state: Current agent state dict.

    Returns:
        Updated state with threat indicators and findings.
    """
    target = state["target"]
    iteration = state.get("iteration", 0) + 1

    logger.info("threat_agent_running", target=target, iteration=iteration)

    findings = list(state.get("findings", []))
    threat_indicators = list(state.get("threat_indicators", []))

    try:
        import aiohttp
        async with aiohttp.ClientSession() as session:
            # Check OpenSanctions
            async with session.get(
                f"https://api.opensanctions.org/search/default?q={target}&limit=3",
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    for result in data.get("results", []):
                        if result.get("score", 0) > 0.7:
                            threat_indicators.append(
                                f"SANCTIONS MATCH: {result.get('caption')} "
                                f"(score: {result.get('score'):.2f})"
                            )
                            findings.append({
                                "finding": f"Subject appears in sanctions database: {result.get('caption')}",
                                "confidence": "HIGH",
                                "source": "threat_agent:opensanctions",
                            })

    except Exception as exc:
        logger.warning("threat_agent_sanctions_error", error=str(exc))

    # Try CISA advisories
    try:
        import feedparser, aiohttp
        async with aiohttp.ClientSession() as session:
            async with session.get(
                "https://www.cisa.gov/cybersecurity-advisories/all.xml",
                timeout=aiohttp.ClientTimeout(total=10),
            ) as resp:
                if resp.status == 200:
                    raw = await resp.text()
                    feed = feedparser.parse(raw)
                    for entry in feed.entries[:20]:
                        title = entry.get("title", "")
                        if target.lower() in title.lower():
                            threat_indicators.append(f"CISA ADVISORY: {title}")
                            findings.append({
                                "finding": f"Subject referenced in CISA advisory: {title}",
                                "confidence": "HIGH",
                                "source": "threat_agent:cisa",
                            })
    except Exception as exc:
        logger.debug("threat_agent_cisa_error", error=str(exc))

    return {
        **state,
        "findings": findings,
        "threat_indicators": threat_indicators,
        "iteration": iteration,
        "next_agent": "synthesize",
    }
