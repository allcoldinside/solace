"""SOLACE agents — LangGraph autonomous intelligence agents."""
from agents.tools import AGENT_TOOLS

def get_graph():
    """Lazy accessor for compiled agent graph."""
    from agents.graph import get_agent_graph
    return get_agent_graph()

def run_task(target, target_type="organization", task="monitor", max_iterations=5):
    """Convenience wrapper for running an agent task."""
    from agents.graph import run_agent_task
    import asyncio
    return asyncio.get_event_loop().run_until_complete(
        run_agent_task(target, target_type, task, max_iterations)
    )

__all__ = ["AGENT_TOOLS", "get_graph", "run_task"]
