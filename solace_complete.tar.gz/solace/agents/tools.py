"""
SOLACE — Shared Agent Tools
Tool functions available to all LangGraph agents for DB queries, search, and analysis.
"""
from __future__ import annotations

from typing import Any

from langchain.tools import tool
from config import get_logger

logger = get_logger("agent_tools")


@tool
async def search_reports(query: str, limit: int = 5) -> list[dict]:
    """Semantic search over SOLACE intelligence reports.

    Args:
        query: Natural language search query.
        limit: Maximum results to return.

    Returns:
        List of matching report summaries.
    """
    from storage.pgvector_client import pgvector_client
    results = await pgvector_client.search_reports(query, limit=limit)
    logger.info("agent_tool_search_reports", query=query, results=len(results))
    return results


@tool
async def get_report_by_id(report_id: str) -> dict | None:
    """Retrieve a specific report by its SOLACE ID.

    Args:
        report_id: SOLACE report ID (REPORT-YYYYMMDD-SLUG-UID).

    Returns:
        Report dict or None if not found.
    """
    from core.database import get_db_session
    from core.models import Report
    from sqlalchemy import select

    async with get_db_session() as db:
        result = await db.execute(
            select(Report).where(Report.report_id == report_id)
        )
        report = result.scalar_one_or_none()
        if not report:
            return None
        return {
            "report_id": report.report_id,
            "subject": report.subject,
            "classification": report.classification,
            "confidence": report.confidence,
            "executive_summary": report.executive_summary,
            "key_findings": report.key_findings,
            "entity_map": report.entity_map,
            "threat_assessment": report.threat_assessment,
        }


@tool
async def get_entity_network(entity_name: str, depth: int = 2) -> dict:
    """Get the relationship network for a named entity from the graph DB.

    Args:
        entity_name: Name of the entity to look up.
        depth: Traversal depth in the graph.

    Returns:
        Dict with nodes and relationships.
    """
    from storage.neo4j_client import neo4j_client
    import uuid
    entity_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, entity_name.lower().strip()))
    return await neo4j_client.get_entity_network(entity_id, depth=depth)


@tool
async def trigger_collection(target: str, target_type: str = "organization") -> dict:
    """Trigger an OSINT collection run for a target.

    Args:
        target: Subject to collect intelligence on.
        target_type: Type classification (organization/person/infrastructure/event).

    Returns:
        Task dispatch result with task_id.
    """
    from tasks.collection_tasks import run_full_osint_pipeline
    task = run_full_osint_pipeline.delay(
        target=target,
        target_type=target_type,
        requestor="agent",
    )
    logger.info("agent_triggered_collection", target=target, task_id=task.id)
    return {"task_id": task.id, "target": target, "status": "queued"}


@tool
async def check_sanctions(name: str) -> dict:
    """Check a name against OpenSanctions database.

    Args:
        name: Person or organization name to check.

    Returns:
        Sanctions check result with match details.
    """
    import aiohttp
    async with aiohttp.ClientSession() as session:
        async with session.get(
            f"https://api.opensanctions.org/search/default?q={name}&limit=3",
            timeout=aiohttp.ClientTimeout(total=10),
        ) as resp:
            if resp.status != 200:
                return {"found": False, "name": name}
            data = await resp.json()
            results = data.get("results", [])
            high_confidence = [r for r in results if r.get("score", 0) > 0.7]
            return {
                "found": len(high_confidence) > 0,
                "name": name,
                "matches": high_confidence[:3],
                "total_results": len(results),
            }


@tool
def summarize_findings(findings: list[dict]) -> str:
    """Synthesize a list of intelligence findings into a structured summary.

    Args:
        findings: List of finding dicts with 'finding', 'confidence', 'source'.

    Returns:
        Formatted summary string.
    """
    if not findings:
        return "No findings to summarize."

    lines = ["INTELLIGENCE FINDINGS SUMMARY", "=" * 40]
    for i, f in enumerate(findings, 1):
        confidence = f.get("confidence", "UNKNOWN")
        finding = f.get("finding", str(f))
        source = f.get("source", "unattributed")
        lines.append(f"{i}. [{confidence}] {finding}")
        lines.append(f"   Source: {source}")

    high = sum(1 for f in findings if f.get("confidence") == "HIGH")
    med = sum(1 for f in findings if f.get("confidence") == "MEDIUM")
    low = sum(1 for f in findings if f.get("confidence") == "LOW")
    lines.append(f"\nTotal: {len(findings)} | HIGH: {high} | MEDIUM: {med} | LOW: {low}")

    return "\n".join(lines)


AGENT_TOOLS = [
    search_reports,
    get_report_by_id,
    get_entity_network,
    trigger_collection,
    check_sanctions,
    summarize_findings,
]
