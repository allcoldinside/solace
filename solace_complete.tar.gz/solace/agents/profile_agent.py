"""
SOLACE — Profile Agent
Builds comprehensive subject profiles from entity data and report corpus.
"""
from __future__ import annotations

from config import get_logger

logger = get_logger("profile_agent")


async def run_profile_agent(state: dict) -> dict:
    """Profile agent: builds entity profile from graph and report data.

    Args:
        state: Current agent state dict.

    Returns:
        Updated state with profile findings and entity map.
    """
    target = state["target"]
    iteration = state.get("iteration", 0) + 1

    logger.info("profile_agent_running", target=target, iteration=iteration)

    findings = list(state.get("findings", []))
    entity_map = dict(state.get("entity_map", {}))
    next_agent = "synthesize"

    try:
        from storage.pgvector_client import pgvector_client
        results = await pgvector_client.search_reports(f"profile {target}", limit=3)

        for r in results:
            em = r.get("entity_map", {})
            if isinstance(em, dict):
                for category, entities in em.items():
                    if category not in entity_map:
                        entity_map[category] = []
                    entity_map[category] = list(set(
                        entity_map[category] + (entities or [])
                    ))

            # Extract profile-relevant findings
            key_findings = r.get("key_findings", [])
            if isinstance(key_findings, list):
                for kf in key_findings[:3]:
                    if isinstance(kf, dict):
                        findings.append({
                            "finding": kf.get("finding", ""),
                            "confidence": kf.get("confidence", "MEDIUM"),
                            "source": f"profile_agent:{r.get('report_id')}",
                        })

        # After profiling, check threat indicators
        if iteration < state.get("max_iterations", 5):
            next_agent = "threat"

    except Exception as exc:
        logger.error("profile_agent_error", error=str(exc))

    return {
        **state,
        "findings": findings,
        "entity_map": entity_map,
        "iteration": iteration,
        "next_agent": next_agent,
    }
