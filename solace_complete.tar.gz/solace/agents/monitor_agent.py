"""
SOLACE — Monitor Agent
Ongoing surveillance agent: watches for new intelligence on a target.
"""
from __future__ import annotations

from config import get_logger, settings

logger = get_logger("monitor_agent")


async def run_monitor_agent(state: dict) -> dict:
    """Monitor agent node: searches existing reports and flags new intelligence.

    Searches the report corpus for anything relevant to the target,
    extracts key findings, and routes to threat agent if IOCs detected.

    Args:
        state: Current agent state dict.

    Returns:
        Updated state with new findings.
    """
    target = state["target"]
    iteration = state.get("iteration", 0) + 1

    logger.info("monitor_agent_running", target=target, iteration=iteration)

    findings = list(state.get("findings", []))
    report_ids = list(state.get("report_ids", []))
    next_agent = "synthesize"

    try:
        from storage.pgvector_client import pgvector_client
        results = await pgvector_client.search_reports(target, limit=5)

        for r in results:
            report_ids.append(r.get("report_id", ""))
            summary = r.get("executive_summary", "")
            if summary:
                findings.append({
                    "finding": f"Report {r.get('report_id')}: {summary[:200]}",
                    "confidence": r.get("confidence", "MEDIUM"),
                    "source": "monitor_agent_search",
                    "report_id": r.get("report_id"),
                })

        # If threat reports found, escalate to threat agent
        threat_reports = [r for r in results if r.get("confidence") == "HIGH"]
        if threat_reports and iteration < state.get("max_iterations", 5):
            next_agent = "threat"
        elif len(findings) < 3 and iteration < state.get("max_iterations", 5):
            # Not enough findings — try profile agent
            next_agent = "profile"

    except Exception as exc:
        logger.error("monitor_agent_error", error=str(exc))
        findings.append({
            "finding": f"Monitor search unavailable: {exc}",
            "confidence": "LOW",
            "source": "monitor_agent_error",
        })

    return {
        **state,
        "findings": findings,
        "report_ids": list(set(report_ids)),
        "iteration": iteration,
        "next_agent": next_agent,
    }
