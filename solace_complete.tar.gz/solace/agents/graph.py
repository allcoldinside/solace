"""
SOLACE — LangGraph Agent State Machine
Defines the main agent graph with Monitor, Profile, Threat, and Geo agents.
"""
from __future__ import annotations

from typing import Annotated, TypedDict

from langgraph.graph import StateGraph, END
from config import get_logger

logger = get_logger("agent_graph")


class AgentState(TypedDict):
    """Shared state across all SOLACE agents in the graph."""
    target: str
    target_type: str
    task: str                          # Current task: monitor / profile / threat / geo
    messages: list[dict]               # Conversation history
    findings: list[dict]               # Accumulated findings
    report_ids: list[str]              # Reports consulted
    entity_map: dict[str, list[str]]   # Entities discovered
    threat_indicators: list[str]       # IOCs and threat signals
    geo_data: list[dict]               # Geographic intelligence
    final_assessment: str              # Final synthesized output
    iteration: int                     # Loop counter
    max_iterations: int                # Guard against infinite loops
    next_agent: str                    # Router decision


def route_to_agent(state: AgentState) -> str:
    """Route to the appropriate agent based on task and state.

    Args:
        state: Current agent state.

    Returns:
        Next node name.
    """
    task = state.get("task", "monitor")
    iteration = state.get("iteration", 0)
    max_iter = state.get("max_iterations", 5)

    if iteration >= max_iter:
        logger.info("agent_max_iterations_reached", iteration=iteration)
        return "synthesize"

    next_agent = state.get("next_agent", task)

    routes = {
        "monitor": "monitor_agent",
        "profile": "profile_agent",
        "threat": "threat_agent",
        "geo": "geo_agent",
        "synthesize": "synthesize",
        "end": END,
    }
    return routes.get(next_agent, "synthesize")


def build_agent_graph() -> StateGraph:
    """Build and compile the SOLACE agent state machine.

    Returns:
        Compiled LangGraph StateGraph.
    """
    from agents.monitor_agent import run_monitor_agent
    from agents.profile_agent import run_profile_agent
    from agents.threat_agent import run_threat_agent

    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("monitor_agent",  run_monitor_agent)
    graph.add_node("profile_agent",  run_profile_agent)
    graph.add_node("threat_agent",   run_threat_agent)
    graph.add_node("synthesize",     _synthesize_node)

    # Entry point — router decides where to start
    graph.set_conditional_entry_point(route_to_agent)

    # All agents can route to any other agent or end
    for agent_node in ["monitor_agent", "profile_agent", "threat_agent"]:
        graph.add_conditional_edges(agent_node, route_to_agent)

    graph.add_edge("synthesize", END)

    return graph.compile()


async def _synthesize_node(state: AgentState) -> AgentState:
    """Final synthesis node — combines all agent findings into assessment.

    Args:
        state: Accumulated agent state.

    Returns:
        Updated state with final_assessment populated.
    """
    findings = state.get("findings", [])
    target = state.get("target", "Unknown")
    threat_indicators = state.get("threat_indicators", [])
    geo_data = state.get("geo_data", [])

    lines = [
        f"# SOLACE AGENT ASSESSMENT: {target}",
        "",
        f"## FINDINGS ({len(findings)} total)",
    ]
    for i, f in enumerate(findings, 1):
        lines.append(f"{i}. [{f.get('confidence','?')}] {f.get('finding', f)}")

    if threat_indicators:
        lines.append(f"\n## THREAT INDICATORS ({len(threat_indicators)})")
        for ti in threat_indicators[:10]:
            lines.append(f"- {ti}")

    if geo_data:
        lines.append(f"\n## GEOGRAPHIC INTELLIGENCE ({len(geo_data)} locations)")
        for gd in geo_data[:5]:
            lines.append(f"- {gd.get('location', gd)}")

    lines.append(f"\n## REPORTS CONSULTED")
    for rid in state.get("report_ids", []):
        lines.append(f"- {rid}")

    assessment = "\n".join(lines)
    logger.info("agent_synthesis_complete", target=target,
                findings_count=len(findings))

    return {**state, "final_assessment": assessment}


# Singleton compiled graph
_compiled_graph = None


def get_agent_graph():
    """Get or build the compiled agent graph singleton."""
    global _compiled_graph
    if _compiled_graph is None:
        _compiled_graph = build_agent_graph()
    return _compiled_graph


async def run_agent_task(
    target: str,
    target_type: str = "organization",
    task: str = "monitor",
    max_iterations: int = 5,
) -> dict:
    """Execute an agent task on a target.

    Args:
        target: Intelligence target.
        target_type: Target type.
        task: Starting task (monitor/profile/threat/geo).
        max_iterations: Maximum agent iterations.

    Returns:
        Final agent state with assessment.
    """
    graph = get_agent_graph()

    initial_state: AgentState = {
        "target": target,
        "target_type": target_type,
        "task": task,
        "messages": [],
        "findings": [],
        "report_ids": [],
        "entity_map": {},
        "threat_indicators": [],
        "geo_data": [],
        "final_assessment": "",
        "iteration": 0,
        "max_iterations": max_iterations,
        "next_agent": task,
    }

    logger.info("agent_task_started", target=target, task=task)
    final_state = await graph.ainvoke(initial_state)
    logger.info("agent_task_complete", target=target,
                findings=len(final_state.get("findings", [])))

    return final_state
